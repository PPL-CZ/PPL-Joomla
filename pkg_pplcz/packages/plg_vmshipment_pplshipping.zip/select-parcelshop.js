
jQuery(document).on("click", "button[data-pplcz-select-parcel-shop],a[data-pplcz-select-parcel-shop]", function(ev) {
    ev.preventDefault();
   const mapSetting = {
       address : jQuery(this).data('address') ?? null,
       country : jQuery(this).data('country') ?? null,
       hiddenPoints : jQuery(this).data('hidden-points') ?? null,
       countries : jQuery(this).data('countries') ?? null
   }

   const what = jQuery(this).data("pplcz-select-parcel-shop");

   async function updateCheckout(data){
       await jQuery("[name=pplcz_parcelshop]").val(JSON.stringify(data));

       // Použití absolutní URL z konfigurace
       const baseUrl = (window.PPLCZ_MAP_CONFIG && window.PPLCZ_MAP_CONFIG.siteurl)
           ? window.PPLCZ_MAP_CONFIG.siteurl
           : window.location.origin + '/';
       const ajaxUrl = baseUrl + "index.php?option=com_pplcz&task=Cart.setCartSession";

       await jQuery.post(ajaxUrl, {parcelshop: JSON.stringify(data)})
       Virtuemart.autocheck();
   }



   switch(what)
   {
       case "cash":
           PplMap(data => updateCheckout(data), { withCash: true, ...mapSetting});
           break;
       case "clear":
           updateCheckout(null);
           break;
       default:

           PplMap(data => updateCheckout(data), mapSetting);
           break;
   }
});

jQuery('body').on('updated_checkout', function() {

    const trigger = jQuery("a[data-pplcz-select-parcel-shop], button[data-pplcz-select-parcel-shop]").first();

    if (trigger.length > 0) {
        //Testovací komponenta
        window.pplczLastPplMapData = {
            address: trigger.data("address") ?? null,
            country: trigger.data("country") ?? null,
            hiddenPoints: trigger.data("hidden-points") ?? null,
            countries: trigger.data("countries") ?? null
        };
    }
    const showmap = jQuery('.pplcz-parcelshop-inner').data('pplcz-showmap');
    if (showmap == 1) {
        jQuery("a[data-pplcz-select-parcel-shop]").trigger("click")

    }
});

(function ($) {
    $('form.checkout').on('change','input[name^=\"virtuemart_paymentmethod_id\"]', function () {
        const selectedPaymentMethod = $('input[name^="virtuemart_paymentmethod_id"]:checked').val();
        const payments = [previousPaymentMethod, selectedPaymentMethod];

        //const codMethod = jQuery('a.pplcz-parcel').data('cod-method');
        const codMethod = jQuery('#pplcz_cod_method').val();

        previousPaymentMethod = selectedPaymentMethod;

        if (payments.indexOf(codMethod) > -1)
        {
            $('body').trigger('virtuemart_paymentmethod_id');
        }
    });
})(jQuery);
