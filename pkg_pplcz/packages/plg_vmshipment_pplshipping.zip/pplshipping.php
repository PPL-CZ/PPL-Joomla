<?php

use Joomla\CMS\Factory;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\WebAsset\WebAssetManager;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Layout\FileLayout;
use Joomla\CMS\Table\Table;
use PPLCZ\Model\Model\CartModel;
use PPLCZ\Serializer;
//use PPLCZComponent\Component\Pplcz\Site\Template\Template;
use PPLCZ\Template\Template;
use Joomla\Registry\Registry;
use PPLCZ\Data\AddressData;
use PPLCZ\Model\Model\SenderAddressModel;
use PPLCZ\Admin\Order\OrderPanel;
use PPLCZ\Setting\MethodSetting;


defined('_JEXEC') or die('Restricted access');

if (!class_exists('vmPSPlugin')) {
    require(VMPATH_PLUGINLIBS . DS . 'vmpsplugin.php');
}

require_once JPATH_ADMINISTRATOR . "/components/com_pplcz/core/autoloader.php";
require_once JPATH_ADMINISTRATOR . '/components/com_pplcz/core/globals.php';

class plgVmshipmentPplshipping extends vmPSPlugin
{
    function __construct(&$subject, $config)
    {
        $cart = VirtueMartCart::getCart();
        parent::__construct($subject, $config);

        $this->_loggable = TRUE;
        $this->_tablepkey = 'id';
        $this->_tableId = 'id';
        $this->tableFields = array_keys($this->getTableSQLFields());
        $this->_tablename = '#__virtuemart_shipment_plg_pplshipping';

        $varsToPush = $this->getVarsToPush();

        $this->addVarsToPushCore($varsToPush, 0); // 0 for shipment
        $this->setConfigParameterable($this->_configTableFieldName, $varsToPush);
        $this->setConvertable(array('min_amount', 'max_amount', 'shipment_cost', 'package_fee', 'free_shipment'));

        $wa = Factory::getApplication()->getDocument()->getWebAssetManager();
        // Použití lokální verze select-parcelshop.js pro VirtueMart (s AJAX voláním)
        $wa->registerAndUseScript('select-parcelshop', Uri::root() . 'plugins/vmshipment/pplshipping/select-parcelshop.js', ['jquery'], ['defer' => true]);
        $wa->registerAndUseScript('ppl-map', Uri::root() . 'administrator/components/com_pplcz/core/Front/Components/Map/ppl-map.js', ['jquery'], ['defer' => true]);
        $wa->registerAndUseStyle('ppl-map-css', Uri::root() . 'administrator/components/com_pplcz/core/Front/Components/Map/ppl-map.css', ['jquery'], ['defer' => true]);
        $wa->registerAndUseStyle('ppl-label-method-css', Uri::root() . 'administrator/components/com_pplcz/core/Front/Components/Map/label-method.css', ['jquery'], ['defer' => true]);

        $mapUrl = Uri::root() . 'index.php?option=com_pplcz&view=map&tmpl=component';
        $config = ['mapurl' => $mapUrl, 'siteurl' => Uri::root()];
        $configScript = 'window.PPLCZ_MAP_CONFIG = ' . json_encode($config) . ';';
        $wa->addInlineScript($configScript, [], [], ['ppl-map']);
    }


    public function getTableSQLFields()
    {
        $SQLfields = array(
            'id' => 'int(1) UNSIGNED NOT NULL AUTO_INCREMENT',
            'virtuemart_order_id' => 'int(11) UNSIGNED',
            'order_number' => 'char(32)',
            'virtuemart_shipmentmethod_id' => 'mediumint(1) UNSIGNED',
            'shipment_name' => 'varchar(5000)',
            'order_weight' => 'decimal(10,4)',
            'shipment_weight_unit' => 'char(3) DEFAULT \'KG\'',
            'free_shipment' => 'boolean',
            'shipment_cost' => 'decimal(10,2)',
            'shipment_package_fee' => 'decimal(10,2)',
            'tax_id' => 'smallint(1)'
        );
        return $SQLfields;
    }

    /**
     * This method is fired when showing the order details in the frontend.
     */
    public function plgVmOnShowOrderFEShipment($virtuemart_order_id, $virtuemart_shipmentmethod_id, &$shipment_name)
    {
        $this->onShowOrderFE($virtuemart_order_id, $virtuemart_shipmentmethod_id, $shipment_name);
    }

    /**
     * This event is fired after the order has been stored
     */
    function plgVmConfirmedOrder(VirtueMartCart $cart, $order)
    {
        if (!($method = $this->getVmPluginMethod($order['details']['BT']->virtuemart_shipmentmethod_id))) {
            return NULL; // Another method was selected, do nothing
        }
        if (!$this->selectedThisElement($method->shipment_element)) {
            return FALSE;
        }

        $weight_unit = $method->weight_unit ?? '';

        $values['virtuemart_order_id'] = $order['details']['BT']->virtuemart_order_id;
        $values['order_number'] = $order['details']['BT']->order_number;
        $values['virtuemart_shipmentmethod_id'] = $order['details']['BT']->virtuemart_shipmentmethod_id;
        $values['shipment_name'] = $this->renderPluginName($method);
        $values['order_weight'] = $this->getOrderWeight($cart, $weight_unit);
        $values['shipment_weight_unit'] = $weight_unit;

        $costs = $this->getCosts($cart, $method, $cart->cartPrices);
        if (!empty($costs)) {
            $values['shipment_cost'] = $method->shipment_cost;
            $values['shipment_package_fee'] = $method->package_fee;
        }
        if (empty($values['shipment_cost'])) $values['shipment_cost'] = 0.0;
        if (empty($values['shipment_package_fee'])) $values['shipment_package_fee'] = 0.0;

        $values['tax_id'] = $method->tax_id;
        $this->storePSPluginInternalData($values);

        $status = $order['details']['BT']->order_status;
        if ($status === 'P' || $status === 'C') {
            $this->store_order_meta($method, $order);
        }


        return TRUE;
    }

    public function store_order_meta($method, $order)
    {
        if ($method->code && MethodSetting::getMethod($method->code)) {
            $shipmentModel = pplcz_denormalize($method, CartModel::class);
            $cartData = pplcz_normalize($shipmentModel);
            $cartJson = json_encode($cartData);

            $parcelModel = pplcz_get_cart_parceldata();
            $id = $order['details']['BT']->virtuemart_order_id;

            $db = Factory::getContainer()->get('DatabaseDriver');
            $query = $db->getQuery(true);

            if ($parcelModel) {
                $parcelData = pplcz_normalize($parcelModel);
                $parcelJson = json_encode($parcelData);
                $columns = ['ppl_order_id', 'cart_model', 'parcel_model'];

                $values = [(int)$id,
                    $db->quote($cartJson),
                    $db->quote($parcelJson)];
            } else {
                $columns = ['ppl_order_id', 'cart_model'];
                $values = [(int)$id,
                    $db->quote($cartJson)];
            }

            $query
                ->insert($db->quoteName('#__pplcz_order_meta'))
                ->columns($db->quoteName($columns))
                ->values(implode(', ', $values));

            $db->setQuery($query);
            $db->execute();
        }
    }

    /**
     * This method is fired when showing the order details in the backend.
     */
    // Zobrazení dopravy v administraci objednávky
    public function plgVmOnShowOrderBEShipment($virtuemart_order_id, $virtuemart_shipmentmethod_id)
    {
        if (!($this->selectedThisByMethodId($virtuemart_shipmentmethod_id))) {
            return NULL;
        }

        $order = VmModel::getModel('orders');
        $order = $order->getTable('orders');
        $order->load($virtuemart_order_id);
        $html = OrderPanel::render($order);
        return $html;
    }

    /**
     * Get order shipment HTML for backend
     */
    // Viz metoda výše
    function getOrderShipmentHtml($virtuemart_order_id)
    {
//        $db = JFactory::getDBO();
        $db = Factory::getContainer()->get('DatabaseDriver');
        $q = 'SELECT * FROM `' . $this->_tablename . '` '
            . 'WHERE `virtuemart_order_id` = ' . $virtuemart_order_id;
        $db->setQuery($q);
        if (!($shipinfo = $db->loadObject())) {
            return 'No shipping info found for order ID: ' . $virtuemart_order_id;
        }
        // Pro zobrazení správné ceny s DPH vytáhnout shipmentData
        $currency = CurrencyDisplay::getInstance();
        $html = '<table class="adminlist table">' . "\n";
        //
        $html .= $this->getHtmlRowBE('Název dopravy', $shipinfo->shipment_name);
        $html .= $this->getHtmlRowBE('Cena dopravy', $currency->priceDisplay($shipinfo->shipment_cost));
        $html .= $this->getHtmlRowBE('Váha zásilky', $shipinfo->order_weight);
        $html .= '</table>' . "\n";

        return $html;
    }


    /**
     * Calculate shipping costs
     */
    function getCosts(VirtueMartCart $cart, $method, $cart_prices)
    {
        $costs = $this->calculate_shipping($cart, $method);

        $method->shipment_cost = $costs['cost'] + $costs['codFee'];
        $method->tax_id = $costs['costDPH'] ? $costs['costDPHId'] : $costs['codFeeDPHId'];

        return $method->shipment_cost;
    }

    protected function setParcelData()
    {
        $parcelModel = pplcz_get_cart_parceldata();
        $table = new \PPLCZ\Data\ParcelData();

        $gps = ($parcelModel !== null) ? $parcelModel->getGps() : null;
        $lat = ($gps !== null) ? $gps->getLatitude() : null;
        $lng = ($gps !== null) ? $gps->getLongitude() : null;

        $data = [
            'name' => $parcelModel->getName(),
            'name2' => null,
            'street' => $parcelModel->getStreet(),
            'city' => $parcelModel->getCity(),
            'zip' => $parcelModel->getZipCode(),
            'country' => $parcelModel->getCountry(),
            'code' => $parcelModel->getCode(),
            'type' => $parcelModel->getAccessPointType(),
            'lat' => $lat,
            'lng' => $lng,
            'valid' => 1,
            'hidden' => 0,
        ];

        $table->bind($data);

        if (!$table->check()) {
            throw new \RuntimeException($table->getError());
        }

        if (!$table->store()) {
            throw new \RuntimeException($table->getError());
        }
    }

    /**
     * Check conditions for this shipping method
     */
    // Zde přidat podmínky z ShipmentMethod.php - ověření váhy apod.
    protected function checkConditions($cart, $method, $cart_prices)
    {
//         Add any custom conditions here if needed
//         For now, just return true to allow this method

        $shipmentMethod = \VmModel::getModel('shipmentmethod');
        $shipmentMethod = $shipmentMethod->getShipment($method->virtuemart_shipmentmethod_id);
        $cartData = pplcz_denormalize($shipmentMethod, CartModel::class);

        $countryId = $_POST['virtuemart_country_id'] ?? $cart->BT['virtuemart_country_id'] ?? null;

        if (isset($countryId)) {
            $countryModel = VmModel::getModel('country')->getCountry($countryId);
        }
        else{
            $countryModel = null;
        }
        $country = $countryModel ? $countryModel->country_2_code : null;

        if ($country != null && $cartData->getDisabledByCountry()) {
            return false;
        }

        if ($country != null && $cartData->getDisabledByRules()) {
            return false;
        }

        if ($cartData->getDisabledByWeight())
            return false;

        if ($cartData->getParcelRequired() && $cartData->getAgeRequired() && $country !== 'CZ')
            return false;

        if ($cartData->getDisabledByProduct())
            return false;

        if ($cartData->getDisabledBySize())
            return false;

        return true;
    }

    /**
     * Convert method values
     */
    function convert(&$method)
    {
        $method->min_amount = (float)str_replace(',', '.', $method->min_amount);
        $method->max_amount = (float)str_replace(',', '.', $method->max_amount);
        $method->free_shipment = (float)str_replace(',', '.', $method->free_shipment);
        $method->shipment_cost = (float)str_replace(',', '.', $method->shipment_cost);
        $method->package_fee = (float)str_replace(',', '.', $method->package_fee);
    }

    /**
     * Display list in frontend
     */
    // Vykreslení dopravy vč. vlastního divu s odkazem na mapu na FE
    public function plgVmDisplayListFEShipment(VirtueMartCart $cart, $selected = 0, &$htmlIn)
    {
        if ($this->getPluginMethods($cart->vendorId) === 0) {
            return false;
        }

        $this->displayListFE($cart, $selected, $htmlIn);
        $htmlBlocks = [];
        foreach ($this->methods as $method) {

            $shipmentMethod = \VmModel::getModel('shipmentmethod');
            $shipmentMethod = $shipmentMethod->getShipment($method->virtuemart_shipmentmethod_id);
            $cartData = pplcz_denormalize($shipmentMethod, CartModel::class);
            $cart_prices = $cart->cartPrices;

            if ($selected != $method->virtuemart_shipmentmethod_id || !in_array($cartData->getServiceCode(), ['SMAR', 'SMEU', 'SMED', 'SBOX', 'SBOD'])) {
                continue;
            }

            if (!$this->checkConditions($cart, $method, $cart_prices)) {
                continue;
            }

            $html = '<div class="custom-shipment-details" value="' . $method->virtuemart_shipmentmethod_id . '" ' . ($selected == $method->virtuemart_shipmentmethod_id ? 'checked' : '') . '>';
            $html .= $this->plgVmOnGetMapTemplate($method);
            $html .= '</div>';

            $htmlBlocks[] = $html;
        }

        $htmlIn[] = $htmlBlocks;

        return true;
    }

    // Implementace template pro vykreslení údajů o výdejním místě, viz metoda výše
    public function plgVmOnGetMapTemplate($method)
    {
        $app = Factory::getApplication();

        $image = pplcz_asset_icon('ps_pb.png');

        //Data získaná ze session
        $parcelshop = pplcz_get_cart_parceldata();

        if ($parcelshop) {
            $accessPointType = $parcelshop->getAccessPointType();
        }

        $shipmentId = $method->virtuemart_shipmentmethod_id;
        $shipmentMethod = \VmModel::getModel('shipmentmethod');
        $shipmentMethod = $shipmentMethod->getShipment($shipmentId);
        $cartData = pplcz_denormalize($shipmentMethod, CartModel::class);

        return Template::render('select-parcelshop-inner.php', [
            "shipping_address" => $parcelshop,
            "cod" => $cartData->getDisableCod(),
            "codMethod" => $cartData->getCodPayment(),
            "accessPointType" => $accessPointType ?? Text::_('PLG_VMSHIPMENT_PPLSHIPPING_PICKUP_POINT'),
            "parcelRequired" => $cartData->getParcelRequired(),
            "ageRequired" => $cartData->getAgeRequired(),
            "mapEnabled" => $cartData->getMapEnabled(),
            "parcelShopEnabled" => $cartData->getParcelShopEnabled(),
            "parcelBoxEnabled" => $cartData->getParcelBoxEnabled(),
            "alzaBoxEnabled" => $cartData->getAlzaBoxEnabled(),
            "countries" => $cartData->getEnabledParcelCountries(),
            "ageOk" => $cartData->getAgeRequired(),
            "content" => urlencode(json_encode($parcelshop ? Serializer::getInstance()->normalize($parcelshop) : null)),
            "image" => $image,
            "nonce" => md5(uniqid()),
            "showMap" => 0,
            "canOpenMap" => !$cartData->getDisabledByCountry()
        ]);
    }

    public function calculate_shipping($cart, $method)
    {
        /**
         * @var CartModel $cartData
         */

        $shipmentId = $method->virtuemart_shipmentmethod_id;
        $shipmentMethod = \VmModel::getModel('shipmentmethod');
        $shipmentMethod = $shipmentMethod->getShipment($shipmentId);

        $cartData = pplcz_denormalize($shipmentMethod, CartModel::class);
        $app = Factory::getApplication();

        return [
            'codFee' => $cartData->getCodFee(),
            'codFeeDPH' => $cartData->getCodFeeDPH() ? $cartData->getCodFeeDPH()->getValue() : 0,
            'codFeeDPHId' => $cartData->getCodFeeDPH() ? $cartData->getCodFeeDPH()->getDphId() : -1,
            'cost' => $cartData->getCost(),
            'costDPH' => $cartData->getCostDPH() ? $cartData->getCostDPH()->getValue() : 0,
            'costDPHId' => $cartData->getCostDPH() ? $cartData->getCostDPH()->getDphId() : -1,
        ];
    }

    /**
     * Calculate price when selected
     */
    public
    function plgVmOnSelectedCalculatePriceShipment(VirtueMartCart $cart, array &$cart_prices, &$cart_prices_name)
    {
        return $this->onSelectedCalculatePrice($cart, $cart_prices, $cart_prices_name);
    }

    /**
     * Check automatic selection
     */
    function plgVmOnCheckAutomaticSelectedShipment(VirtueMartCart $cart, array $cart_prices, &$shipCounter)
    {
        return $this->onCheckAutomaticSelected($cart, $cart_prices, $shipCounter);
    }

    /**
     * Select check
     */
    public
    function plgVmOnSelectCheckShipment(VirtueMartCart &$cart)
    {
        return $this->OnSelectCheck($cart);
    }

    /**
     * Checkout data check
     */
    function plgVmOnCheckoutCheckDataShipment(VirtueMartCart $cart)
    {
        if (empty($cart->virtuemart_shipmentmethod_id)) return false;

        if ($this->getPluginMethods($cart->vendorId) === 0) {
            return NULL;
        }

        $isOurMethod = false;

        foreach ($this->methods as $this->_currentMethod) {
            if ($cart->virtuemart_shipmentmethod_id == $this->_currentMethod->virtuemart_shipmentmethod_id) {
                $isOurMethod = true;
                break;
            }
        }

        if (!$isOurMethod) {
            return NULL;
        }

        $app = Factory::getApplication();

        $shipmentMethod = \VmModel::getModel('shipmentmethod');
        $shipmentMethod = $shipmentMethod->getShipment($cart->virtuemart_shipmentmethod_id);
        $cartData = pplcz_denormalize($shipmentMethod, CartModel::class);
        $cart->setRedirectDisabled(true);

        $errors = pplcz_validate($cart);
        if ($errors->hasErrors()) {
            foreach ($errors->getErrors() as $error => $messages) {
                $app = Factory::getApplication();
                $message = is_array($messages) ? $messages[0] : $messages;
                $app->enqueueMessage($message, 'error');
            }

            $cart->setRedirectDisabled(true); // Zabrání přesměrování na stránku edit_shipment"
            $cart->blockConfirm(); // Zablokuje tlačítko "Potvrdit objednávku"

            return false;
        }

        if (!$this->checkConditions($cart, $this->_currentMethod, $cart->cartPrices)) {
            return false;
        }

        return true;
    }

    function plgVmOnCheckoutCheckDataPayment(VirtueMartCart $cart)
    {

        if (empty($cart->virtuemart_shipmentmethod_id)) {
            return null;
        }

        $isOurMethod = false;
        foreach ($this->methods as $method) {
            if ($cart->virtuemart_shipmentmethod_id == $method->virtuemart_shipmentmethod_id) {
                $isOurMethod = true;
                break;
            }
        }

        if (!$isOurMethod) {
            return null;
        }


        if (empty($cart->virtuemart_paymentmethod_id)) {
            return null;
        }


        $shipmentMethod = \VmModel::getModel('shipmentmethod');
        $shipmentMethod = $shipmentMethod->getShipment($cart->virtuemart_shipmentmethod_id);
        $cartData = pplcz_denormalize($shipmentMethod, CartModel::class);

        $codPaymentId = $cartData->getCodPayment();

        if (!$codPaymentId) {
            return null;
        }

        if ($cart->virtuemart_paymentmethod_id != $codPaymentId) {
            return null;
        }

        $countryId = $cart->ST['virtuemart_country_id'] ?? $cart->BT['virtuemart_country_id'] ?? null;

        if (!isset($countryId)) {
            return null;
        }

        $countryModel = VmModel::getModel('country')->getCountry($countryId);
        $countryCode = $countryModel ? $countryModel->country_2_code : null;

        if ($countryCode && $countryCode !== 'CZ') {
            $app = Factory::getApplication();
            $app->enqueueMessage(
                Text::_('PLG_VMSHIPMENT_PPLSHIPPING_COD_ONLY_CZ'),
                'error'
            );

            return false;
        }

        return null;
    }

    /**
     * Create plugin table
     */
    function plgVmOnStoreInstallShipmentPluginTable($jplugin_id)
    {
        return $this->onStoreInstallPluginTable($jplugin_id);
    }

    public function plgVmOnStoreShipmentPluginOrder()
    {

    }

    /**
     * Show order print
     */
    function plgVmOnShowOrderPrint($order_number, $method_id)
    {
        return $this->onShowOrderPrint($order_number, $method_id);
    }

    /**
     * Declare plugin parameters for VM3
     */
    function plgVmDeclarePluginParamsShipmentVM3(&$data)
    {
        return $this->declarePluginParams('shipment', $data);
    }

    /**
     * Set plugin parameters on table
     */
    function plgVmSetOnTablePluginShipment(&$data, &$table)
    {
        $name = $data['shipment_element'];
        $id = $data['shipment_jplugin_id'];

        if (!empty($this->_psType) and !$this->selectedThis($this->_psType, $name, $id)) {
            return FALSE;
        } else {
            // Convert numeric fields
            $tCon = array('min_amount', 'max_amount', 'shipment_cost', 'package_fee');
            foreach ($tCon as $f) {
                if (!empty($data[$f])) {
                    $data[$f] = str_replace(array(',', ' '), array('.', ''), $data[$f]);
                }
            }

            return $this->setOnTablePluginParams($name, $id, $table);
        }
    }

    /**
     * Render plugin name with cost
     * Metoda renderuje pouze název metody, cena v závorce (Fee ...) se renderuje jinde
     */

    protected function renderPluginName($plugin)
    {
        $return = '';
        $plugin_name = $this->_psType . '_name';
        $plugin_desc = $this->_psType . '_desc';
        $description = '';
        $img = pplcz_asset_icon('small_logo.png');
        $cart = VirtueMartCart::getCart();
        $paymentModel = VmModel::getModel('paymentmethod');
        $paymentId = $cart->virtuemart_paymentmethod_id;
        $paymentMethod = $paymentModel->getPayment($paymentId);

        $prices = self::calculate_shipping($cart, $plugin);

        $plugin->shipment_cost = ($prices['cost'] + $prices['costDPH']) + ($prices['codFee'] + $prices['codFeeDPH']);

        if (!empty($plugin->{$plugin_desc})) {
            $description = '<span class="' . $this->_type . '_description">' . $plugin->{$plugin_desc} . '</span>';
        }

        $cost = '';

        $db = Factory::getContainer()->get('DatabaseDriver');
        $query = $db->getQuery('true')
            ->select($db->quoteName('params'))
            ->from($db->quoteName('#__pplcz_shipment_method'))
            ->where($db->quoteName('virtuemart_shipmentmethod_id') . ' = ' . $db->quote($cart->virtuemart_shipmentmethod_id));

        $db->setQuery($query);
        $result = $db->loadResult();
        $params = $result ? json_decode($result) : null;

        if (!empty($prices['codFee']) && $params && isset($params->codPayment) && $paymentId === $params->codPayment) {
            $currency = CurrencyDisplay::getInstance();
            $cost = ' (' . $paymentMethod->payment_name . ' +' . $currency->priceDisplay($prices['codFee'] + $prices['codFeeDPH']) . ')';
        }
        if ($plugin->shipment_cost == 0) {
            $cost = ' <span class="vmshipment_cost fee"><strong>' . Text::_('PLG_VMSHIPMENT_PPLSHIPPING_FREE_PRICE_TAG') . '</strong></span>';
        }

        $return = $return
            . '<img src="' . htmlspecialchars($img) . '" style= "height: 1em;">'
            . '<span class="' . $this->_type . '_name">'
            . $plugin->{$plugin_name}
            . '</span>'
//            . $description
            . $cost;

        return $return;
    }
}

// No closing tag