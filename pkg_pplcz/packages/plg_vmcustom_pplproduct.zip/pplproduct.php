<?php

use PPLCZ\Admin\Product\Tab;
use PPLCZ\Admin\Category\CategoryPanel;

defined('_JEXEC') or die;

// VirtueMart custom plugin base class
if (!class_exists('vmCustomPlugin')) {
    require(JPATH_VM_PLUGINS . DS . 'vmcustomplugin.php');
}

require_once JPATH_ADMINISTRATOR . "/components/com_pplcz/core/autoloader.php";
require_once JPATH_ADMINISTRATOR . '/components/com_pplcz/core/globals.php';

class plgVmCustomPplproduct extends vmCustomPlugin
{
    function __construct(&$subject, $config)
    {
        parent::__construct($subject, $config);
    }

    /**
     * Event volaný PO uložení produktu
     * @param array $data - data produktu
     * @param object $product_data - product objekt
     */
    public function plgVmAfterStoreProduct(&$data, &$product_data)
    {
        Tab::save($product_data->virtuemart_product_id);
    }

    /**
     * Event volaný PO uložení kategorie
     * @param array $data - data kategorie
     * @param object $category_data - category table objekt
     */
    public function plgVmAfterStoreCategory(&$data, &$category_data)
    {
        CategoryPanel::Save($category_data->virtuemart_category_id);
    }
}