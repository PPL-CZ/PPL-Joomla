# PPLCZCPL\VersionInformationApi

All URIs are relative to http://localhost.

Method | HTTP request | Description
------------- | ------------- | -------------
[**versionInformationGet()**](VersionInformationApi.md#versionInformationGet) | **GET** /versionInformation | Metoda slouží k získávání novinek, informací, plánované odstávky a další důležité informace vztahující se k (nejen) CPL.


## `versionInformationGet()`

```php
versionInformationGet($limit, $offset, $accept_language, $x_correlation_id, $x_log_level): \PPLCZCPL\Model\EpsApiMyApi2BusinessDtoVersionInformationVersionInformationDto[]
```

Metoda slouží k získávání novinek, informací, plánované odstávky a další důležité informace vztahující se k (nejen) CPL.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer (JWT) authorization: Bearer
$config = PPLCZCPL\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new PPLCZCPL\Api\VersionInformationApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$limit = 56; // int
$offset = 56; // int
$accept_language = 'accept_language_example'; // string | Language specification, default language: cs-CZ
$x_correlation_id = 'x_correlation_id_example'; // string | Correlation Id of request
$x_log_level = new \PPLCZCPL\Model\XLogLevelSchema(); // XLogLevelSchema | The forced log level

try {
    $result = $apiInstance->versionInformationGet($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling VersionInformationApi->versionInformationGet: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int**|  |
 **offset** | **int**|  |
 **accept_language** | **string**| Language specification, default language: cs-CZ | [optional]
 **x_correlation_id** | **string**| Correlation Id of request | [optional]
 **x_log_level** | [**XLogLevelSchema**](../Model/.md)| The forced log level | [optional]

### Return type

[**\PPLCZCPL\Model\EpsApiMyApi2BusinessDtoVersionInformationVersionInformationDto[]**](../Model/EpsApiMyApi2BusinessDtoVersionInformationVersionInformationDto.md)

### Authorization

[Bearer](../../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`, `text/json`, `application/problem+json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)
