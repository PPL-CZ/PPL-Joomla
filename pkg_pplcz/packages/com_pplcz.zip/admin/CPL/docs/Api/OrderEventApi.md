# PPLCZCPL\OrderEventApi

All URIs are relative to http://localhost.

Method | HTTP request | Description
------------- | ------------- | -------------
[**orderCancelPost()**](OrderEventApi.md#orderCancelPost) | **POST** /order/cancel | Zrušení objednání svozu nebo balíku z libovolné adresy


## `orderCancelPost()`

```php
orderCancelPost($customer_reference, $order_reference, $accept_language, $x_correlation_id, $x_log_level, $eps_api_my_api2_web_models_order_event_cancel_order_event_model)
```

Zrušení objednání svozu nebo balíku z libovolné adresy

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer (JWT) authorization: Bearer
$config = PPLCZCPL\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new PPLCZCPL\Api\OrderEventApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$customer_reference = 'customer_reference_example'; // string | Reference odesílatele
$order_reference = 'order_reference_example'; // string | Reference objednávky
$accept_language = 'accept_language_example'; // string | Language specification, default language: cs-CZ
$x_correlation_id = 'x_correlation_id_example'; // string | Correlation Id of request
$x_log_level = new \PPLCZCPL\Model\XLogLevelSchema(); // XLogLevelSchema | The forced log level
$eps_api_my_api2_web_models_order_event_cancel_order_event_model = new \PPLCZCPL\Model\EpsApiMyApi2WebModelsOrderEventCancelOrderEventModel(); // \PPLCZCPL\Model\EpsApiMyApi2WebModelsOrderEventCancelOrderEventModel | Event detail

try {
    $apiInstance->orderCancelPost($customer_reference, $order_reference, $accept_language, $x_correlation_id, $x_log_level, $eps_api_my_api2_web_models_order_event_cancel_order_event_model);
} catch (Exception $e) {
    echo 'Exception when calling OrderEventApi->orderCancelPost: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **customer_reference** | **string**| Reference odesílatele | [optional]
 **order_reference** | **string**| Reference objednávky | [optional]
 **accept_language** | **string**| Language specification, default language: cs-CZ | [optional]
 **x_correlation_id** | **string**| Correlation Id of request | [optional]
 **x_log_level** | [**XLogLevelSchema**](../Model/.md)| The forced log level | [optional]
 **eps_api_my_api2_web_models_order_event_cancel_order_event_model** | [**\PPLCZCPL\Model\EpsApiMyApi2WebModelsOrderEventCancelOrderEventModel**](../Model/EpsApiMyApi2WebModelsOrderEventCancelOrderEventModel.md)| Event detail | [optional]

### Return type

void (empty response body)

### Authorization

[Bearer](../../README.md#Bearer)

### HTTP request headers

- **Content-Type**: `application/json-patch+json`, `application/json`, `text/json`, `application/*+json`
- **Accept**: `application/problem+json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)
