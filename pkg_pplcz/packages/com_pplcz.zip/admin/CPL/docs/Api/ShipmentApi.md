# PPLCZCPL\ShipmentApi

All URIs are relative to http://localhost.

Method | HTTP request | Description
------------- | ------------- | -------------
[**shipmentGet()**](ShipmentApi.md#shipmentGet) | **GET** /shipment | Slouží k získání informací (trackingu) k zásilce


## `shipmentGet()`

```php
shipmentGet($limit, $offset, $shipment_numbers, $invoice_numbers, $customer_references, $variable_symbols, $date_from, $date_to, $shipment_states, $accept_language, $x_correlation_id, $x_log_level): \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentShipmentModel[]
```

Slouží k získání informací (trackingu) k zásilce

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer (JWT) authorization: Bearer
$config = PPLCZCPL\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new PPLCZCPL\Api\ShipmentApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$limit = 56; // int
$offset = 56; // int
$shipment_numbers = array('shipment_numbers_example'); // string[] | ShipmentNumbers
$invoice_numbers = array('invoice_numbers_example'); // string[] | InvoiceNumbers
$customer_references = array('customer_references_example'); // string[] | CustomerReferences
$variable_symbols = array('variable_symbols_example'); // string[] | VariableSymbols
$date_from = new \DateTime("2013-10-20T19:20:30+01:00"); // \DateTime | DateFrom
$date_to = new \DateTime("2013-10-20T19:20:30+01:00"); // \DateTime | DateTo
$shipment_states = new \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentShipmentStates(); // EpsApiMyApi2WebModelsShipmentShipmentStates | ShipmentStates
$accept_language = 'accept_language_example'; // string | Language specification, default language: cs-CZ
$x_correlation_id = 'x_correlation_id_example'; // string | Correlation Id of request
$x_log_level = new \PPLCZCPL\Model\XLogLevelSchema(); // XLogLevelSchema | The forced log level

try {
    $result = $apiInstance->shipmentGet($limit, $offset, $shipment_numbers, $invoice_numbers, $customer_references, $variable_symbols, $date_from, $date_to, $shipment_states, $accept_language, $x_correlation_id, $x_log_level);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ShipmentApi->shipmentGet: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int**|  |
 **offset** | **int**|  |
 **shipment_numbers** | [**string[]**](../Model/string.md)| ShipmentNumbers | [optional]
 **invoice_numbers** | [**string[]**](../Model/string.md)| InvoiceNumbers | [optional]
 **customer_references** | [**string[]**](../Model/string.md)| CustomerReferences | [optional]
 **variable_symbols** | [**string[]**](../Model/string.md)| VariableSymbols | [optional]
 **date_from** | **\DateTime**| DateFrom | [optional]
 **date_to** | **\DateTime**| DateTo | [optional]
 **shipment_states** | [**EpsApiMyApi2WebModelsShipmentShipmentStates**](../Model/.md)| ShipmentStates | [optional]
 **accept_language** | **string**| Language specification, default language: cs-CZ | [optional]
 **x_correlation_id** | **string**| Correlation Id of request | [optional]
 **x_log_level** | [**XLogLevelSchema**](../Model/.md)| The forced log level | [optional]

### Return type

[**\PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentShipmentModel[]**](../Model/EpsApiMyApi2WebModelsShipmentShipmentModel.md)

### Authorization

[Bearer](../../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`, `text/json`, `application/problem+json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)
