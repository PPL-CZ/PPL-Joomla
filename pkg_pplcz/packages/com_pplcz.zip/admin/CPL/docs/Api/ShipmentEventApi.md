# PPLCZCPL\ShipmentEventApi

All URIs are relative to http://localhost.

Method | HTTP request | Description
------------- | ------------- | -------------
[**shipmentShipmentNumberCancelPost()**](ShipmentEventApi.md#shipmentShipmentNumberCancelPost) | **POST** /shipment/{shipmentNumber}/cancel | Možnost stornovat balík, pokud nebyl fyzicky poslán
[**shipmentShipmentNumberRedirectPost()**](ShipmentEventApi.md#shipmentShipmentNumberRedirectPost) | **POST** /shipment/{shipmentNumber}/redirect | Možnost doplnit informace k balíku


## `shipmentShipmentNumberCancelPost()`

```php
shipmentShipmentNumberCancelPost($shipment_number, $accept_language, $x_correlation_id, $x_log_level)
```

Možnost stornovat balík, pokud nebyl fyzicky poslán

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer (JWT) authorization: Bearer
$config = PPLCZCPL\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new PPLCZCPL\Api\ShipmentEventApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$shipment_number = 'shipment_number_example'; // string | 
$accept_language = 'accept_language_example'; // string | Language specification, default language: cs-CZ
$x_correlation_id = 'x_correlation_id_example'; // string | Correlation Id of request
$x_log_level = new \PPLCZCPL\Model\XLogLevelSchema(); // XLogLevelSchema | The forced log level

try {
    $apiInstance->shipmentShipmentNumberCancelPost($shipment_number, $accept_language, $x_correlation_id, $x_log_level);
} catch (Exception $e) {
    echo 'Exception when calling ShipmentEventApi->shipmentShipmentNumberCancelPost: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shipment_number** | **string**|  |
 **accept_language** | **string**| Language specification, default language: cs-CZ | [optional]
 **x_correlation_id** | **string**| Correlation Id of request | [optional]
 **x_log_level** | [**XLogLevelSchema**](../Model/.md)| The forced log level | [optional]

### Return type

void (empty response body)

### Authorization

[Bearer](../../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/problem+json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `shipmentShipmentNumberRedirectPost()`

```php
shipmentShipmentNumberRedirectPost($shipment_number, $accept_language, $x_correlation_id, $x_log_level, $eps_api_my_api2_web_models_shipment_event_redirect_shipment_event_model)
```

Možnost doplnit informace k balíku

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer (JWT) authorization: Bearer
$config = PPLCZCPL\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new PPLCZCPL\Api\ShipmentEventApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$shipment_number = 'shipment_number_example'; // string | 
$accept_language = 'accept_language_example'; // string | Language specification, default language: cs-CZ
$x_correlation_id = 'x_correlation_id_example'; // string | Correlation Id of request
$x_log_level = new \PPLCZCPL\Model\XLogLevelSchema(); // XLogLevelSchema | The forced log level
$eps_api_my_api2_web_models_shipment_event_redirect_shipment_event_model = new \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentEventRedirectShipmentEventModel(); // \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentEventRedirectShipmentEventModel | 

try {
    $apiInstance->shipmentShipmentNumberRedirectPost($shipment_number, $accept_language, $x_correlation_id, $x_log_level, $eps_api_my_api2_web_models_shipment_event_redirect_shipment_event_model);
} catch (Exception $e) {
    echo 'Exception when calling ShipmentEventApi->shipmentShipmentNumberRedirectPost: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shipment_number** | **string**|  |
 **accept_language** | **string**| Language specification, default language: cs-CZ | [optional]
 **x_correlation_id** | **string**| Correlation Id of request | [optional]
 **x_log_level** | [**XLogLevelSchema**](../Model/.md)| The forced log level | [optional]
 **eps_api_my_api2_web_models_shipment_event_redirect_shipment_event_model** | [**\PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentEventRedirectShipmentEventModel**](../Model/EpsApiMyApi2WebModelsShipmentEventRedirectShipmentEventModel.md)|  | [optional]

### Return type

void (empty response body)

### Authorization

[Bearer](../../README.md#Bearer)

### HTTP request headers

- **Content-Type**: `application/json-patch+json`, `application/json`, `text/json`, `application/*+json`
- **Accept**: `application/problem+json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)
