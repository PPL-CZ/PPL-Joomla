# PPLCZCPL\OrderApi

All URIs are relative to http://localhost.

Method | HTTP request | Description
------------- | ------------- | -------------
[**orderGet()**](OrderApi.md#orderGet) | **GET** /order | Sledování stavu objednávek


## `orderGet()`

```php
orderGet($limit, $offset, $shipment_numbers, $customer_references, $order_references, $order_numbers, $order_ids, $date_from, $date_to, $send_date, $product_type, $order_states, $accept_language, $x_correlation_id, $x_log_level): \PPLCZCPL\Model\EpsApiMyApi2WebModelsOrderOrderModel
```

Sledování stavu objednávek

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer (JWT) authorization: Bearer
$config = PPLCZCPL\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new PPLCZCPL\Api\OrderApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$limit = 56; // int
$offset = 56; // int
$shipment_numbers = array('shipment_numbers_example'); // string[] | Číslo/čísla balíků
$customer_references = array('customer_references_example'); // string[] | Reference odesílatele
$order_references = array('order_references_example'); // string[] | Reference objednávky
$order_numbers = array('order_numbers_example'); // string[] | Číslo objednávky
$order_ids = array(56); // int[] | ID objednávky
$date_from = new \DateTime("2013-10-20T19:20:30+01:00"); // \DateTime | Datum od
$date_to = new \DateTime("2013-10-20T19:20:30+01:00"); // \DateTime | Datum do
$send_date = new \DateTime("2013-10-20T19:20:30+01:00"); // \DateTime | Datum odeslání
$product_type = 'product_type_example'; // string | Typ produktu
$order_states = new \PPLCZCPL\Model\EpsApiMyApi2WebModelsEnumOrderStates(); // EpsApiMyApi2WebModelsEnumOrderStates | Stav objednávky
$accept_language = 'accept_language_example'; // string | Language specification, default language: cs-CZ
$x_correlation_id = 'x_correlation_id_example'; // string | Correlation Id of request
$x_log_level = new \PPLCZCPL\Model\XLogLevelSchema(); // XLogLevelSchema | The forced log level

try {
    $result = $apiInstance->orderGet($limit, $offset, $shipment_numbers, $customer_references, $order_references, $order_numbers, $order_ids, $date_from, $date_to, $send_date, $product_type, $order_states, $accept_language, $x_correlation_id, $x_log_level);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OrderApi->orderGet: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int**|  |
 **offset** | **int**|  |
 **shipment_numbers** | [**string[]**](../Model/string.md)| Číslo/čísla balíků | [optional]
 **customer_references** | [**string[]**](../Model/string.md)| Reference odesílatele | [optional]
 **order_references** | [**string[]**](../Model/string.md)| Reference objednávky | [optional]
 **order_numbers** | [**string[]**](../Model/string.md)| Číslo objednávky | [optional]
 **order_ids** | [**int[]**](../Model/int.md)| ID objednávky | [optional]
 **date_from** | **\DateTime**| Datum od | [optional]
 **date_to** | **\DateTime**| Datum do | [optional]
 **send_date** | **\DateTime**| Datum odeslání | [optional]
 **product_type** | **string**| Typ produktu | [optional]
 **order_states** | [**EpsApiMyApi2WebModelsEnumOrderStates**](../Model/.md)| Stav objednávky | [optional]
 **accept_language** | **string**| Language specification, default language: cs-CZ | [optional]
 **x_correlation_id** | **string**| Correlation Id of request | [optional]
 **x_log_level** | [**XLogLevelSchema**](../Model/.md)| The forced log level | [optional]

### Return type

[**\PPLCZCPL\Model\EpsApiMyApi2WebModelsOrderOrderModel**](../Model/EpsApiMyApi2WebModelsOrderOrderModel.md)

### Authorization

[Bearer](../../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`, `text/json`, `application/problem+json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)
