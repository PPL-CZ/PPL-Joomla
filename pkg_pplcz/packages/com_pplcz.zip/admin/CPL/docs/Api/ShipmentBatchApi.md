# PPLCZCPL\ShipmentBatchApi

All URIs are relative to http://localhost.

Method | HTTP request | Description
------------- | ------------- | -------------
[**createShipments()**](ShipmentBatchApi.md#createShipments) | **POST** /shipment/batch | Slouží k vytvoření zásilky. Odpověď je v header (Location)
[**getShipmentBatch()**](ShipmentBatchApi.md#getShipmentBatch) | **GET** /shipment/batch/{batchId} | Slouží k získání stavu importu zásilky
[**getShipmentBatchLabel()**](ShipmentBatchApi.md#getShipmentBatchLabel) | **GET** /shipment/batch/{batchId}/label | BatchId z předchozí metody. Odpovědí je URL (hromadné nebo k jednotlivému balíku) pro stažení vygenerované etikety.
[**updateShipmentBatch()**](ShipmentBatchApi.md#updateShipmentBatch) | **PUT** /shipment/batch/{batchId} | Slouží k úpravě sady zásilek


## `createShipments()`

```php
createShipments($eps_api_my_api2_web_models_shipment_batch_create_shipment_batch_model, $accept_language, $x_correlation_id, $x_log_level)
```

Slouží k vytvoření zásilky. Odpověď je v header (Location)

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer (JWT) authorization: Bearer
$config = PPLCZCPL\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new PPLCZCPL\Api\ShipmentBatchApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$eps_api_my_api2_web_models_shipment_batch_create_shipment_batch_model = {"labelSettings":{"format":"Pdf","completeLabelSettings":{"isCompleteLabelRequested":true,"pageSize":"A4"}},"shipments":[{"referenceId":"27c92d31-2a18-4fc3-a388-bee64edfdafb","productType":"BUSS","sender":{"street":"Novoveská 1262/95","city":"Ostrava","zipCode":"70900","country":"CZ","phone":"+420777888999","email":"sender@email.cz"},"recipient":{"street":"Františka a Anny Ryšových 1168","city":"Ostrava-Svinov","zipCode":"72100","country":"CZ","phone":"+420666777888","email":"recipient@email.cz"}}],"shipmentsOrderBy":"ShipmentNumber"}; // \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchCreateShipmentBatchModel | The request data
$accept_language = 'accept_language_example'; // string | Language specification, default language: cs-CZ
$x_correlation_id = 'x_correlation_id_example'; // string | Correlation Id of request
$x_log_level = new \PPLCZCPL\Model\XLogLevelSchema(); // XLogLevelSchema | The forced log level

try {
    $apiInstance->createShipments($eps_api_my_api2_web_models_shipment_batch_create_shipment_batch_model, $accept_language, $x_correlation_id, $x_log_level);
} catch (Exception $e) {
    echo 'Exception when calling ShipmentBatchApi->createShipments: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **eps_api_my_api2_web_models_shipment_batch_create_shipment_batch_model** | [**\PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchCreateShipmentBatchModel**](../Model/EpsApiMyApi2WebModelsShipmentBatchCreateShipmentBatchModel.md)| The request data |
 **accept_language** | **string**| Language specification, default language: cs-CZ | [optional]
 **x_correlation_id** | **string**| Correlation Id of request | [optional]
 **x_log_level** | [**XLogLevelSchema**](../Model/.md)| The forced log level | [optional]

### Return type

void (empty response body)

### Authorization

[Bearer](../../README.md#Bearer)

### HTTP request headers

- **Content-Type**: `application/json-patch+json`, `application/json`, `text/json`, `application/*+json`
- **Accept**: `application/problem+json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `getShipmentBatch()`

```php
getShipmentBatch($batch_id, $accept_language, $x_correlation_id, $x_log_level, $order_by): \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentBatchResultModel
```

Slouží k získání stavu importu zásilky

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer (JWT) authorization: Bearer
$config = PPLCZCPL\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new PPLCZCPL\Api\ShipmentBatchApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$batch_id = 'batch_id_example'; // string | The batch id
$accept_language = 'accept_language_example'; // string | Language specification, default language: cs-CZ
$x_correlation_id = 'x_correlation_id_example'; // string | Correlation Id of request
$x_log_level = new \PPLCZCPL\Model\XLogLevelSchema(); // XLogLevelSchema | The forced log level
$order_by = new \PPLCZCPL\Model\GetShipmentBatchOrderByParameter(); // GetShipmentBatchOrderByParameter | Sort items by defined fields. For multiple sorting use field names separated by comma. Use \"-\" to descendant order (eg.: OrderBy=field1,-field2).  Orderable fields: **ShipmentNumber, ReferenceId**, see also schema **Eps.Api.MyApi2.Web.Controllers.ShipmentBatchController.GetShipmentBatch.OrderBy.enum**

try {
    $result = $apiInstance->getShipmentBatch($batch_id, $accept_language, $x_correlation_id, $x_log_level, $order_by);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ShipmentBatchApi->getShipmentBatch: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **batch_id** | **string**| The batch id |
 **accept_language** | **string**| Language specification, default language: cs-CZ | [optional]
 **x_correlation_id** | **string**| Correlation Id of request | [optional]
 **x_log_level** | [**XLogLevelSchema**](../Model/.md)| The forced log level | [optional]
 **order_by** | [**GetShipmentBatchOrderByParameter**](../Model/.md)| Sort items by defined fields. For multiple sorting use field names separated by comma. Use \&quot;-\&quot; to descendant order (eg.: OrderBy&#x3D;field1,-field2).  Orderable fields: **ShipmentNumber, ReferenceId**, see also schema **Eps.Api.MyApi2.Web.Controllers.ShipmentBatchController.GetShipmentBatch.OrderBy.enum** | [optional]

### Return type

[**\PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentBatchResultModel**](../Model/EpsApiMyApi2WebModelsShipmentBatchShipmentBatchResultModel.md)

### Authorization

[Bearer](../../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`, `text/json`, `application/problem+json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `getShipmentBatchLabel()`

```php
getShipmentBatchLabel($batch_id, $limit, $offset, $page_size, $position, $accept_language, $x_correlation_id, $x_log_level, $order_by): \SplFileObject
```

BatchId z předchozí metody. Odpovědí je URL (hromadné nebo k jednotlivému balíku) pro stažení vygenerované etikety.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer (JWT) authorization: Bearer
$config = PPLCZCPL\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new PPLCZCPL\Api\ShipmentBatchApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$batch_id = 'batch_id_example'; // string | The batch id
$limit = 56; // int | The limit
$offset = 56; // int | The offset
$page_size = new \PPLCZCPL\Model\EpsApiMyApi2BusinessEnumsConstPageSize(); // EpsApiMyApi2BusinessEnumsConstPageSize | PageSize
$position = 56; // int | Position
$accept_language = 'accept_language_example'; // string | Language specification, default language: cs-CZ
$x_correlation_id = 'x_correlation_id_example'; // string | Correlation Id of request
$x_log_level = new \PPLCZCPL\Model\XLogLevelSchema(); // XLogLevelSchema | The forced log level
$order_by = new \PPLCZCPL\Model\GetShipmentBatchLabelOrderByParameter(); // GetShipmentBatchLabelOrderByParameter | Sort items by defined fields. For multiple sorting use field names separated by comma. Use \"-\" to descendant order (eg.: OrderBy=field1,-field2).  Orderable fields: **ShipmentNumber, ReferenceId**, see also schema **Eps.Api.MyApi2.Web.Controllers.ShipmentBatchController.GetShipmentBatchLabel.OrderBy.enum**

try {
    $result = $apiInstance->getShipmentBatchLabel($batch_id, $limit, $offset, $page_size, $position, $accept_language, $x_correlation_id, $x_log_level, $order_by);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ShipmentBatchApi->getShipmentBatchLabel: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **batch_id** | **string**| The batch id |
 **limit** | **int**| The limit |
 **offset** | **int**| The offset |
 **page_size** | [**EpsApiMyApi2BusinessEnumsConstPageSize**](../Model/.md)| PageSize | [optional]
 **position** | **int**| Position | [optional]
 **accept_language** | **string**| Language specification, default language: cs-CZ | [optional]
 **x_correlation_id** | **string**| Correlation Id of request | [optional]
 **x_log_level** | [**XLogLevelSchema**](../Model/.md)| The forced log level | [optional]
 **order_by** | [**GetShipmentBatchLabelOrderByParameter**](../Model/.md)| Sort items by defined fields. For multiple sorting use field names separated by comma. Use \&quot;-\&quot; to descendant order (eg.: OrderBy&#x3D;field1,-field2).  Orderable fields: **ShipmentNumber, ReferenceId**, see also schema **Eps.Api.MyApi2.Web.Controllers.ShipmentBatchController.GetShipmentBatchLabel.OrderBy.enum** | [optional]

### Return type

**\SplFileObject**

### Authorization

[Bearer](../../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`, `text/json`, `application/problem+json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `updateShipmentBatch()`

```php
updateShipmentBatch($batch_id, $eps_api_my_api2_web_models_shipment_batch_update_shipment_batch_model, $accept_language, $x_correlation_id, $x_log_level)
```

Slouží k úpravě sady zásilek

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer (JWT) authorization: Bearer
$config = PPLCZCPL\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new PPLCZCPL\Api\ShipmentBatchApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$batch_id = 'batch_id_example'; // string | The batch id
$eps_api_my_api2_web_models_shipment_batch_update_shipment_batch_model = {"labelSettings":{"format":"Pdf","completeLabelSettings":{"isCompleteLabelRequested":true,"pageSize":"A4"}}}; // \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchUpdateShipmentBatchModel | The request data
$accept_language = 'accept_language_example'; // string | Language specification, default language: cs-CZ
$x_correlation_id = 'x_correlation_id_example'; // string | Correlation Id of request
$x_log_level = new \PPLCZCPL\Model\XLogLevelSchema(); // XLogLevelSchema | The forced log level

try {
    $apiInstance->updateShipmentBatch($batch_id, $eps_api_my_api2_web_models_shipment_batch_update_shipment_batch_model, $accept_language, $x_correlation_id, $x_log_level);
} catch (Exception $e) {
    echo 'Exception when calling ShipmentBatchApi->updateShipmentBatch: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **batch_id** | **string**| The batch id |
 **eps_api_my_api2_web_models_shipment_batch_update_shipment_batch_model** | [**\PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchUpdateShipmentBatchModel**](../Model/EpsApiMyApi2WebModelsShipmentBatchUpdateShipmentBatchModel.md)| The request data |
 **accept_language** | **string**| Language specification, default language: cs-CZ | [optional]
 **x_correlation_id** | **string**| Correlation Id of request | [optional]
 **x_log_level** | [**XLogLevelSchema**](../Model/.md)| The forced log level | [optional]

### Return type

void (empty response body)

### Authorization

[Bearer](../../README.md#Bearer)

### HTTP request headers

- **Content-Type**: `application/json-patch+json`, `application/json`, `text/json`, `application/*+json`
- **Accept**: `application/problem+json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)
