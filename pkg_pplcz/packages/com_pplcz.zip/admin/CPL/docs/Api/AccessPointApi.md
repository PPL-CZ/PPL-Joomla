# PPLCZCPL\AccessPointApi

All URIs are relative to http://localhost.

Method | HTTP request | Description
------------- | ------------- | -------------
[**accessPointGet()**](AccessPointApi.md#accessPointGet) | **GET** /accessPoint | Seznam výdejních míst


## `accessPointGet()`

```php
accessPointGet($limit, $offset, $access_point_code, $country_code, $zip_code, $city, $access_point_types, $radius, $latitude, $longitude, $tribal_service_point, $active_card_payment, $active_cash_payment, $pickup_enabled, $sizes, $accept_language, $x_correlation_id, $x_log_level): \PPLCZCPL\Model\EpsApiMyApi2WebModelsAccessPointAccessPointModel[]
```

Seznam výdejních míst

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer (JWT) authorization: Bearer
$config = PPLCZCPL\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new PPLCZCPL\Api\AccessPointApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$limit = 56; // int
$offset = 56; // int
$access_point_code = 'access_point_code_example'; // string | Kód Výdejního místa
$country_code = 'country_code_example'; // string | kód země viz. /codelist/country
$zip_code = 'zip_code_example'; // string | PSČ
$city = 'city_example'; // string | Město
$access_point_types = array(new \PPLCZCPL\Model\\PPLCZCPL\Model\EpsApiMyApi2WebModelsAccessPointConstMyApi2AccessPointType()); // \PPLCZCPL\Model\EpsApiMyApi2WebModelsAccessPointConstMyApi2AccessPointType[] | Typ výdejního místa
$radius = 56; // int | Rádius (km)
$latitude = 3.4; // double | GPS souřanice
$longitude = 3.4; // double | GPS souřanice
$tribal_service_point = True; // bool | Kmenové výdejní místo
$active_card_payment = True; // bool | Možnost platby kartou
$active_cash_payment = True; // bool | Možnost platby v hotovosti
$pickup_enabled = True; // bool | Možnost podání zásilky
$sizes = array('sizes_example'); // string[] | Maximální hodnoty velikosti balíku: S,M,L,XL
$accept_language = 'accept_language_example'; // string | Language specification, default language: cs-CZ
$x_correlation_id = 'x_correlation_id_example'; // string | Correlation Id of request
$x_log_level = new \PPLCZCPL\Model\XLogLevelSchema(); // XLogLevelSchema | The forced log level

try {
    $result = $apiInstance->accessPointGet($limit, $offset, $access_point_code, $country_code, $zip_code, $city, $access_point_types, $radius, $latitude, $longitude, $tribal_service_point, $active_card_payment, $active_cash_payment, $pickup_enabled, $sizes, $accept_language, $x_correlation_id, $x_log_level);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AccessPointApi->accessPointGet: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int**|  |
 **offset** | **int**|  |
 **access_point_code** | **string**| Kód Výdejního místa | [optional]
 **country_code** | **string**| kód země viz. /codelist/country | [optional]
 **zip_code** | **string**| PSČ | [optional]
 **city** | **string**| Město | [optional]
 **access_point_types** | [**\PPLCZCPL\Model\EpsApiMyApi2WebModelsAccessPointConstMyApi2AccessPointType[]**](../Model/\PPLCZCPL\Model\EpsApiMyApi2WebModelsAccessPointConstMyApi2AccessPointType.md)| Typ výdejního místa | [optional]
 **radius** | **int**| Rádius (km) | [optional]
 **latitude** | **double**| GPS souřanice | [optional]
 **longitude** | **double**| GPS souřanice | [optional]
 **tribal_service_point** | **bool**| Kmenové výdejní místo | [optional]
 **active_card_payment** | **bool**| Možnost platby kartou | [optional]
 **active_cash_payment** | **bool**| Možnost platby v hotovosti | [optional]
 **pickup_enabled** | **bool**| Možnost podání zásilky | [optional]
 **sizes** | [**string[]**](../Model/string.md)| Maximální hodnoty velikosti balíku: S,M,L,XL | [optional]
 **accept_language** | **string**| Language specification, default language: cs-CZ | [optional]
 **x_correlation_id** | **string**| Correlation Id of request | [optional]
 **x_log_level** | [**XLogLevelSchema**](../Model/.md)| The forced log level | [optional]

### Return type

[**\PPLCZCPL\Model\EpsApiMyApi2WebModelsAccessPointAccessPointModel[]**](../Model/EpsApiMyApi2WebModelsAccessPointAccessPointModel.md)

### Authorization

[Bearer](../../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`, `text/json`, `application/problem+json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)
