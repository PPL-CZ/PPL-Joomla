# PPLCZCPL\OrderBatchApi

All URIs are relative to http://localhost.

Method | HTTP request | Description
------------- | ------------- | -------------
[**createOrders()**](OrderBatchApi.md#createOrders) | **POST** /order/batch | Slouží k vytvoření objednávky. Odpověď je v header (Location)
[**getOrderBatch()**](OrderBatchApi.md#getOrderBatch) | **GET** /order/batch/{batchId} | BatchId z předchozí metody. Odpovědí je informace o úspěšném vygenerování objednávky.


## `createOrders()`

```php
createOrders($eps_api_my_api2_web_models_order_batch_create_order_batch_model, $accept_language, $x_correlation_id, $x_log_level)
```

Slouží k vytvoření objednávky. Odpověď je v header (Location)

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer (JWT) authorization: Bearer
$config = PPLCZCPL\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new PPLCZCPL\Api\OrderBatchApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$eps_api_my_api2_web_models_order_batch_create_order_batch_model = new \PPLCZCPL\Model\EpsApiMyApi2WebModelsOrderBatchCreateOrderBatchModel(); // \PPLCZCPL\Model\EpsApiMyApi2WebModelsOrderBatchCreateOrderBatchModel | The request data
$accept_language = 'accept_language_example'; // string | Language specification, default language: cs-CZ
$x_correlation_id = 'x_correlation_id_example'; // string | Correlation Id of request
$x_log_level = new \PPLCZCPL\Model\XLogLevelSchema(); // XLogLevelSchema | The forced log level

try {
    $apiInstance->createOrders($eps_api_my_api2_web_models_order_batch_create_order_batch_model, $accept_language, $x_correlation_id, $x_log_level);
} catch (Exception $e) {
    echo 'Exception when calling OrderBatchApi->createOrders: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **eps_api_my_api2_web_models_order_batch_create_order_batch_model** | [**\PPLCZCPL\Model\EpsApiMyApi2WebModelsOrderBatchCreateOrderBatchModel**](../Model/EpsApiMyApi2WebModelsOrderBatchCreateOrderBatchModel.md)| The request data |
 **accept_language** | **string**| Language specification, default language: cs-CZ | [optional]
 **x_correlation_id** | **string**| Correlation Id of request | [optional]
 **x_log_level** | [**XLogLevelSchema**](../Model/.md)| The forced log level | [optional]

### Return type

void (empty response body)

### Authorization

[Bearer](../../README.md#Bearer)

### HTTP request headers

- **Content-Type**: `application/json-patch+json`, `application/json`, `text/json`, `application/*+json`
- **Accept**: `application/problem+json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `getOrderBatch()`

```php
getOrderBatch($batch_id, $accept_language, $x_correlation_id, $x_log_level): \PPLCZCPL\Model\EpsApiMyApi2WebModelsOrderBatchOrderBatchResultModel
```

BatchId z předchozí metody. Odpovědí je informace o úspěšném vygenerování objednávky.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer (JWT) authorization: Bearer
$config = PPLCZCPL\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new PPLCZCPL\Api\OrderBatchApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$batch_id = 'batch_id_example'; // string | The batch id
$accept_language = 'accept_language_example'; // string | Language specification, default language: cs-CZ
$x_correlation_id = 'x_correlation_id_example'; // string | Correlation Id of request
$x_log_level = new \PPLCZCPL\Model\XLogLevelSchema(); // XLogLevelSchema | The forced log level

try {
    $result = $apiInstance->getOrderBatch($batch_id, $accept_language, $x_correlation_id, $x_log_level);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OrderBatchApi->getOrderBatch: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **batch_id** | **string**| The batch id |
 **accept_language** | **string**| Language specification, default language: cs-CZ | [optional]
 **x_correlation_id** | **string**| Correlation Id of request | [optional]
 **x_log_level** | [**XLogLevelSchema**](../Model/.md)| The forced log level | [optional]

### Return type

[**\PPLCZCPL\Model\EpsApiMyApi2WebModelsOrderBatchOrderBatchResultModel**](../Model/EpsApiMyApi2WebModelsOrderBatchOrderBatchResultModel.md)

### Authorization

[Bearer](../../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`, `text/json`, `application/problem+json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)
