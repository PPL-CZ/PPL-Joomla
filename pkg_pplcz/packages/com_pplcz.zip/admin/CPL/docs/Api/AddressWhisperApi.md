# PPLCZCPL\AddressWhisperApi

All URIs are relative to http://localhost.

Method | HTTP request | Description
------------- | ------------- | -------------
[**addressWhisperGet()**](AddressWhisperApi.md#addressWhisperGet) | **GET** /addressWhisper | Našeptávač adres


## `addressWhisperGet()`

```php
addressWhisperGet($street, $zip_code, $city, $called_from, $accept_language, $x_correlation_id, $x_log_level): \PPLCZCPL\Model\EpsApiMyApi2WebModelsAddressWhisperAddressWhispModel[]
```

Našeptávač adres

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer (JWT) authorization: Bearer
$config = PPLCZCPL\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new PPLCZCPL\Api\AddressWhisperApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$street = 'street_example'; // string | Street
$zip_code = 'zip_code_example'; // string | Zip code
$city = 'city_example'; // string | City
$called_from = new \PPLCZCPL\Model\EpsApiMyApi2WebModelsAddressWhisperCalledFrom(); // EpsApiMyApi2WebModelsAddressWhisperCalledFrom | Whispering from street / zip code / city text box
$accept_language = 'accept_language_example'; // string | Language specification, default language: cs-CZ
$x_correlation_id = 'x_correlation_id_example'; // string | Correlation Id of request
$x_log_level = new \PPLCZCPL\Model\XLogLevelSchema(); // XLogLevelSchema | The forced log level

try {
    $result = $apiInstance->addressWhisperGet($street, $zip_code, $city, $called_from, $accept_language, $x_correlation_id, $x_log_level);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AddressWhisperApi->addressWhisperGet: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **street** | **string**| Street | [optional]
 **zip_code** | **string**| Zip code | [optional]
 **city** | **string**| City | [optional]
 **called_from** | [**EpsApiMyApi2WebModelsAddressWhisperCalledFrom**](../Model/.md)| Whispering from street / zip code / city text box | [optional]
 **accept_language** | **string**| Language specification, default language: cs-CZ | [optional]
 **x_correlation_id** | **string**| Correlation Id of request | [optional]
 **x_log_level** | [**XLogLevelSchema**](../Model/.md)| The forced log level | [optional]

### Return type

[**\PPLCZCPL\Model\EpsApiMyApi2WebModelsAddressWhisperAddressWhispModel[]**](../Model/EpsApiMyApi2WebModelsAddressWhisperAddressWhispModel.md)

### Authorization

[Bearer](../../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`, `text/json`, `application/problem+json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)
