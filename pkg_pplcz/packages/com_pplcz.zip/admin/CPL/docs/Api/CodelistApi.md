# PPLCZCPL\CodelistApi

All URIs are relative to http://localhost.

Method | HTTP request | Description
------------- | ------------- | -------------
[**codelistAgeCheckGet()**](CodelistApi.md#codelistAgeCheckGet) | **GET** /codelist/ageCheck | Číselník pro službu kontrola věku příjemce
[**codelistCountryGet()**](CodelistApi.md#codelistCountryGet) | **GET** /codelist/country | Číselník zemí + povolení COD
[**codelistCurrencyGet()**](CodelistApi.md#codelistCurrencyGet) | **GET** /codelist/currency | Číselník povolených měn
[**codelistExternalNumberGet()**](CodelistApi.md#codelistExternalNumberGet) | **GET** /codelist/externalNumber | Číselník typu externích čísel
[**codelistProductGet()**](CodelistApi.md#codelistProductGet) | **GET** /codelist/product | Číselník produktů
[**codelistProofOfIdentityTypeGet()**](CodelistApi.md#codelistProofOfIdentityTypeGet) | **GET** /codelist/proofOfIdentityType | Typy osobních dokladů
[**codelistServiceGet()**](CodelistApi.md#codelistServiceGet) | **GET** /codelist/service | Metoda pro získání poskytovaných služeb k zásilkám. Vyskytuje se u shipment/batch nebo /shipment
[**codelistServicePriceLimitGet()**](CodelistApi.md#codelistServicePriceLimitGet) | **GET** /codelist/servicePriceLimit | Metoda pro získání minimálních a maximálních hodnot u služeb
[**codelistShipmentPhaseGet()**](CodelistApi.md#codelistShipmentPhaseGet) | **GET** /codelist/shipmentPhase | Fáze zásilky
[**codelistStatusGet()**](CodelistApi.md#codelistStatusGet) | **GET** /codelist/status | Statusy zásilky /shipment
[**codelistValidationMessageGet()**](CodelistApi.md#codelistValidationMessageGet) | **GET** /codelist/validationMessage | Chybové hlášení.


## `codelistAgeCheckGet()`

```php
codelistAgeCheckGet($limit, $offset, $accept_language, $x_correlation_id, $x_log_level): \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistAgeCheckTypeModel[]
```

Číselník pro službu kontrola věku příjemce

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer (JWT) authorization: Bearer
$config = PPLCZCPL\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new PPLCZCPL\Api\CodelistApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$limit = 56; // int
$offset = 56; // int
$accept_language = 'accept_language_example'; // string | Language specification, default language: cs-CZ
$x_correlation_id = 'x_correlation_id_example'; // string | Correlation Id of request
$x_log_level = new \PPLCZCPL\Model\XLogLevelSchema(); // XLogLevelSchema | The forced log level

try {
    $result = $apiInstance->codelistAgeCheckGet($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CodelistApi->codelistAgeCheckGet: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int**|  |
 **offset** | **int**|  |
 **accept_language** | **string**| Language specification, default language: cs-CZ | [optional]
 **x_correlation_id** | **string**| Correlation Id of request | [optional]
 **x_log_level** | [**XLogLevelSchema**](../Model/.md)| The forced log level | [optional]

### Return type

[**\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistAgeCheckTypeModel[]**](../Model/EpsApiMyApi2WebModelsCodelistAgeCheckTypeModel.md)

### Authorization

[Bearer](../../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`, `text/json`, `application/problem+json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `codelistCountryGet()`

```php
codelistCountryGet($limit, $offset, $accept_language, $x_correlation_id, $x_log_level): \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistCountryModel[]
```

Číselník zemí + povolení COD

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer (JWT) authorization: Bearer
$config = PPLCZCPL\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new PPLCZCPL\Api\CodelistApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$limit = 56; // int
$offset = 56; // int
$accept_language = 'accept_language_example'; // string | Language specification, default language: cs-CZ
$x_correlation_id = 'x_correlation_id_example'; // string | Correlation Id of request
$x_log_level = new \PPLCZCPL\Model\XLogLevelSchema(); // XLogLevelSchema | The forced log level

try {
    $result = $apiInstance->codelistCountryGet($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CodelistApi->codelistCountryGet: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int**|  |
 **offset** | **int**|  |
 **accept_language** | **string**| Language specification, default language: cs-CZ | [optional]
 **x_correlation_id** | **string**| Correlation Id of request | [optional]
 **x_log_level** | [**XLogLevelSchema**](../Model/.md)| The forced log level | [optional]

### Return type

[**\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistCountryModel[]**](../Model/EpsApiMyApi2WebModelsCodelistCountryModel.md)

### Authorization

[Bearer](../../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`, `text/json`, `application/problem+json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `codelistCurrencyGet()`

```php
codelistCurrencyGet($limit, $offset, $accept_language, $x_correlation_id, $x_log_level): \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistCurrencyModel[]
```

Číselník povolených měn

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer (JWT) authorization: Bearer
$config = PPLCZCPL\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new PPLCZCPL\Api\CodelistApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$limit = 56; // int
$offset = 56; // int
$accept_language = 'accept_language_example'; // string | Language specification, default language: cs-CZ
$x_correlation_id = 'x_correlation_id_example'; // string | Correlation Id of request
$x_log_level = new \PPLCZCPL\Model\XLogLevelSchema(); // XLogLevelSchema | The forced log level

try {
    $result = $apiInstance->codelistCurrencyGet($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CodelistApi->codelistCurrencyGet: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int**|  |
 **offset** | **int**|  |
 **accept_language** | **string**| Language specification, default language: cs-CZ | [optional]
 **x_correlation_id** | **string**| Correlation Id of request | [optional]
 **x_log_level** | [**XLogLevelSchema**](../Model/.md)| The forced log level | [optional]

### Return type

[**\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistCurrencyModel[]**](../Model/EpsApiMyApi2WebModelsCodelistCurrencyModel.md)

### Authorization

[Bearer](../../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`, `text/json`, `application/problem+json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `codelistExternalNumberGet()`

```php
codelistExternalNumberGet($limit, $offset, $accept_language, $x_correlation_id, $x_log_level): \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentExternalNumberTypeModel[]
```

Číselník typu externích čísel

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer (JWT) authorization: Bearer
$config = PPLCZCPL\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new PPLCZCPL\Api\CodelistApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$limit = 56; // int
$offset = 56; // int
$accept_language = 'accept_language_example'; // string | Language specification, default language: cs-CZ
$x_correlation_id = 'x_correlation_id_example'; // string | Correlation Id of request
$x_log_level = new \PPLCZCPL\Model\XLogLevelSchema(); // XLogLevelSchema | The forced log level

try {
    $result = $apiInstance->codelistExternalNumberGet($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CodelistApi->codelistExternalNumberGet: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int**|  |
 **offset** | **int**|  |
 **accept_language** | **string**| Language specification, default language: cs-CZ | [optional]
 **x_correlation_id** | **string**| Correlation Id of request | [optional]
 **x_log_level** | [**XLogLevelSchema**](../Model/.md)| The forced log level | [optional]

### Return type

[**\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentExternalNumberTypeModel[]**](../Model/EpsApiMyApi2WebModelsCodelistShipmentExternalNumberTypeModel.md)

### Authorization

[Bearer](../../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`, `text/json`, `application/problem+json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `codelistProductGet()`

```php
codelistProductGet($limit, $offset, $accept_language, $x_correlation_id, $x_log_level): \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentProductType[]
```

Číselník produktů

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer (JWT) authorization: Bearer
$config = PPLCZCPL\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new PPLCZCPL\Api\CodelistApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$limit = 56; // int
$offset = 56; // int
$accept_language = 'accept_language_example'; // string | Language specification, default language: cs-CZ
$x_correlation_id = 'x_correlation_id_example'; // string | Correlation Id of request
$x_log_level = new \PPLCZCPL\Model\XLogLevelSchema(); // XLogLevelSchema | The forced log level

try {
    $result = $apiInstance->codelistProductGet($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CodelistApi->codelistProductGet: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int**|  |
 **offset** | **int**|  |
 **accept_language** | **string**| Language specification, default language: cs-CZ | [optional]
 **x_correlation_id** | **string**| Correlation Id of request | [optional]
 **x_log_level** | [**XLogLevelSchema**](../Model/.md)| The forced log level | [optional]

### Return type

[**\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentProductType[]**](../Model/EpsApiMyApi2WebModelsCodelistShipmentProductType.md)

### Authorization

[Bearer](../../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`, `text/json`, `application/problem+json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `codelistProofOfIdentityTypeGet()`

```php
codelistProofOfIdentityTypeGet($limit, $offset, $accept_language, $x_correlation_id, $x_log_level): \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistProofOfIdentityTypeModel[]
```

Typy osobních dokladů

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer (JWT) authorization: Bearer
$config = PPLCZCPL\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new PPLCZCPL\Api\CodelistApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$limit = 56; // int
$offset = 56; // int
$accept_language = 'accept_language_example'; // string | Language specification, default language: cs-CZ
$x_correlation_id = 'x_correlation_id_example'; // string | Correlation Id of request
$x_log_level = new \PPLCZCPL\Model\XLogLevelSchema(); // XLogLevelSchema | The forced log level

try {
    $result = $apiInstance->codelistProofOfIdentityTypeGet($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CodelistApi->codelistProofOfIdentityTypeGet: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int**|  |
 **offset** | **int**|  |
 **accept_language** | **string**| Language specification, default language: cs-CZ | [optional]
 **x_correlation_id** | **string**| Correlation Id of request | [optional]
 **x_log_level** | [**XLogLevelSchema**](../Model/.md)| The forced log level | [optional]

### Return type

[**\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistProofOfIdentityTypeModel[]**](../Model/EpsApiMyApi2WebModelsCodelistProofOfIdentityTypeModel.md)

### Authorization

[Bearer](../../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`, `text/json`, `application/problem+json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `codelistServiceGet()`

```php
codelistServiceGet($limit, $offset, $accept_language, $x_correlation_id, $x_log_level): \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentServiceModel[]
```

Metoda pro získání poskytovaných služeb k zásilkám. Vyskytuje se u shipment/batch nebo /shipment

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer (JWT) authorization: Bearer
$config = PPLCZCPL\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new PPLCZCPL\Api\CodelistApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$limit = 56; // int
$offset = 56; // int
$accept_language = 'accept_language_example'; // string | Language specification, default language: cs-CZ
$x_correlation_id = 'x_correlation_id_example'; // string | Correlation Id of request
$x_log_level = new \PPLCZCPL\Model\XLogLevelSchema(); // XLogLevelSchema | The forced log level

try {
    $result = $apiInstance->codelistServiceGet($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CodelistApi->codelistServiceGet: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int**|  |
 **offset** | **int**|  |
 **accept_language** | **string**| Language specification, default language: cs-CZ | [optional]
 **x_correlation_id** | **string**| Correlation Id of request | [optional]
 **x_log_level** | [**XLogLevelSchema**](../Model/.md)| The forced log level | [optional]

### Return type

[**\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentServiceModel[]**](../Model/EpsApiMyApi2WebModelsCodelistShipmentServiceModel.md)

### Authorization

[Bearer](../../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`, `text/json`, `application/problem+json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `codelistServicePriceLimitGet()`

```php
codelistServicePriceLimitGet($limit, $offset, $service, $currency, $country, $product, $accept_language, $x_correlation_id, $x_log_level): \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistServicePriceLimitModel[]
```

Metoda pro získání minimálních a maximálních hodnot u služeb

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer (JWT) authorization: Bearer
$config = PPLCZCPL\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new PPLCZCPL\Api\CodelistApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$limit = 56; // int
$offset = 56; // int
$service = 'service_example'; // string | Service code
$currency = 'currency_example'; // string | Currency code
$country = 'country_example'; // string | Country code
$product = 'product_example'; // string | Product code
$accept_language = 'accept_language_example'; // string | Language specification, default language: cs-CZ
$x_correlation_id = 'x_correlation_id_example'; // string | Correlation Id of request
$x_log_level = new \PPLCZCPL\Model\XLogLevelSchema(); // XLogLevelSchema | The forced log level

try {
    $result = $apiInstance->codelistServicePriceLimitGet($limit, $offset, $service, $currency, $country, $product, $accept_language, $x_correlation_id, $x_log_level);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CodelistApi->codelistServicePriceLimitGet: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int**|  |
 **offset** | **int**|  |
 **service** | **string**| Service code | [optional]
 **currency** | **string**| Currency code | [optional]
 **country** | **string**| Country code | [optional]
 **product** | **string**| Product code | [optional]
 **accept_language** | **string**| Language specification, default language: cs-CZ | [optional]
 **x_correlation_id** | **string**| Correlation Id of request | [optional]
 **x_log_level** | [**XLogLevelSchema**](../Model/.md)| The forced log level | [optional]

### Return type

[**\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistServicePriceLimitModel[]**](../Model/EpsApiMyApi2WebModelsCodelistServicePriceLimitModel.md)

### Authorization

[Bearer](../../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`, `text/json`, `application/problem+json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `codelistShipmentPhaseGet()`

```php
codelistShipmentPhaseGet($limit, $offset, $accept_language, $x_correlation_id, $x_log_level): \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentPhaseModel[]
```

Fáze zásilky

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer (JWT) authorization: Bearer
$config = PPLCZCPL\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new PPLCZCPL\Api\CodelistApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$limit = 56; // int
$offset = 56; // int
$accept_language = 'accept_language_example'; // string | Language specification, default language: cs-CZ
$x_correlation_id = 'x_correlation_id_example'; // string | Correlation Id of request
$x_log_level = new \PPLCZCPL\Model\XLogLevelSchema(); // XLogLevelSchema | The forced log level

try {
    $result = $apiInstance->codelistShipmentPhaseGet($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CodelistApi->codelistShipmentPhaseGet: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int**|  |
 **offset** | **int**|  |
 **accept_language** | **string**| Language specification, default language: cs-CZ | [optional]
 **x_correlation_id** | **string**| Correlation Id of request | [optional]
 **x_log_level** | [**XLogLevelSchema**](../Model/.md)| The forced log level | [optional]

### Return type

[**\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentPhaseModel[]**](../Model/EpsApiMyApi2WebModelsCodelistShipmentPhaseModel.md)

### Authorization

[Bearer](../../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`, `text/json`, `application/problem+json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `codelistStatusGet()`

```php
codelistStatusGet($limit, $offset, $accept_language, $x_correlation_id, $x_log_level): \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistStatusModel[]
```

Statusy zásilky /shipment

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer (JWT) authorization: Bearer
$config = PPLCZCPL\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new PPLCZCPL\Api\CodelistApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$limit = 56; // int
$offset = 56; // int
$accept_language = 'accept_language_example'; // string | Language specification, default language: cs-CZ
$x_correlation_id = 'x_correlation_id_example'; // string | Correlation Id of request
$x_log_level = new \PPLCZCPL\Model\XLogLevelSchema(); // XLogLevelSchema | The forced log level

try {
    $result = $apiInstance->codelistStatusGet($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CodelistApi->codelistStatusGet: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int**|  |
 **offset** | **int**|  |
 **accept_language** | **string**| Language specification, default language: cs-CZ | [optional]
 **x_correlation_id** | **string**| Correlation Id of request | [optional]
 **x_log_level** | [**XLogLevelSchema**](../Model/.md)| The forced log level | [optional]

### Return type

[**\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistStatusModel[]**](../Model/EpsApiMyApi2WebModelsCodelistStatusModel.md)

### Authorization

[Bearer](../../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`, `text/json`, `application/problem+json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `codelistValidationMessageGet()`

```php
codelistValidationMessageGet($limit, $offset, $accept_language, $x_correlation_id, $x_log_level): \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistValidationMessageModel[]
```

Chybové hlášení.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer (JWT) authorization: Bearer
$config = PPLCZCPL\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new PPLCZCPL\Api\CodelistApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$limit = 56; // int
$offset = 56; // int
$accept_language = 'accept_language_example'; // string | Language specification, default language: cs-CZ
$x_correlation_id = 'x_correlation_id_example'; // string | Correlation Id of request
$x_log_level = new \PPLCZCPL\Model\XLogLevelSchema(); // XLogLevelSchema | The forced log level

try {
    $result = $apiInstance->codelistValidationMessageGet($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CodelistApi->codelistValidationMessageGet: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int**|  |
 **offset** | **int**|  |
 **accept_language** | **string**| Language specification, default language: cs-CZ | [optional]
 **x_correlation_id** | **string**| Correlation Id of request | [optional]
 **x_log_level** | [**XLogLevelSchema**](../Model/.md)| The forced log level | [optional]

### Return type

[**\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistValidationMessageModel[]**](../Model/EpsApiMyApi2WebModelsCodelistValidationMessageModel.md)

### Authorization

[Bearer](../../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`, `text/json`, `application/problem+json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)
