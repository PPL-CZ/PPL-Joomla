# # EpsApiMyApi2WebModelsShipmentServiceModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**additional_parameters** | [**\PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentAdditionalParameterModel[]**](EpsApiMyApi2WebModelsShipmentAdditionalParameterModel.md) | AdditionalParameters | [optional]
**code** | **string** | Code | [optional]
**price** | **double** | Price | [optional]
**price_currency** | **string** | PriceCurrency | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
