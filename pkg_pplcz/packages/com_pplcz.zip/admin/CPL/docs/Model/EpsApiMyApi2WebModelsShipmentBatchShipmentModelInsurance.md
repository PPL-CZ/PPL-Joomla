# # EpsApiMyApi2WebModelsShipmentBatchShipmentModelInsurance

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**insurance_price** | **double** | Částka připojištění. Max limity - /codelist/servicePriceLimit Délka: 12,4 |
**insurance_currency** | **string** | Připojištění může být pouze v rámci naší národní měny – CZK Délka: 3 |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
