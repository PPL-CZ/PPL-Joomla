# # EpsApiMyApi2WebModelsShipmentBatchShipmentResultItemModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reference_id** | **string** | Reference Id | [optional]
**shipment_number** | **string** | Shipment number | [optional]
**insurance_currency** | **string** | Insurance currency | [optional]
**insurance_price** | **double** | Insurance price | [optional]
**label_url** | **string** | Label uri | [optional]
**import_state** | [**\PPLCZCPL\Model\EpsApiMyApi2BusinessEnumsConstImportState**](EpsApiMyApi2BusinessEnumsConstImportState.md) |  | [optional]
**error_message** | **string** | Error message | [optional]
**error_code** | **string** | Error code | [optional]
**related_items** | [**\PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentResultChildItemModel[]**](EpsApiMyApi2WebModelsShipmentBatchShipmentResultChildItemModel.md) | Related items | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
