# # EpsApiMyApi2WebModelsShipmentBatchShipmentSetFeatureModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number_of_shipments** | **int** | Počet balíků na adresu - Max 50 |
**shipment_set_items** | [**\PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentSetItemModel[]**](EpsApiMyApi2WebModelsShipmentBatchShipmentSetItemModel.md) | Shipment set items | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
