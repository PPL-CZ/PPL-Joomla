# # EpsApiMyApi2WebModelsShipmentTrackAndTraceItemModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status_id** | **int** | Status id | [optional]
**code** | **string** | Event code | [optional]
**phase** | **string** | Event phase | [optional]
**group** | **string** | Event group | [optional]
**event_date** | **\DateTime** | Event date | [optional]
**name** | **string** | Status name from codelist | [optional]
**gps_latitude** | **double** | Latitude | [optional]
**gps_longitude** | **double** | Longitude | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
