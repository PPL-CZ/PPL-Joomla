# # EpsApiMyApi2WebModelsOrderBatchOrderModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**order_type** | [**\PPLCZCPL\Model\EpsApiMyApi2WebModelsEnumOrderType**](EpsApiMyApi2WebModelsEnumOrderType.md) |  |
**reference_id** | **string** | Jedinečná reference! |
**shipment_count** | **int** | Počet balíků Max: 50 Délka: 2 |
**email** | **string** | Notifikační email pro objednavatele Délka: 2 | [optional]
**note** | **string** | Poznámka Délka 50 | [optional]
**customer_reference** | **string** | Zákaznická reference. Délka: 9,2 | [optional]
**send_date** | **\DateTime** | Datum odeslání Délka: 9,2 |
**send_time_from** | **string** | Čas odeslání od | [optional]
**send_time_to** | **string** | Čas odeslání do | [optional]
**product_type** | **string** | BUSS / IMPO Délka: 4 | [optional]
**sender** | [**\PPLCZCPL\Model\EpsApiMyApi2WebModelsOrderBatchOrderModelSender**](EpsApiMyApi2WebModelsOrderBatchOrderModelSender.md) |  | [optional]
**recipient** | [**\PPLCZCPL\Model\EpsApiMyApi2WebModelsOrderBatchOrderModelRecipient**](EpsApiMyApi2WebModelsOrderBatchOrderModelRecipient.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
