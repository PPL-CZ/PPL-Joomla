# # EpsApiMyApi2WebModelsShipmentBatchLabelSettingsModelCompleteLabelSettings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_complete_label_requested** | **bool** | IsCompleteLabelRequested | [optional]
**page_size** | [**\PPLCZCPL\Model\EpsApiMyApi2BusinessEnumsConstPageSize**](EpsApiMyApi2BusinessEnumsConstPageSize.md) |  | [optional]
**position** | **int** | Position | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
