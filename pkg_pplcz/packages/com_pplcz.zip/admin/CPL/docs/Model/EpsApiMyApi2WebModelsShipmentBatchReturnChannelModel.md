# # EpsApiMyApi2WebModelsShipmentBatchReturnChannelModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | [**\PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchReturnChannelModelType**](EpsApiMyApi2WebModelsShipmentBatchReturnChannelModelType.md) |  | [optional]
**address** | **string** | Pokud je vybrán Type &#x3D; Email, pak zde vyplňovat email příjemce etikety Délka: 100 | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
