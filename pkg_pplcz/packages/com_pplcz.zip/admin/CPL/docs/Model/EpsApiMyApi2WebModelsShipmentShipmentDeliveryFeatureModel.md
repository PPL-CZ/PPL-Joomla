# # EpsApiMyApi2WebModelsShipmentShipmentDeliveryFeatureModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**load_date** | **\DateTime** | Date of loading shipment for delivery. | [optional]
**deliv_date** | **\DateTime** | Delivery date | [optional]
**deliv_person** | **string** | Delivery person | [optional]
**not_deliv_date** | **\DateTime** | Not delivery date | [optional]
**out_dep_date** | **\DateTime** | Out dep date | [optional]
**hub_date** | **\DateTime** | Hub date | [optional]
**delivery_to_access_point** | **bool** | DeliveryToAccessPoint | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
