# # EpsApiMyApi2WebModelsShipmentShipmentModelPaymentInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**paid_by_card** | **bool** |  | [optional]
**cod_paid_date** | **\DateTime** |  | [optional]
**invoice_number** | **string** |  | [optional]
**bank_account** | **string** |  | [optional]
**bank_code** | **string** |  | [optional]
**cod_bank_statement_date** | **\DateTime** |  | [optional]
**cod_currency** | **string** |  | [optional]
**cod_payment_acc_date** | **\DateTime** |  | [optional]
**cod_price** | **double** |  | [optional]
**cod_variable_symbol** | **string** |  | [optional]
**specific_symbol** | **string** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
