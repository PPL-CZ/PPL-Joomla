# # EpsApiMyApi2WebModelsOrderBatchCreateOrderBatchModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orders** | [**\PPLCZCPL\Model\EpsApiMyApi2WebModelsOrderBatchOrderModel[]**](EpsApiMyApi2WebModelsOrderBatchOrderModel.md) | Objednávky |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
