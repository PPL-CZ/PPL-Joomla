# # EpsApiMyApi2WebModelsShipmentBatchCompleteLabelModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**label_urls** | **string[]** | LabelUrls | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
