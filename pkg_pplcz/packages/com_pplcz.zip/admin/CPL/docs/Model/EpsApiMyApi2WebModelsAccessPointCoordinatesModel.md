# # EpsApiMyApi2WebModelsAccessPointCoordinatesModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**latitude** | **double** | Latitude | [optional]
**longitude** | **double** | Longitude | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
