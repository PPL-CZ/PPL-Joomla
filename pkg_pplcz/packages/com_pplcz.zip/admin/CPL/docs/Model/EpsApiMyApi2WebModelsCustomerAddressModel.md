# # EpsApiMyApi2WebModelsCustomerAddressModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **string** | Address type code | [optional]
**name** | **string** | Name | [optional]
**name2** | **string** | Name2 | [optional]
**street** | **string** | Street | [optional]
**city** | **string** | City | [optional]
**zip_code** | **string** | Zip code | [optional]
**country** | **string** | Country code | [optional]
**default** | **bool** | Default address | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
