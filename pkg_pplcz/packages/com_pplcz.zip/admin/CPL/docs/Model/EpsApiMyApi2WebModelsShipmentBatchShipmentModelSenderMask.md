# # EpsApiMyApi2WebModelsShipmentBatchShipmentModelSenderMask

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** | Název firmy / jméno  Délka: 50 | [optional]
**name2** | **string** | Dodatek (Název firmy / jméno)  Délka: 50 | [optional]
**street** | **string** | Ulice Délka: 60 | [optional]
**city** | **string** | Město Délka: 50 | [optional]
**zip_code** | **string** | PSČ Délka: 10 |
**country** | **string** | Kód země podle číselníku - /codelist/country Délka: 2 |
**contact** | **string** | Kontaktní osoba. Délka: 50 | [optional]
**phone** | **string** | Telefon Délka: 30 | [optional]
**email** | **string** | Email Délka: 50 | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
