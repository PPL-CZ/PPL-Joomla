# # EpsApiMyApi2WebModelsShipmentBatchShipmentModelSpecificDelivery

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**specific_delivery_date** | **\DateTime** | SpecificDeliveryDate | [optional]
**specific_delivery_time_from** | **\DateTime** | SpecificDeliveryTimeFrom | [optional]
**specific_delivery_time_to** | **\DateTime** | SpecificDeliveryTimeTo | [optional]
**specific_take_date** | **\DateTime** | SpecificTakeDate | [optional]
**parcel_shop_code** | **string** | Kód výdejního místa Délka: 50 | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
