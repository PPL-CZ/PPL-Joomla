# # EpsApiMyApi2WebModelsShipmentBatchDormantShipmentModelWeighedShipmentInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**weight** | **double** | Váha zásilky deklarovaná odesílatelem. Délka: 9,2 | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
