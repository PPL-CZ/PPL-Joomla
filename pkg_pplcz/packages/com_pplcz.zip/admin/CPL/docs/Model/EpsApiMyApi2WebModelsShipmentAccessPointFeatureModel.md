# # EpsApiMyApi2WebModelsShipmentAccessPointFeatureModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**access_point_days_in_storage** | **int** | Number of days at the access point. | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
