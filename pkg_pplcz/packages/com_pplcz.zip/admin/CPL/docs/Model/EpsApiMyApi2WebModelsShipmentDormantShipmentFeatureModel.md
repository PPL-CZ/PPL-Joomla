# # EpsApiMyApi2WebModelsShipmentDormantShipmentFeatureModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dormant_shipment_number** | **string** | DormantShipmentNumber | [optional]
**dormant_shipment_number_active** | **bool** | DormantShipmentNumberActive | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
