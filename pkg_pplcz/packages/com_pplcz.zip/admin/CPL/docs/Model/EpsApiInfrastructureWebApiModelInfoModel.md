# # EpsApiInfrastructureWebApiModelInfoModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **string** |  | [optional]
**state** | **string** |  | [optional]
**time** | **\DateTime** |  | [optional]
**node** | **string** |  | [optional]
**application** | **string** |  | [optional]
**start_time** | **\DateTime** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
