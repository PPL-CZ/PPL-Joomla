# # EpsApiMyApi2WebModelsShipmentShipmentModelSender

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** | Name | [optional]
**name2** | **string** | Name2 | [optional]
**street** | **string** | Street | [optional]
**city** | **string** | City | [optional]
**zip_code** | **string** | ZipCode | [optional]
**country** | **string** | Country | [optional]
**contact** | **string** | Contact | [optional]
**phone** | **string** | Phone | [optional]
**email** | **string** | Email | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
