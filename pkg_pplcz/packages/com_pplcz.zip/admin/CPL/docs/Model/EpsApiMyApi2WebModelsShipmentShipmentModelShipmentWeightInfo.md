# # EpsApiMyApi2WebModelsShipmentShipmentModelShipmentWeightInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**weight** | **double** | Gets or sets the weight. | [optional]
**weighed_date** | **\DateTime** | Weighed date | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
