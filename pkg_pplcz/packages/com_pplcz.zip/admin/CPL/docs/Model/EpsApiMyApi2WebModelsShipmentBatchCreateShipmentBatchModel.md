# # EpsApiMyApi2WebModelsShipmentBatchCreateShipmentBatchModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**return_channel** | [**\PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchCreateShipmentBatchModelReturnChannel**](EpsApiMyApi2WebModelsShipmentBatchCreateShipmentBatchModelReturnChannel.md) |  | [optional]
**label_settings** | [**\PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchCreateShipmentBatchModelLabelSettings**](EpsApiMyApi2WebModelsShipmentBatchCreateShipmentBatchModelLabelSettings.md) |  | [optional]
**shipments** | [**\PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModel[]**](EpsApiMyApi2WebModelsShipmentBatchShipmentModel.md) | Zásilky |
**shipments_order_by** | **string** | Order by | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
