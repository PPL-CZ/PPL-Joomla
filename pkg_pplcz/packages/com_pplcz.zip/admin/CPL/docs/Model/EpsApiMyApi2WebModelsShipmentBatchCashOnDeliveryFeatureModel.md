# # EpsApiMyApi2WebModelsShipmentBatchCashOnDeliveryFeatureModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**iban** | **string** | IBAN  Délka: 50 | [optional]
**swift** | **string** | Swift  Délka: 50 | [optional]
**spec_symbol** | **string** | Specifický symbol Délka: 6 | [optional]
**account** | **string** | Číslo bankovního účtu Délka: 10 | [optional]
**account_pre** | **string** | Před číslo bankovního účtu Délka: 10 | [optional]
**bank_code** | **string** | Kód banky Délka: 4 | [optional]
**cod_price** | **double** | Částka dobírky.  1. Pokud je CodPrice vyplněné, pak musí být vyplněno i CodCurrency. Délka: 12.4  2. Částka nesmí být záporná.  3. max limity - /codelist/servicePriceLimit |
**cod_currency** | **string** | Měna dobírky, povolené měny - /codelist/currency Délka: 3 |
**cod_var_sym** | **string** | Variabilní symbol dobírky. POUZE čísla Délka: 30 |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
