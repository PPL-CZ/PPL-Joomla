# # EpsApiMyApi2WebModelsAccessPointAccessPointModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**access_point_code** | **string** | AccessPointCode | [optional]
**access_point_type** | [**\PPLCZCPL\Model\EpsApiMyApi2WebModelsAccessPointConstMyApi2AccessPointType**](EpsApiMyApi2WebModelsAccessPointConstMyApi2AccessPointType.md) |  | [optional]
**name** | **string** | Name | [optional]
**name2** | **string** | Name2 | [optional]
**street** | **string** | Street | [optional]
**city** | **string** | City | [optional]
**country** | **string** | Country | [optional]
**zip_code** | **string** | ZipCode | [optional]
**phone** | **string** | Phone | [optional]
**email** | **string** | Email | [optional]
**tribal_service_point** | **bool** | Tribal service point | [optional]
**active_card_payment** | **bool** | ActiveCardPayment | [optional]
**active_cash_payment** | **bool** | Active cash payment | [optional]
**pickup_enabled** | **bool** | Pickup enabled | [optional]
**dimension_forced** | **bool** | Dimension forced | [optional]
**work_hours** | [**\PPLCZCPL\Model\EpsApiMyApi2WebModelsAccessPointAccessPointWorkHourModel[]**](EpsApiMyApi2WebModelsAccessPointAccessPointWorkHourModel.md) | WorkHours | [optional]
**access_point_note** | **string** | AccessPointNote | [optional]
**gps** | [**\PPLCZCPL\Model\EpsApiMyApi2WebModelsAccessPointAccessPointModelGps**](EpsApiMyApi2WebModelsAccessPointAccessPointModelGps.md) |  | [optional]
**capacity_settings** | [**\PPLCZCPL\Model\EpsApiMyApi2WebModelsAccessPointAccessPointCapacitySettingModel[]**](EpsApiMyApi2WebModelsAccessPointAccessPointCapacitySettingModel.md) | CapacitySettings | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
