# OpenAPIClient-php

**Changelog**

* 2024-08-22 - SPRJ-13791 - validace PRTE / PRBC externích čísel - nelze použít najednou
  - /shipment/batch

* 2024-07-01 - SPRJ-13838 - přidání
  - /customer/address

* 2023-11-23 - SPRJ-12703 - CPL - /shipment - timestamp
  - /shipment - Rozšíření výstupu o LastUpdateDate.

* 2023-07-13 - SPRJ-11888 - přidání
  - /codelist/status - číselník statusů

* 2023-07-13 - SPRJ-11953 - přidání
  - /order/cancel - storno objednávky



## Installation & Usage

### Requirements

PHP 7.4 and later.
Should also work with PHP 8.0.

### Composer

To install the bindings via [Composer](https://getcomposer.org/), add the following to `composer.json`:

```json
{
  "repositories": [
    {
      "type": "vcs",
      "url": "https://github.com/GIT_USER_ID/GIT_REPO_ID.git"
    }
  ],
  "require": {
    "GIT_USER_ID/GIT_REPO_ID": "*@dev"
  }
}
```

Then run `composer install`

### Manual Installation

Download the files and include `autoload.php`:

```php
<?php
require_once('/path/to/OpenAPIClient-php/vendor/autoload.php');
```

## Getting Started

Please follow the [installation procedure](#installation--usage) and then run the following:

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');



// Configure Bearer (JWT) authorization: Bearer
$config = PPLCZCPL\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new PPLCZCPL\Api\AccessPointApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$limit = 56; // int
$offset = 56; // int
$access_point_code = 'access_point_code_example'; // string | Kód Výdejního místa
$country_code = 'country_code_example'; // string | kód země viz. /codelist/country
$zip_code = 'zip_code_example'; // string | PSČ
$city = 'city_example'; // string | Město
$access_point_types = array(new \PPLCZCPL\Model\\PPLCZCPL\Model\EpsApiMyApi2WebModelsAccessPointConstMyApi2AccessPointType()); // \PPLCZCPL\Model\EpsApiMyApi2WebModelsAccessPointConstMyApi2AccessPointType[] | Typ výdejního místa
$radius = 56; // int | Rádius (km)
$latitude = 3.4; // double | GPS souřanice
$longitude = 3.4; // double | GPS souřanice
$tribal_service_point = True; // bool | Kmenové výdejní místo
$active_card_payment = True; // bool | Možnost platby kartou
$active_cash_payment = True; // bool | Možnost platby v hotovosti
$pickup_enabled = True; // bool | Možnost podání zásilky
$sizes = array('sizes_example'); // string[] | Maximální hodnoty velikosti balíku: S,M,L,XL
$accept_language = 'accept_language_example'; // string | Language specification, default language: cs-CZ
$x_correlation_id = 'x_correlation_id_example'; // string | Correlation Id of request
$x_log_level = new \PPLCZCPL\Model\XLogLevelSchema(); // XLogLevelSchema | The forced log level

try {
    $result = $apiInstance->accessPointGet($limit, $offset, $access_point_code, $country_code, $zip_code, $city, $access_point_types, $radius, $latitude, $longitude, $tribal_service_point, $active_card_payment, $active_cash_payment, $pickup_enabled, $sizes, $accept_language, $x_correlation_id, $x_log_level);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AccessPointApi->accessPointGet: ', $e->getMessage(), PHP_EOL;
}

```

## API Endpoints

All URIs are relative to *http://localhost*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*AccessPointApi* | [**accessPointGet**](docs/Api/AccessPointApi.md#accesspointget) | **GET** /accessPoint | Seznam výdejních míst
*AddressWhisperApi* | [**addressWhisperGet**](docs/Api/AddressWhisperApi.md#addresswhisperget) | **GET** /addressWhisper | Našeptávač adres
*CodelistApi* | [**codelistAgeCheckGet**](docs/Api/CodelistApi.md#codelistagecheckget) | **GET** /codelist/ageCheck | Číselník pro službu kontrola věku příjemce
*CodelistApi* | [**codelistCountryGet**](docs/Api/CodelistApi.md#codelistcountryget) | **GET** /codelist/country | Číselník zemí + povolení COD
*CodelistApi* | [**codelistCurrencyGet**](docs/Api/CodelistApi.md#codelistcurrencyget) | **GET** /codelist/currency | Číselník povolených měn
*CodelistApi* | [**codelistExternalNumberGet**](docs/Api/CodelistApi.md#codelistexternalnumberget) | **GET** /codelist/externalNumber | Číselník typu externích čísel
*CodelistApi* | [**codelistProductGet**](docs/Api/CodelistApi.md#codelistproductget) | **GET** /codelist/product | Číselník produktů
*CodelistApi* | [**codelistProofOfIdentityTypeGet**](docs/Api/CodelistApi.md#codelistproofofidentitytypeget) | **GET** /codelist/proofOfIdentityType | Typy osobních dokladů
*CodelistApi* | [**codelistServiceGet**](docs/Api/CodelistApi.md#codelistserviceget) | **GET** /codelist/service | Metoda pro získání poskytovaných služeb k zásilkám. Vyskytuje se u shipment/batch nebo /shipment
*CodelistApi* | [**codelistServicePriceLimitGet**](docs/Api/CodelistApi.md#codelistservicepricelimitget) | **GET** /codelist/servicePriceLimit | Metoda pro získání minimálních a maximálních hodnot u služeb
*CodelistApi* | [**codelistShipmentPhaseGet**](docs/Api/CodelistApi.md#codelistshipmentphaseget) | **GET** /codelist/shipmentPhase | Fáze zásilky
*CodelistApi* | [**codelistStatusGet**](docs/Api/CodelistApi.md#codeliststatusget) | **GET** /codelist/status | Statusy zásilky /shipment
*CodelistApi* | [**codelistValidationMessageGet**](docs/Api/CodelistApi.md#codelistvalidationmessageget) | **GET** /codelist/validationMessage | Chybové hlášení.
*CustomerApi* | [**customerAddressGet**](docs/Api/CustomerApi.md#customeraddressget) | **GET** /customer/address | Zákazníkovy adresy
*CustomerApi* | [**customerGet**](docs/Api/CustomerApi.md#customerget) | **GET** /customer | Informace k zákazníkovi – povolené měny
*DataApi* | [**getData**](docs/Api/DataApi.md#getdata) | **GET** /data/{dataGuid} | Metoda pro stažení štítku.
*InfoApi* | [**infoGet**](docs/Api/InfoApi.md#infoget) | **GET** /info | 
*OrderApi* | [**orderGet**](docs/Api/OrderApi.md#orderget) | **GET** /order | Sledování stavu objednávek
*OrderBatchApi* | [**createOrders**](docs/Api/OrderBatchApi.md#createorders) | **POST** /order/batch | Slouží k vytvoření objednávky. Odpověď je v header (Location)
*OrderBatchApi* | [**getOrderBatch**](docs/Api/OrderBatchApi.md#getorderbatch) | **GET** /order/batch/{batchId} | BatchId z předchozí metody. Odpovědí je informace o úspěšném vygenerování objednávky.
*OrderEventApi* | [**orderCancelPost**](docs/Api/OrderEventApi.md#ordercancelpost) | **POST** /order/cancel | Zrušení objednání svozu nebo balíku z libovolné adresy
*ShipmentApi* | [**shipmentGet**](docs/Api/ShipmentApi.md#shipmentget) | **GET** /shipment | Slouží k získání informací (trackingu) k zásilce
*ShipmentBatchApi* | [**createShipments**](docs/Api/ShipmentBatchApi.md#createshipments) | **POST** /shipment/batch | Slouží k vytvoření zásilky. Odpověď je v header (Location)
*ShipmentBatchApi* | [**getShipmentBatch**](docs/Api/ShipmentBatchApi.md#getshipmentbatch) | **GET** /shipment/batch/{batchId} | Slouží k získání stavu importu zásilky
*ShipmentBatchApi* | [**getShipmentBatchLabel**](docs/Api/ShipmentBatchApi.md#getshipmentbatchlabel) | **GET** /shipment/batch/{batchId}/label | BatchId z předchozí metody. Odpovědí je URL (hromadné nebo k jednotlivému balíku) pro stažení vygenerované etikety.
*ShipmentBatchApi* | [**updateShipmentBatch**](docs/Api/ShipmentBatchApi.md#updateshipmentbatch) | **PUT** /shipment/batch/{batchId} | Slouží k úpravě sady zásilek
*ShipmentEventApi* | [**shipmentShipmentNumberCancelPost**](docs/Api/ShipmentEventApi.md#shipmentshipmentnumbercancelpost) | **POST** /shipment/{shipmentNumber}/cancel | Možnost stornovat balík, pokud nebyl fyzicky poslán
*ShipmentEventApi* | [**shipmentShipmentNumberRedirectPost**](docs/Api/ShipmentEventApi.md#shipmentshipmentnumberredirectpost) | **POST** /shipment/{shipmentNumber}/redirect | Možnost doplnit informace k balíku
*VersionInformationApi* | [**versionInformationGet**](docs/Api/VersionInformationApi.md#versioninformationget) | **GET** /versionInformation | Metoda slouží k získávání novinek, informací, plánované odstávky a další důležité informace vztahující se k (nejen) CPL.

## Models

- [EpsApiInfrastructureWebApiModelInfoModel](docs/Model/EpsApiInfrastructureWebApiModelInfoModel.md)
- [EpsApiInfrastructureWebApiModelProblemJsonBasicModel](docs/Model/EpsApiInfrastructureWebApiModelProblemJsonBasicModel.md)
- [EpsApiInfrastructureWebApiModelProblemJsonModel](docs/Model/EpsApiInfrastructureWebApiModelProblemJsonModel.md)
- [EpsApiMyApi2BusinessDtoVersionInformationVersionInformationDto](docs/Model/EpsApiMyApi2BusinessDtoVersionInformationVersionInformationDto.md)
- [EpsApiMyApi2BusinessEnumsConstImportState](docs/Model/EpsApiMyApi2BusinessEnumsConstImportState.md)
- [EpsApiMyApi2BusinessEnumsConstPageSize](docs/Model/EpsApiMyApi2BusinessEnumsConstPageSize.md)
- [EpsApiMyApi2BusinessEnumsConstRelationType](docs/Model/EpsApiMyApi2BusinessEnumsConstRelationType.md)
- [EpsApiMyApi2BusinessEnumsConstReturnChannel](docs/Model/EpsApiMyApi2BusinessEnumsConstReturnChannel.md)
- [EpsApiMyApi2WebConstantsConstLabelFormat](docs/Model/EpsApiMyApi2WebConstantsConstLabelFormat.md)
- [EpsApiMyApi2WebControllersShipmentBatchControllerGetShipmentBatchLabelOrderByEnum](docs/Model/EpsApiMyApi2WebControllersShipmentBatchControllerGetShipmentBatchLabelOrderByEnum.md)
- [EpsApiMyApi2WebControllersShipmentBatchControllerGetShipmentBatchOrderByEnum](docs/Model/EpsApiMyApi2WebControllersShipmentBatchControllerGetShipmentBatchOrderByEnum.md)
- [EpsApiMyApi2WebModelsAccessPointAccessPointCapacitySettingModel](docs/Model/EpsApiMyApi2WebModelsAccessPointAccessPointCapacitySettingModel.md)
- [EpsApiMyApi2WebModelsAccessPointAccessPointModel](docs/Model/EpsApiMyApi2WebModelsAccessPointAccessPointModel.md)
- [EpsApiMyApi2WebModelsAccessPointAccessPointModelGps](docs/Model/EpsApiMyApi2WebModelsAccessPointAccessPointModelGps.md)
- [EpsApiMyApi2WebModelsAccessPointAccessPointWorkHourModel](docs/Model/EpsApiMyApi2WebModelsAccessPointAccessPointWorkHourModel.md)
- [EpsApiMyApi2WebModelsAccessPointConstMyApi2AccessPointType](docs/Model/EpsApiMyApi2WebModelsAccessPointConstMyApi2AccessPointType.md)
- [EpsApiMyApi2WebModelsAccessPointCoordinatesModel](docs/Model/EpsApiMyApi2WebModelsAccessPointCoordinatesModel.md)
- [EpsApiMyApi2WebModelsAddressWhisperAddressWhispModel](docs/Model/EpsApiMyApi2WebModelsAddressWhisperAddressWhispModel.md)
- [EpsApiMyApi2WebModelsAddressWhisperCalledFrom](docs/Model/EpsApiMyApi2WebModelsAddressWhisperCalledFrom.md)
- [EpsApiMyApi2WebModelsCodelistAgeCheckTypeModel](docs/Model/EpsApiMyApi2WebModelsCodelistAgeCheckTypeModel.md)
- [EpsApiMyApi2WebModelsCodelistCountryModel](docs/Model/EpsApiMyApi2WebModelsCodelistCountryModel.md)
- [EpsApiMyApi2WebModelsCodelistCurrencyModel](docs/Model/EpsApiMyApi2WebModelsCodelistCurrencyModel.md)
- [EpsApiMyApi2WebModelsCodelistProofOfIdentityTypeModel](docs/Model/EpsApiMyApi2WebModelsCodelistProofOfIdentityTypeModel.md)
- [EpsApiMyApi2WebModelsCodelistServicePriceLimitModel](docs/Model/EpsApiMyApi2WebModelsCodelistServicePriceLimitModel.md)
- [EpsApiMyApi2WebModelsCodelistShipmentExternalNumberTypeModel](docs/Model/EpsApiMyApi2WebModelsCodelistShipmentExternalNumberTypeModel.md)
- [EpsApiMyApi2WebModelsCodelistShipmentPhaseModel](docs/Model/EpsApiMyApi2WebModelsCodelistShipmentPhaseModel.md)
- [EpsApiMyApi2WebModelsCodelistShipmentProductType](docs/Model/EpsApiMyApi2WebModelsCodelistShipmentProductType.md)
- [EpsApiMyApi2WebModelsCodelistShipmentServiceModel](docs/Model/EpsApiMyApi2WebModelsCodelistShipmentServiceModel.md)
- [EpsApiMyApi2WebModelsCodelistStatusModel](docs/Model/EpsApiMyApi2WebModelsCodelistStatusModel.md)
- [EpsApiMyApi2WebModelsCodelistValidationMessageModel](docs/Model/EpsApiMyApi2WebModelsCodelistValidationMessageModel.md)
- [EpsApiMyApi2WebModelsCustomerAccountModel](docs/Model/EpsApiMyApi2WebModelsCustomerAccountModel.md)
- [EpsApiMyApi2WebModelsCustomerAddressModel](docs/Model/EpsApiMyApi2WebModelsCustomerAddressModel.md)
- [EpsApiMyApi2WebModelsCustomerCustomerModel](docs/Model/EpsApiMyApi2WebModelsCustomerCustomerModel.md)
- [EpsApiMyApi2WebModelsEnumOrderStates](docs/Model/EpsApiMyApi2WebModelsEnumOrderStates.md)
- [EpsApiMyApi2WebModelsEnumOrderType](docs/Model/EpsApiMyApi2WebModelsEnumOrderType.md)
- [EpsApiMyApi2WebModelsOrderBatchCreateOrderBatchModel](docs/Model/EpsApiMyApi2WebModelsOrderBatchCreateOrderBatchModel.md)
- [EpsApiMyApi2WebModelsOrderBatchOrderBatchResultModel](docs/Model/EpsApiMyApi2WebModelsOrderBatchOrderBatchResultModel.md)
- [EpsApiMyApi2WebModelsOrderBatchOrderModel](docs/Model/EpsApiMyApi2WebModelsOrderBatchOrderModel.md)
- [EpsApiMyApi2WebModelsOrderBatchOrderModelRecipient](docs/Model/EpsApiMyApi2WebModelsOrderBatchOrderModelRecipient.md)
- [EpsApiMyApi2WebModelsOrderBatchOrderModelSender](docs/Model/EpsApiMyApi2WebModelsOrderBatchOrderModelSender.md)
- [EpsApiMyApi2WebModelsOrderBatchOrderResultItemModel](docs/Model/EpsApiMyApi2WebModelsOrderBatchOrderResultItemModel.md)
- [EpsApiMyApi2WebModelsOrderBatchRecipientAddressModel](docs/Model/EpsApiMyApi2WebModelsOrderBatchRecipientAddressModel.md)
- [EpsApiMyApi2WebModelsOrderBatchSenderAddressModel](docs/Model/EpsApiMyApi2WebModelsOrderBatchSenderAddressModel.md)
- [EpsApiMyApi2WebModelsOrderEventCancelOrderEventModel](docs/Model/EpsApiMyApi2WebModelsOrderEventCancelOrderEventModel.md)
- [EpsApiMyApi2WebModelsOrderOrderModel](docs/Model/EpsApiMyApi2WebModelsOrderOrderModel.md)
- [EpsApiMyApi2WebModelsOrderOrderModelRecipient](docs/Model/EpsApiMyApi2WebModelsOrderOrderModelRecipient.md)
- [EpsApiMyApi2WebModelsOrderOrderModelSender](docs/Model/EpsApiMyApi2WebModelsOrderOrderModelSender.md)
- [EpsApiMyApi2WebModelsOrderRecipientAddressModel](docs/Model/EpsApiMyApi2WebModelsOrderRecipientAddressModel.md)
- [EpsApiMyApi2WebModelsOrderSenderAddressModel](docs/Model/EpsApiMyApi2WebModelsOrderSenderAddressModel.md)
- [EpsApiMyApi2WebModelsShipmentAccessPointFeatureModel](docs/Model/EpsApiMyApi2WebModelsShipmentAccessPointFeatureModel.md)
- [EpsApiMyApi2WebModelsShipmentAdditionalParameterModel](docs/Model/EpsApiMyApi2WebModelsShipmentAdditionalParameterModel.md)
- [EpsApiMyApi2WebModelsShipmentBackShipmentFeatureModel](docs/Model/EpsApiMyApi2WebModelsShipmentBackShipmentFeatureModel.md)
- [EpsApiMyApi2WebModelsShipmentBatchBackAddressModel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchBackAddressModel.md)
- [EpsApiMyApi2WebModelsShipmentBatchCashOnDeliveryFeatureModel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchCashOnDeliveryFeatureModel.md)
- [EpsApiMyApi2WebModelsShipmentBatchCompleteLabelModel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchCompleteLabelModel.md)
- [EpsApiMyApi2WebModelsShipmentBatchCompleteLabelSettingsModel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchCompleteLabelSettingsModel.md)
- [EpsApiMyApi2WebModelsShipmentBatchCreateShipmentBatchModel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchCreateShipmentBatchModel.md)
- [EpsApiMyApi2WebModelsShipmentBatchCreateShipmentBatchModelLabelSettings](docs/Model/EpsApiMyApi2WebModelsShipmentBatchCreateShipmentBatchModelLabelSettings.md)
- [EpsApiMyApi2WebModelsShipmentBatchCreateShipmentBatchModelReturnChannel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchCreateShipmentBatchModelReturnChannel.md)
- [EpsApiMyApi2WebModelsShipmentBatchDirectInjectionFeatureModel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchDirectInjectionFeatureModel.md)
- [EpsApiMyApi2WebModelsShipmentBatchDormantExternalNumberModel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchDormantExternalNumberModel.md)
- [EpsApiMyApi2WebModelsShipmentBatchDormantRecipientAddressModel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchDormantRecipientAddressModel.md)
- [EpsApiMyApi2WebModelsShipmentBatchDormantServiceModel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchDormantServiceModel.md)
- [EpsApiMyApi2WebModelsShipmentBatchDormantShipmentModel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchDormantShipmentModel.md)
- [EpsApiMyApi2WebModelsShipmentBatchDormantShipmentModelRecipient](docs/Model/EpsApiMyApi2WebModelsShipmentBatchDormantShipmentModelRecipient.md)
- [EpsApiMyApi2WebModelsShipmentBatchDormantShipmentModelWeighedShipmentInfo](docs/Model/EpsApiMyApi2WebModelsShipmentBatchDormantShipmentModelWeighedShipmentInfo.md)
- [EpsApiMyApi2WebModelsShipmentBatchDormantWeighedShipmentFeatureModel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchDormantWeighedShipmentFeatureModel.md)
- [EpsApiMyApi2WebModelsShipmentBatchExternalNumberModel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchExternalNumberModel.md)
- [EpsApiMyApi2WebModelsShipmentBatchInsuranceFeatureModel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchInsuranceFeatureModel.md)
- [EpsApiMyApi2WebModelsShipmentBatchLabelServiceModel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchLabelServiceModel.md)
- [EpsApiMyApi2WebModelsShipmentBatchLabelSettingsModel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchLabelSettingsModel.md)
- [EpsApiMyApi2WebModelsShipmentBatchLabelSettingsModelCompleteLabelSettings](docs/Model/EpsApiMyApi2WebModelsShipmentBatchLabelSettingsModelCompleteLabelSettings.md)
- [EpsApiMyApi2WebModelsShipmentBatchRecipientAddressModel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchRecipientAddressModel.md)
- [EpsApiMyApi2WebModelsShipmentBatchReturnChannelModel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchReturnChannelModel.md)
- [EpsApiMyApi2WebModelsShipmentBatchReturnChannelModelType](docs/Model/EpsApiMyApi2WebModelsShipmentBatchReturnChannelModelType.md)
- [EpsApiMyApi2WebModelsShipmentBatchSenderAddressModel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchSenderAddressModel.md)
- [EpsApiMyApi2WebModelsShipmentBatchSenderMaskAddressModel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchSenderMaskAddressModel.md)
- [EpsApiMyApi2WebModelsShipmentBatchServiceModel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchServiceModel.md)
- [EpsApiMyApi2WebModelsShipmentBatchShipmentBatchResultModel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchShipmentBatchResultModel.md)
- [EpsApiMyApi2WebModelsShipmentBatchShipmentBatchResultModelCompleteLabel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchShipmentBatchResultModelCompleteLabel.md)
- [EpsApiMyApi2WebModelsShipmentBatchShipmentModel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchShipmentModel.md)
- [EpsApiMyApi2WebModelsShipmentBatchShipmentModelBackAddress](docs/Model/EpsApiMyApi2WebModelsShipmentBatchShipmentModelBackAddress.md)
- [EpsApiMyApi2WebModelsShipmentBatchShipmentModelCashOnDelivery](docs/Model/EpsApiMyApi2WebModelsShipmentBatchShipmentModelCashOnDelivery.md)
- [EpsApiMyApi2WebModelsShipmentBatchShipmentModelDirectInjection](docs/Model/EpsApiMyApi2WebModelsShipmentBatchShipmentModelDirectInjection.md)
- [EpsApiMyApi2WebModelsShipmentBatchShipmentModelDormant](docs/Model/EpsApiMyApi2WebModelsShipmentBatchShipmentModelDormant.md)
- [EpsApiMyApi2WebModelsShipmentBatchShipmentModelInsurance](docs/Model/EpsApiMyApi2WebModelsShipmentBatchShipmentModelInsurance.md)
- [EpsApiMyApi2WebModelsShipmentBatchShipmentModelLabelService](docs/Model/EpsApiMyApi2WebModelsShipmentBatchShipmentModelLabelService.md)
- [EpsApiMyApi2WebModelsShipmentBatchShipmentModelSender](docs/Model/EpsApiMyApi2WebModelsShipmentBatchShipmentModelSender.md)
- [EpsApiMyApi2WebModelsShipmentBatchShipmentModelSenderMask](docs/Model/EpsApiMyApi2WebModelsShipmentBatchShipmentModelSenderMask.md)
- [EpsApiMyApi2WebModelsShipmentBatchShipmentModelShipmentRouting](docs/Model/EpsApiMyApi2WebModelsShipmentBatchShipmentModelShipmentRouting.md)
- [EpsApiMyApi2WebModelsShipmentBatchShipmentModelShipmentSet](docs/Model/EpsApiMyApi2WebModelsShipmentBatchShipmentModelShipmentSet.md)
- [EpsApiMyApi2WebModelsShipmentBatchShipmentModelSpecificDelivery](docs/Model/EpsApiMyApi2WebModelsShipmentBatchShipmentModelSpecificDelivery.md)
- [EpsApiMyApi2WebModelsShipmentBatchShipmentResultChildItemModel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchShipmentResultChildItemModel.md)
- [EpsApiMyApi2WebModelsShipmentBatchShipmentResultItemModel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchShipmentResultItemModel.md)
- [EpsApiMyApi2WebModelsShipmentBatchShipmentRoutingModel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchShipmentRoutingModel.md)
- [EpsApiMyApi2WebModelsShipmentBatchShipmentSetFeatureModel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchShipmentSetFeatureModel.md)
- [EpsApiMyApi2WebModelsShipmentBatchShipmentSetItemModel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchShipmentSetItemModel.md)
- [EpsApiMyApi2WebModelsShipmentBatchShipmentSetItemModelWeighedShipmentInfo](docs/Model/EpsApiMyApi2WebModelsShipmentBatchShipmentSetItemModelWeighedShipmentInfo.md)
- [EpsApiMyApi2WebModelsShipmentBatchSpecificDeliveryFeatureModel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchSpecificDeliveryFeatureModel.md)
- [EpsApiMyApi2WebModelsShipmentBatchUpdateShipmentBatchModel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchUpdateShipmentBatchModel.md)
- [EpsApiMyApi2WebModelsShipmentBatchWeighedShipmentFeatureModel](docs/Model/EpsApiMyApi2WebModelsShipmentBatchWeighedShipmentFeatureModel.md)
- [EpsApiMyApi2WebModelsShipmentDormantShipmentFeatureModel](docs/Model/EpsApiMyApi2WebModelsShipmentDormantShipmentFeatureModel.md)
- [EpsApiMyApi2WebModelsShipmentEventRedirectRecipientAddressModel](docs/Model/EpsApiMyApi2WebModelsShipmentEventRedirectRecipientAddressModel.md)
- [EpsApiMyApi2WebModelsShipmentEventRedirectShipmentEventModel](docs/Model/EpsApiMyApi2WebModelsShipmentEventRedirectShipmentEventModel.md)
- [EpsApiMyApi2WebModelsShipmentEventRedirectShipmentEventModelAddress](docs/Model/EpsApiMyApi2WebModelsShipmentEventRedirectShipmentEventModelAddress.md)
- [EpsApiMyApi2WebModelsShipmentExternalNumberModel](docs/Model/EpsApiMyApi2WebModelsShipmentExternalNumberModel.md)
- [EpsApiMyApi2WebModelsShipmentServiceModel](docs/Model/EpsApiMyApi2WebModelsShipmentServiceModel.md)
- [EpsApiMyApi2WebModelsShipmentShipmentAddressModel](docs/Model/EpsApiMyApi2WebModelsShipmentShipmentAddressModel.md)
- [EpsApiMyApi2WebModelsShipmentShipmentDeliveryFeatureModel](docs/Model/EpsApiMyApi2WebModelsShipmentShipmentDeliveryFeatureModel.md)
- [EpsApiMyApi2WebModelsShipmentShipmentModel](docs/Model/EpsApiMyApi2WebModelsShipmentShipmentModel.md)
- [EpsApiMyApi2WebModelsShipmentShipmentModelAccessPointFeature](docs/Model/EpsApiMyApi2WebModelsShipmentShipmentModelAccessPointFeature.md)
- [EpsApiMyApi2WebModelsShipmentShipmentModelBackShipmentFeature](docs/Model/EpsApiMyApi2WebModelsShipmentShipmentModelBackShipmentFeature.md)
- [EpsApiMyApi2WebModelsShipmentShipmentModelDeliveryFeature](docs/Model/EpsApiMyApi2WebModelsShipmentShipmentModelDeliveryFeature.md)
- [EpsApiMyApi2WebModelsShipmentShipmentModelDormantShipmentFeature](docs/Model/EpsApiMyApi2WebModelsShipmentShipmentModelDormantShipmentFeature.md)
- [EpsApiMyApi2WebModelsShipmentShipmentModelPaymentInfo](docs/Model/EpsApiMyApi2WebModelsShipmentShipmentModelPaymentInfo.md)
- [EpsApiMyApi2WebModelsShipmentShipmentModelSender](docs/Model/EpsApiMyApi2WebModelsShipmentShipmentModelSender.md)
- [EpsApiMyApi2WebModelsShipmentShipmentModelShipmentSet](docs/Model/EpsApiMyApi2WebModelsShipmentShipmentModelShipmentSet.md)
- [EpsApiMyApi2WebModelsShipmentShipmentModelShipmentWeightInfo](docs/Model/EpsApiMyApi2WebModelsShipmentShipmentModelShipmentWeightInfo.md)
- [EpsApiMyApi2WebModelsShipmentShipmentModelSpecificDelivery](docs/Model/EpsApiMyApi2WebModelsShipmentShipmentModelSpecificDelivery.md)
- [EpsApiMyApi2WebModelsShipmentShipmentModelTrackAndTrace](docs/Model/EpsApiMyApi2WebModelsShipmentShipmentModelTrackAndTrace.md)
- [EpsApiMyApi2WebModelsShipmentShipmentPaymentFeatureModel](docs/Model/EpsApiMyApi2WebModelsShipmentShipmentPaymentFeatureModel.md)
- [EpsApiMyApi2WebModelsShipmentShipmentSetFeatureModel](docs/Model/EpsApiMyApi2WebModelsShipmentShipmentSetFeatureModel.md)
- [EpsApiMyApi2WebModelsShipmentShipmentStates](docs/Model/EpsApiMyApi2WebModelsShipmentShipmentStates.md)
- [EpsApiMyApi2WebModelsShipmentShipmentWeightFeatureModel](docs/Model/EpsApiMyApi2WebModelsShipmentShipmentWeightFeatureModel.md)
- [EpsApiMyApi2WebModelsShipmentSpecificDeliveryFeatureModel](docs/Model/EpsApiMyApi2WebModelsShipmentSpecificDeliveryFeatureModel.md)
- [EpsApiMyApi2WebModelsShipmentTrackAndTraceItemModel](docs/Model/EpsApiMyApi2WebModelsShipmentTrackAndTraceItemModel.md)
- [EpsApiMyApi2WebModelsShipmentTrackAndTraceModel](docs/Model/EpsApiMyApi2WebModelsShipmentTrackAndTraceModel.md)
- [GetShipmentBatchLabelOrderByParameter](docs/Model/GetShipmentBatchLabelOrderByParameter.md)
- [GetShipmentBatchOrderByParameter](docs/Model/GetShipmentBatchOrderByParameter.md)
- [XLogLevelSchema](docs/Model/XLogLevelSchema.md)

## Authorization

### Bearer

- **Type**: Bearer authentication (JWT)

## Tests

To run the tests, use:

```bash
composer install
vendor/bin/phpunit
```

## Author



## About this package

This PHP package is automatically generated by the [OpenAPI Generator](https://openapi-generator.tech) project:

- API version: `v1`
- Build package: `org.openapitools.codegen.languages.PhpClientCodegen`
