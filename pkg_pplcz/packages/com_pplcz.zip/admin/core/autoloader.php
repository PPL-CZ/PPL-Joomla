<?php
namespace PPLCZ\core;

class PPLCZAutoloader {
    public static $loaded;
}

if (!is_bool(PPLCZAutoloader::$loaded)) {

    $realpath = realpath(__DIR__ ."/../");

    // Try build/vendor first (for development), then vendor (for production)
    $autoloadPaths = [
        __DIR__."/../build/vendor/autoload.php",
        __DIR__."/../vendor/autoload.php"
    ];

    foreach ($autoloadPaths as $autoloadPath) {
        if (is_file($autoloadPath)) {
            require_once $autoloadPath;
            PPLCZAutoloader::$loaded = true;
            spl_autoload_register(function ()
            {
               return false;
            });
            break;
        }
    }

    if (!isset(PPLCZAutoloader::$loaded) || !PPLCZAutoloader::$loaded) {
        PPLCZAutoloader::$loaded = false;
    }

    if (!function_exists('pplcz_error_handler')) {
        require_once __DIR__ . '/Error/handler.php';
    }
}

