<?php

namespace PPLCZ\Validator;

use Joomla\Language\Text;
use PPLCZ\Admin\CPLOperation;
use PPLCZ\Model\Model\ProductModel;
use PPLCZ\Model\Model\CartModel;
use PPLCZ\ModelNormalizer\ShipmentSettingDenormalizer;
use PPLCZ\Serializer;
use PPLCZ\Setting\MethodSetting;
use PPLCZ\Traits\ParcelDataModelTrait;
use PPLCZCPL\ApiException;

class CartValidator extends ModelValidator
{

    use ParcelDataModelTrait;

    public function canValidate($model)
    {
        if ($model instanceof \VirtueMartCart)
            return true;
        return false;
    }

    private static $accessPoints = [];

    public function validate($model, $errors, $path)
    {
        /**
         * @var \VirtueMartCart $model
         * @var \TableShipmentmethods $shippingMethod
         */
        $shippingMethod = pplcz_get_cart_shipping_method();
        if (!$shippingMethod)
            return $errors;

        /**
         * @var CartModel $data
         */
        $data = Serializer::getInstance()->denormalize($shippingMethod, CartModel::class);

        $parcel = pplcz_get_cart_parceldata();

        if ($parcel) {

            if (!isset(self::$accessPoints[$parcel->getCode()])) {
                try {
                    $cpl = new CPLOperation();
                    self::$accessPoints[$parcel->getCode()] = true;
                    $accessToken = $cpl->getAccessToken();
                    if ($accessToken) {
                        $testparcel = $cpl->findParcel($parcel->getCode(), $parcel->getCountry(), 10);
                        if (!$testparcel)
                            self::$accessPoints[$parcel->getCode()] = false;
                    }
                } catch (\Exception $ex2) {
                    if ($ex2 instanceof ApiException && $ex2->getCode() === 404) {
                        self::$accessPoints[$parcel->getCode()] = false;
                    }
                }
            }

            if (!self::$accessPoints[$parcel->getCode()])
            {
                $errors->add("parcelshop-disabled-shop", \Joomla\CMS\Language\Text::_('PLG_VMSHIPMENT_PPLSHIPPING_CART_MISSING_POINT'));
                return $errors;
            }

            switch ($parcel->getAccessPointType()) {
                case 'ParcelShop':
                    if (!$data->getParcelShopEnabled())
                        $errors->add("parcelshop-disabled-shop", \Joomla\CMS\Language\Text::_('PLG_VMSHIPMENT_PPLSHIPPING_CART_DISABLED_SHOP'));
                    break;
                case 'ParcelBox':
                    if (!$data->getParcelBoxEnabled())
                        $errors->add("parcelshop-disabled-box", \Joomla\CMS\Language\Text::_('PLG_VMSHIPMENT_PPLSHIPPING_CART_DISABLED_PARCELBOX'));
                    break;
                case 'AlzaBox':
                    if (!$data->getAlzaBoxEnabled())
                        $errors->add("parcelshop-disabled-box", \Joomla\CMS\Language\Text::_('PLG_VMSHIPMENT_PPLSHIPPING_CART_DISABLED_ALZABOX'));
                    break;
                default:
                    $errors->add("parcelshop-disabled-box", \Joomla\CMS\Language\Text::_('PLG_VMSHIPMENT_PPLSHIPPING_CART_DISABLED_BOX'));
            }

            $country = $parcel->getCountry();

            if (!in_array($country, $data->getEnabledParcelCountries(), true)) {
                $errors->add("parcelshop-disabled-country", \Joomla\CMS\Language\Text::_('PLG_VMSHIPMENT_PPLSHIPPING_CART_DISABLED_COUNTRY'));
            }
        }

        if ($data->getParcelRequired() && !$parcel) {
            $errors->add("parcelshop-missing", \Joomla\CMS\Language\Text::_('PLG_VMSHIPMENT_PPLSHIPPING_PICKUP_POINT_WARNING_LABEL'));
        }

        if (static::ageRequired($model, $shippingMethod)
            && (!$parcel || $parcel->getAccessPointType() !== 'ParcelShop')) {
            $errors->add("parcelshop-age-required", \Joomla\CMS\Language\Text::_('PLG_VMSHIPMENT_PPLSHIPPING_AGE_WARNING_LABEL'));
        }

        if (!$model->ST['phone_1']) {
            $errors->add("parcelshop-phone-required", \Joomla\CMS\Language\Text::_('PLG_VMSHIPMENT_PPLSHIPPING_CART_PHONE_REQUIRED'));
        } else if (!self::isPhone($model->ST['phone_1'])) {
            $errors->add("parcelshop-phone-required", \Joomla\CMS\Language\Text::_('PLG_VMSHIPMENT_PPLSHIPPING_CART_PHONE_INVALID'));
        }

        if (!self::isZip($model->ST['virtuemart_country_id'], $model->ST['zip'])) {
            $errors->add("parcelshop-shippingzip-required", \Joomla\CMS\Language\Text::_('PLG_VMSHIPMENT_PPLSHIPPING_CART_ZIP_INVALID'));
        }

        if ($data->getParcelRequired() && $model->ST['virtuemart_country_id'] && $parcel) {
            $country = \VmModel::getModel('country')->getCountry($model->ST['virtuemart_country_id'])->country_2_code;
            if ($country !== $parcel->getCountry()) {
                $errors->add("parcelshop-shippingzip-required", \Joomla\CMS\Language\Text::_('PLG_VMSHIPMENT_PPLSHIPPING_CART_COUNTRY_MISMATCH'));
            }
        }
        return $errors;
    }


    public static function ageRequired(\VirtueMartCart $cart, $shippingMethod)
    {
        if (is_string($shippingMethod)) {
            $methodid = $shippingMethod;
        } else {
            $methodid = $shippingMethod->code;
        }

        $countryCode = null;
        if (isset($cart->BT['virtuemart_country_id'])) {
            $country = \VmModel::getModel('country')->getCountry($cart->BT['virtuemart_country_id']);
            $countryCode = $country ? $country->country_2_code : null;
        }
        $methodid = MethodSetting::getMethodForCountry($countryCode ?: 'CZ', $methodid);

        if (in_array($methodid, ["SMAR", "SMAD"], true)) {
            foreach ($cart->products as $product) {

                /**
                 * @var ProductModel $model
                 */
                $model = Serializer::getInstance()->denormalize($product, ProductModel::class);
                if ($model->getPplConfirmAge18()
                    || $model->getPplConfirmAge15()) {
                    return true;
                }
            }
        }
        return false;
    }
}