<?php

namespace PPLCZ\Traits;
defined("_JEXEC") or die();

use Joomla\CMS\Factory;
use PPLCZ\Model\Model\ParcelDataModel;
use PPLCZ\Model\Model\CartModel;
use PPLCZ\Serializer;

trait ParcelDataModelTrait
{
    /**
     * @param \Tableorders $order
     * @return ?\TableShipmentmethods
     */
    public static function hasPPLShipment($order)
    {
        /**
         * @var  \TableShipmentmethods $shippingMethods
         */
        $shippingMethod = $order['details']['BT']->virtuemart_shipmentmethod_id;

        $shipmentModels = \VmModel::getModel('shipmentmethod')->getShipment($shippingMethod);

        foreach ($shipmentModels as $shippingMethod) {
            if (str_contains($shippingMethod->get_method_id(), pplcz_create_name(""))) {
                return $shippingMethod;
            }
        }
        return null;
    }

    public static function getParcelshopOrderData($order_id, $ifActive = false): ?ParcelDataModel
    {
        if ($order_id) {
            $data = self::getParcelDataModel($order_id);
            return $data;
        }
        return null;
    }

    public static function getParcelDataModel($order_id): ?ParcelDataModel
    {
        $db = Factory::getContainer()->get('DatabaseDriver');
        $query = $db->getQuery(true)
            ->select($db->quoteName('parcel_model'))
            ->from($db->quoteName('#__pplcz_order_meta'))
            ->where($db->quoteName('ppl_order_id') . ' = ' . $db->quote($order_id));
        $db->setQuery($query);
        $rows = $db->loadResult();

        if ($rows){
            $rows = json_decode($rows, true);
//            return $rows;
            return Serializer::getInstance()->denormalize($rows, ParcelDataModel::class);
        }

        return null;
    }
}