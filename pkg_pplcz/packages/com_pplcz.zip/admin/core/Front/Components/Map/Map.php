<?php

namespace PPLCZ\Front\Components\Map;

use Joomla\CMS\Factory;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use PPLCZ\Setting\MethodSetting;
use PPLCZ\Template\Template;

defined('_JEXEC') or die('Restricted access');

require_once JPATH_ADMINISTRATOR . '/components/com_pplcz/core/globals.php';

class Map
{
    public static function handleRequest()
    {
        $input = Factory::getApplication()->getInput();

       // Zpracování parametrů
        $data = self::processRequestData($input);

        $args = self::newmap($data);
        self::renderNewMap($args);
    }

    private static function processRequestData($input): array
    {
        return [
            'lat' => $input->getFloat('ppl_lat', 0),
            'lng' => $input->getFloat('ppl_lng', 0),
            'withCard' => $input->getInt('ppl_withCard', 0),
            'withCash' => $input->getInt('ppl_withCash', 0),
            'parcelshop' => $input->getInt('ppl_parcelshop', 0),
            'parcelbox' => $input->getInt('ppl_parcelbox', 0),
            'address' => $input->getString('ppl_address', ''),
            'country' => strtolower($input->getString('ppl_country', '')),
            'hiddenPoints' => $input->getString('ppl_hiddenpoints', ''),
            'countries' => $input->getString('ppl_countries', ''),
        ];
    }

    private static function getLanguage(): string
    {
        $lang = pplcz_get_option(pplcz_create_name("map_language"));

        if (!in_array(strtolower($lang), ['cs', 'en'])) {
            $lang = 'cs';
        }
        return strtolower($lang);
    }

    private static function newmap(array $data): array
    {
        $map = MethodSetting::getGlobalSetting()->getMap();
        $lang = self::getLanguage();
        $country = strtoupper($data['country']) ?: 'CZ';

        $hiddenPoints = array_filter(explode(',', $data['hiddenPoints'] ?: ''));

        $config = [
            'allowedCountries' => array($country),
            'defaultLang' => $lang,
            'viewMode' => 'inline',
            'defaultCountry' => $country,
            'disabledAccessPointTypes' => $hiddenPoints,
        ];

        if ($data['address']) {
            $config['centeredToAddress'] = $data['address'];
        }

        if (floatval($data['lat']) && floatval($data['lng'])) {
            $config['centeredToLat'] = $data['lat'];
            $config['centeredToLon'] = $data['lng'];
        }

        if ($data['withCash']) {
            $config['codRequired'] = true;
        }

        return ['apikey' => $map->getApikey(), 'config' => $config];
    }

    private static function renderNewMap(array $args)
    {
        $document = Factory::getDocument();
        $document->setMetaData('viewport', 'width=device-width, initial-scale=1.0');
        self::loadNewMapAssets();
        Template::renderMapPage([
            'apikey' => $args['apikey'],
            'config' => $args['config'],
        ], 'parcelshops-new-map.php');
    }

    private static function loadNewMapAssets()
    {
        $wa = Factory::getApplication()->getDocument()->getWebAssetManager();

        $wa->registerAndUseScript('ppl.accesspoint.loader', 'https://www.ppl.cz/accesspointwidget/loader.js', [], ['defer' => true]);

        $pluginPathFront = Uri::root() . 'administrator/components/com_pplcz/core/Front/Components/Map/';
        $wa->registerAndUseScript('ppl-external', $pluginPathFront . 'ppl-external.js', [], ['defer' => true]);
        $wa->registerAndUseStyle('ppl-external', $pluginPathFront . 'ppl-external.css');
    }
}
