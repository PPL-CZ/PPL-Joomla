<?php

namespace PPLCZ\Front\Components\Map;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use PPLCZ\Setting\MethodSetting;
use PPLCZ\Template\Template;

defined('_JEXEC') or die('Restricted access');

require_once JPATH_ADMINISTRATOR . '/components/com_pplcz/core/globals.php';

class Map
{
    public static function handleRequest()
    {
        $input = Factory::getApplication()->getInput();

       // Zpracování parametrů
        $data = self::processRequestData($input);

        $args = self::newmap($data);
        self::renderNewMap($args);
    }

    private static function processRequestData($input): array
    {
        return [
            'lat' => $input->getFloat('ppl_lat', 0),
            'lng' => $input->getFloat('ppl_lng', 0),
            'withCard' => $input->getInt('ppl_withCard', 0),
            'withCash' => $input->getInt('ppl_withCash', 0),
            'parcelshop' => $input->getInt('ppl_parcelshop', 0),
            'parcelbox' => $input->getInt('ppl_parcelbox', 0),
            'address' => $input->getString('ppl_address', ''),
            'country' => strtolower($input->getString('ppl_country', '')),
            'hiddenPoints' => $input->getString('ppl_hiddenpoints', ''),
            'countries' => $input->getString('ppl_countries', ''),
        ];
    }

    private static function getLanguage(): string
    {
        $params = ComponentHelper::getParams('com_pplcz');
        $lang = $params->get(pplcz_create_name("map_language"));

        if (!in_array(strtolower($lang), ['cs', 'en'])) {
            $lang = 'cs';
        }
        return strtolower($lang);
    }

    private static function oldmap(array $data): array
    {
        $attributes = [];

        if ($data['lat'] && $data['lng']) {
            $attributes['data-lat'] = $data['lat'];
            $attributes['data-lng'] = $data['lng'];
            $attributes['data-mode'] = 'static';
        }

        $filters = [];
        if ($data['withCard']) $filters[] = 'CardPayment';
        if ($data['withCash']) $filters[] = 'ParcelShop';
        if ($filters) {
            $attributes['data-initialfilters'] = implode(',', $filters);
        }

        if ($data['address']) $attributes['data-address'] = $data['address'];
        if ($data['country']) $attributes['data-country'] = $data['country'];
        if ($data['hiddenPoints']) $attributes['data-hiddenpoints'] = $data['hiddenPoints'];
        if ($data['countries']) $attributes['data-countries'] = $data['countries'];

        $attributes['data-language'] = self::getLanguage();

        return $attributes;
    }

    private static function newmap(array $data): array
    {
        $map = MethodSetting::getGlobalSetting()->getMap();
        $lang = self::getLanguage();
        $country = strtoupper($data['country']) ?: 'CZ';

        $hiddenPoints = array_filter(explode(',', $data['hiddenPoints'] ?: ''));
        $allowedAccessPoint = array_diff(['AlzaBox', 'ParcelBox', 'ParcelShop'], $hiddenPoints);

        $config = [
            'mode' => 'SHOPCART',
            'allowedAccessPointTypes' => array_values($allowedAccessPoint),
            //'allowedCountries' => array_values(array_map('strtoupper',explode(',', $data['countries']))),
            'allowedCountries' => array($country),
            'defaultLanguage' => $lang,
            'viewMode' => 'inline',
            'defaultCountry' => $country,
            'disabledAccessPointTypes' => $hiddenPoints,
        ];

        if ($data['address']) {
            $config['centeredToAddress'] = $data['address'];
        }

        if (floatval($data['lat']) && floatval($data['lng'])) {
            $config['centeredToLat'] = $data['lat'];
            $config['centeredToLon'] = $data['lng'];
        }

        if ($data['withCash']) {
            $config['codRequired'] = true;
        }

        return ['apikey' => $map->getApikey(), 'config' => $config];
    }

    private static function renderOldMap(array $mapAttributes)
    {
        $document = Factory::getDocument();
        $document->setMetaData('viewport', 'width=device-width, initial-scale=1.0');
        self::loadOldMapAssets();
        Template::renderMapPage(['mapAttributes' => $mapAttributes], 'parcelshops-map.php');
    }

    private static function renderNewMap(array $args)
    {
        $document = Factory::getDocument();
        $document->setMetaData('viewport', 'width=device-width, initial-scale=1.0');
        self::loadNewMapAssets();
        Template::renderMapPage([
            'apikey' => $args['apikey'],
            'config' => $args['config'],
        ], 'parcelshops-new-map.php');
    }

    private static function loadOldMapAssets()
    {
        $wa = Factory::getApplication()->getDocument()->getWebAssetManager();

        $wa->registerAndUseScript('ppl.map', 'https://www.ppl.cz/sources/map/main.js', [], ['defer' => true]);
        $wa->registerAndUseStyle('ppl.map', 'https://www.ppl.cz/sources/map/main.css');

        $pluginPathFront = Uri::root() . 'administrator/components/com_pplcz/core/Front/Components/Map/';
        $wa->registerAndUseScript('ppl-external', $pluginPathFront . 'ppl-external.js', ['jquery'], ['defer' => true]);
        $wa->registerAndUseStyle('ppl-external', $pluginPathFront . 'ppl-external.css');
    }

    private static function loadNewMapAssets()
    {
        $wa = Factory::getApplication()->getDocument()->getWebAssetManager();

        $wa->registerAndUseScript('ppl.accesspoint.loader', 'https://www.ppl.cz/accesspointwidget/loader.js', [], ['defer' => true]);

        $pluginPathFront = Uri::root() . 'administrator/components/com_pplcz/core/Front/Components/Map/';
        $wa->registerAndUseScript('ppl-external', $pluginPathFront . 'ppl-external.js', [], ['defer' => true]);
        $wa->registerAndUseStyle('ppl-external', $pluginPathFront . 'ppl-external.css');
    }
}
