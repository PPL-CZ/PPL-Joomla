<?php

namespace PPLCZ\Template;
use Joomla\Filesystem\Path;
use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;

defined('_JEXEC') or die;

class Template {

    public static function renderMapPage(array $data, string $templateName): void
    {
        $path = self::getTemplatePath($templateName);

        if (!file_exists($path)) {
            throw new \RuntimeException("Map template not found: " . $path);
        }

        // Nastavit content-type
        header('Content-Type: text/html; charset=utf-8');

        extract($data);
        include $path;
    }

    public static function getTemplatePath($template_name)
    {
        $defaultPath = JPATH_ADMINISTRATOR . '/components/com_pplcz/core/Template/';

        return Path::clean($defaultPath . $template_name);

    }

    public static function render(string $templateName, array $data = []): string
    {
        $path = self::getTemplatePath($templateName);

        if (!file_exists($path)) {
            throw new \RuntimeException("Template {$templateName} not found.");
        }



        // Vytvoří proměnné z pole $data
        extract($data);

        ob_start();
        include $path;
        return ob_get_clean();

    }
}