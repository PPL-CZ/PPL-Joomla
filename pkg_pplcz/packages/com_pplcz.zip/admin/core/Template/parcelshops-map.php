<?php
//defined("JEXEC") or die();

use Joomla\CMS\Factory;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
?>
<!DOCTYPE html>
<html lang="<?php echo \Joomla\CMS\Factory::getApplication()->getLanguage()->getTag(); ?>">
<head>
    <jdoc:include type="head" />
</head>
<body class="ppl-map">
<div id="pplcz-parcelshop-info"></div>
<div id="ppl-parcelshop-map"
    <?php foreach ($mapAttributes as $k => $v) {
        echo $k . '="' . htmlspecialchars($v, ENT_QUOTES) . '" ';
    } ?>
></div>
</body>
</html>
