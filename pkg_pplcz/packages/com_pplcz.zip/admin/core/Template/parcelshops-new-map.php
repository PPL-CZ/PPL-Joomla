<?php
use Joomla\CMS\Factory;
?>
<!DOCTYPE html>
<html lang="<?php echo Factory::getApplication()->getLanguage()->getTag(); ?>">
<head>
    <jdoc:include type="head" />
</head>
<body class="ppl-map" style="margin:0;padding:0">
<div id="pplcz-parcelshop-info"></div>
<ppl-access-point-widget
    id="pplWidget"
    api-key="<?php echo htmlspecialchars($apikey, ENT_QUOTES, 'UTF-8'); ?>"
    config="<?php echo htmlspecialchars(json_encode($config), ENT_QUOTES, 'UTF-8'); ?>"
></ppl-access-point-widget>
</body>
</html>
