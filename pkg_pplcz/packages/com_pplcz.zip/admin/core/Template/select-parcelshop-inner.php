<?php

$messages = [];
if (!$ageOk) {
    if ($parcelRequired)
        $messages[] = \Joomla\CMS\Language\Text::_('PLG_VMSHIPMENT_PPLSHIPPING_AGE_WARNING_LABEL');
}
if ($parcelRequired && !$shipping_address)
    $messages[] = \Joomla\CMS\Language\Text::_('PLG_VMSHIPMENT_PPLSHIPPING_PICKUP_POINT_WARNING_LABEL');

$cart = VirtueMartCart::getCart();
$address = "";
$country = "";

if ($cart && $cart->BT) {
    if (!empty($cart->ST)) {
        $address = join(", ", array_filter([$cart->ST['address_1'] ?? null, $cart->ST['zip'] ?? null, $cart->ST['city'] ?? null]));
        $countryId = $cart->ST['virtuemart_country_id'] ?? null;
    } else {
        $address = join(", ", array_filter([$cart->BT['address_1'] ?? null, $cart->BT['zip'] ?? null, $cart->BT['city'] ?? null]));
        $countryId = $cart->BT['virtuemart_country_id'] ?? null;
    }
    if ($countryId) {
        $countryModel = \VmModel::getModel('country')->getCountry($countryId);
        $country = $countryModel ? $countryModel->country_2_code : "";
    }
}
/**
 * @var \PPLCZ\Model\Model\ParcelDataModel $shipping_address
 */

if (isset($shipping_address) && $shipping_address->getId()) {
    $address = join(', ', array_filter([$shipping_address->getStreet(), join(" ", array_filter([$shipping_address->getZipCode(), $shipping_address->getCity()]))]));
    $country = $shipping_address->getCountry();
}

$parcels = ["ParcelBox" => "1", "AlzaBox" => "2", "ParcelShop" => 3];


if ($parcelBoxEnabled) {
    unset($parcels["ParcelBox"]);
}
if ($alzaBoxEnabled) {
    unset($parcels["AlzaBox"]);
}
if ($parcelShopEnabled) {
    unset($parcels["ParcelShop"]);
}
$parcelShopRequired = 0;
$parcelBoxRequired = 0;
?>
<div class="pplcz-parcelshop-inner" <?php echo((isset($showMap) && $showMap) ? "data-pplcz-showmap='1'" : "") ?> >
    <?php
    if ($canOpenMap): ?>
        <div class="pplcz-select-parcelshop">
            <a href="#"
               class="pplcz-select-parcelshop"
               data-pplcz-select-parcel-shop=""
               data-hidden-points="<?php echo htmlspecialchars(join(',', array_keys($parcels))); ?>"
               <?php if (!$ageOk): ?>data-pplcz-parcelshop="1"<?php endif ?>
               data-address="<?php echo htmlspecialchars($address) ?>"
               data-country="<?php echo htmlspecialchars($country) ?>"
               data-countries="<?php echo htmlspecialchars(join(', ', $countries)) ?>"
               data-cod-method="<?php echo htmlspecialchars($codMethod) ?>"
            >
                <img src="<?php echo htmlspecialchars($image) ?>">
            </a>
        </div>
    <?php else: ?>
    <div class="pplcz-select-parcelshop-disabled">
        <img src="<?php echo htmlspecialchars($image) ?>">
    </div>
    <?php endif ?>
    <div class="pplcz-selected-parcelshop">
        <?php
        if (isset($shipping_address) && $shipping_address) {
            ?>
            <?php echo htmlspecialchars($shipping_address->getAccessPointType()); ?>  <a href="#"
                                                                                         class="pplcz-clear-map"
                                                                                         data-pplcz-select-parcel-shop="clear">
                <?php echo \Joomla\CMS\Language\Text::_('PLG_VMSHIPMENT_PPLSHIPPING_CANCEL_SELECTION_LABEL') ?>
            </a>,
            <?php echo htmlspecialchars($shipping_address->getName()) ?>,
            <?php echo htmlspecialchars($shipping_address->getStreet()) ?>,
            <?php echo htmlspecialchars($shipping_address->getZipCode()) ?>
            <?php echo htmlspecialchars($shipping_address->getCity()) ?>

            <?php
        } else {
            ?>
            <?php if (!$parcelRequired) {
                echo \Joomla\CMS\Language\Text::_('PLG_VMSHIPMENT_PPLSHIPPING_SELECT_PARCELSHOP_LABEL');
            } else {
                echo \Joomla\CMS\Language\Text::_('PLG_VMSHIPMENT_PPLSHIPPING_SELECT_PICKUP_POINT_LABEL');
            } ?>

        <?php } ?>
    </div>
    <input type="hidden" name="pplcz_parcelshop" value='<?php echo htmlspecialchars($content) ?>'>
</div>
