<?php

namespace PPLCZ\ModelNormalizer;

defined("_JEXEC") or die();

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use PPLCZ\Model\Model\CalculatedDPH;
use PPLCZ\Model\Model\CategoryModel;
use PPLCZ\Model\Model\ProductModel;
use PPLCZ\Model\Model\ShipmentMethodSettingCurrencyModel;
use PPLCZ\Model\Model\ShipmentMethodSettingModel;
use PPLCZ\Serializer;
use PPLCZ\Setting\MethodSetting;
use PPLCZ\Utils\BoxPacker;
use PPLCZ\Validator\CartValidator;
use PPLCZVendor\Symfony\Component\Serializer\Normalizer\DenormalizerInterface;
use PPLCZ\Front\Validator\ParcelShopValidator;
use PPLCZ\Model\Model\CartModel;
use PPLCZ\ShipmentMethod;
use VmModel;
use calculationHelper;

require_once __DIR__ . '/../globals.php';

class CartModelDernomalizer implements DenormalizerInterface
{


    public function denormalize($data, string $type, ?string $format = null, array $context = [])
    {
        require_once JPATH_PLUGINS . '/vmshipment/pplshipping/pplshipping.php';
        /**
         * @var ShipmentMethod $data
         * @var ShipmentMethodSettingModel $setting
         */

        $setting = pplcz_denormalize($data, ShipmentMethodSettingModel::class);

        $cart = \VirtueMartCart::getCart();

        $paymentModel = \VmModel::getModel('paymentmethod');
        $paymentMethod = $cart->virtuemart_paymentmethod_id;

        $countryId = $_POST['virtuemart_country_id'] ?? $cart->BT['virtuemart_country_id'] ?? null;

        if (!empty($countryId)) {
            $countryModel = VmModel::getModel('country')->getCountry($countryId);
        } else {
            $countryModel = null;
        }
        $country = $countryModel ? $countryModel->country_2_code : null;

        $currencyId = $cart->pricesCurrency;
        $currency = \CurrencyDisplay::getInstance()->ensureUsingCurrencyCode($currencyId);
        $currencySetting = null;

        if ($setting->getCurrencies()) {
            $currencySetting = array_filter($setting->getCurrencies(), function ($item) use ($currency) {
                return $item->getCurrency() === $currency;
            });
            $currencySetting = reset($currencySetting);
        }

        if ($currencySetting == null) {
            $currencySetting = new ShipmentMethodSettingCurrencyModel();
            $currencySetting->setCurrency($currency);
            $currencySetting->setEnabled(false);
        }

        $shipmentCartModel = new CartModel();

        $countries = include __DIR__ . '/../config/countries.php';
        $limits = include __DIR__ . '/../config/limits.php';

        $shipmentCartModel->setParcelRequired(false);
        $shipmentCartModel->setMapEnabled(false);
        $shipmentCartModel->setDisabledByCountry(false);
        $shipmentCartModel->setAgeRequired(false);
        $shipmentCartModel->setDisabledByRules(false);

        $parcelPlacesSetting = MethodSetting::getGlobalParcelboxesSetting();

        $disabledParcelBox = $parcelPlacesSetting->getDisabledParcelBox();
        $disabledParcelShop = $parcelPlacesSetting->getDisabledParcelShop();
        $disabledAlzaBox = $parcelPlacesSetting->getDisabledAlzaBox();
        $disabledCountriesFromBaseSetting = $parcelPlacesSetting->getDisabledCountries();
        /**
         * NOVÁ LOGIKA - kombinace globálních ZAKÁZANÝCH a lokálních POVOLENÝCH zemí
         *
         * 1. Získat všechny parcel země: [CZ, SK, PL, DE]
         * 2. Odečíst globálně zakázané země (plugin-level)
         * 3. Udělat průnik s lokálně povolenými zeměmi (shipment-level)
         *
         */

        // Globální ZAKÁZANÉ země (plugin-level) - zůstává stejné

        if (!is_array($disabledCountriesFromBaseSetting))
            $disabledCountriesFromBaseSetting = [];

        // POVOLENÉ země z nastavení konkrétní dopravy (shipment-level)
        $allowedCountriesFromShipmentSetting = $setting->getAllowedParcelCountries() ?? [];

        if ($setting->getParcelBoxes()) {
            $globalMapSetting = MethodSetting::getGlobalSetting()->getMap();
            $enabledMap = $globalMapSetting && $globalMapSetting->getApikey() ? true : false;

            $shipmentCartModel->setMapEnabled($enabledMap);

            if (!$enabledMap)
                $shipmentCartModel->setDisabledByRules(true);

            $shipmentCartModel->setParcelRequired(true);

            // Získání zemí s parcelshopy
            $countriesWithParcelshop = pplcz_get_parcel_countries();

            // 1. Nejprve odečíst globálně zakázané země
            $availableCountries = array_diff($countriesWithParcelshop, $disabledCountriesFromBaseSetting);

            // 2. Pokud jsou nastavené povolené země pro dopravní metodu, udělat průnik
            if (!empty($allowedCountriesFromShipmentSetting)) {
                $allowedParcelCountries = array_intersect($availableCountries, $allowedCountriesFromShipmentSetting);
            } else {
                // Pokud nejsou nastavené žádné povolené země - zakázat dopravu
                $allowedParcelCountries = [];

            }

            // je povolena zeme, kteoru ted mame v ramci parcelshopu?
            $enabledByCountry = in_array($country, $allowedParcelCountries, true);

            $shipmentCartModel->setEnabledParcelCountries($allowedParcelCountries);

            $shipmentCartModel->setParcelShopEnabled($enabledByCountry && !$disabledParcelShop && !$setting->getDisabledParcelShop());
            $shipmentCartModel->setParcelBoxEnabled($enabledByCountry && !$disabledParcelBox && !$setting->getDisabledParcelBox());
            $shipmentCartModel->setAlzaBoxEnabled($enabledByCountry && !$disabledAlzaBox && !$setting->getDisabledAlzaBox());
            $shipmentCartModel->setDisabledByCountry(!$enabledByCountry);

        } else {
            $shipmentCartModel->setDisabledByCountry(false);
            $shipmentCartModel->setParcelBoxEnabled(false);
            $shipmentCartModel->setParcelShopEnabled(false);
            $shipmentCartModel->setAlzaBoxEnabled(false);
        }

        $shipmentCartModel->setDisabledByWeight(true);

        $totalWeight = 0;

        foreach ($cart->products as $product) {
            $productWeight = $this->unitConverter($product->product_weight_uom, $product->product_weight);
            $quantity = $product->quantity;
            $totalWeight += $productWeight * $quantity;
        }

        $selectedWeightPrice = 0;

        if ($setting->getCostByWeight()) {
            $selectedWeightRule = null;
            foreach ($setting->getWeights() as $weight) {
                if (($weight->getFrom() == null || $weight->getFrom() <= $totalWeight)
                    && ($weight->getTo() == null || $weight->getTo() > $totalWeight)) {
                    //["EUR" => 6, "CZK" => 5]. ["CZK" => 5], 5
                    // [] => null
                    $weightPrice = array_filter($weight->getPrices(), function ($price) use ($currency) {
                        return $price->getCurrency() === $currency;
                    });
                    $weightPrice = reset($weightPrice);
                    if ($weightPrice && $selectedWeightPrice < $weightPrice->getPrice()) {
                        $selectedWeightPrice = $weightPrice->getPrice() ?: 0;
                        $shipmentCartModel->setDisabledByWeight(false);
                        $selectedWeightRule = $weight;
                    }
                }
            }

            if ($selectedWeightRule) {
                $shipmentCartModel->setAlzaBoxEnabled($shipmentCartModel->getAlzaBoxEnabled() && !$selectedWeightRule->getDisabledAlzaBox());
                $shipmentCartModel->setParcelBoxEnabled($shipmentCartModel->getParcelBoxEnabled() && !$selectedWeightRule->getDisabledParcelBox());
                $shipmentCartModel->setParcelShopEnabled($shipmentCartModel->getParcelShopEnabled() && !$selectedWeightRule->getDisabledParcelShop());
            }
        } else {
            $selectedWeightRule = array_filter($setting->getCurrencies(), function ($currencies) use ($currency) {
                return $currencies->getCurrency() === $currency;
            });

            $selectedWeightRule = reset($selectedWeightRule);
            if ($selectedWeightRule) {
                $shipmentCartModel->setDisabledByWeight(false);
                /**
                 * @var ShipmentMethodSettingCurrencyModel $selectedWeightPrice
                 */
                $selectedWeightPrice = $selectedWeightRule->getCost() ?: 0;
            }
        }


        $serviceCode = str_replace(pplcz_create_name(''), '', $setting->getCode());
        // preklad
        $serviceCode = MethodSetting::getMethodForCountry($country, $serviceCode);

        if (!$serviceCode) {
            $shipmentCartModel->setDisabledByCountry(true);
            return $shipmentCartModel;
        } else if (CartValidator::ageRequired($cart, $serviceCode)) {
            $shipmentCartModel->setAgeRequired(true);
            $shipmentCartModel->setParcelBoxEnabled(false);
            $shipmentCartModel->setAlzaBoxEnabled(false);
        }

        $serviceCode = $serviceCode ?: "NONSERVICEFOUNDED";

        if (!in_array($country, $allowedCountriesFromShipmentSetting)) {
            $shipmentCartModel->setDisabledByCountry(true);
        }

        $shipmentCartModel->setServiceCode($serviceCode);

        $codServiceCode = MethodSetting::getCodMethods($serviceCode);

        $shipmentCartModel->setCodPayment($setting->getCodPayment() ?: '');

        $disabledPayments = $setting->getDisablePayments();

        $shipmentCartModel->setDisablePayments($disabledPayments);

        $countryAndBankAccount = pplcz_get_cod_currencies();

        // Kontrola, zda aktuální platební metoda není v seznamu zakázaných
        if (is_array($disabledPayments) && in_array($paymentMethod, $disabledPayments, true)) {
            $shipmentCartModel->setDisabledByRules(true);
        }

        $accountIn = array_filter($countryAndBankAccount, function ($item) use ($country, $currency) {
            return $item['country'] == $country && $item['currency'] == $currency;
        });

        if (!isset($countries[$country]) || !$countries[$country] || !$accountIn)
            $shipmentCartModel->setDisableCod(true);
        else
            $shipmentCartModel->setDisableCod(false);

        $maxCodPrice = array_values(array_filter($limits['COD'], function ($item) use ($codServiceCode, $currency) {
            if ($item['product'] === $codServiceCode && $item['currency'] === $currency) {
                return true;
            }
            return false;
        }, true));

        $totalContents = $cart->cartPrices['basePrice'] + $cart->cartPrices['taxAmount'];
        $total = $totalContents;

        $isPriceWithDph = $setting->getIsPriceWithDph();

        $shipmentCartModel->setIsPriceWithDph($isPriceWithDph);

        if (!$maxCodPrice
            || !isset($maxCodPrice[0])
            || !isset($maxCodPrice[0]['max'])
            || $maxCodPrice[0]['max'] === ''
            || $maxCodPrice[0]['max'] === null
            || $total >= $maxCodPrice[0]['max']) {
            $shipmentCartModel->setDisableCod(true);
            if ($currencySetting->getCostOrderFree() != null
                && $currencySetting->getCostOrderFree() <= $total) {
                $shipmentCartModel->setCodFee(0);
                $shipmentCartModel->setCost(0);
            } else {
                $shipmentCartModel->setCodFee(0);
                $shipmentCartModel->setCost($selectedWeightPrice ?: 0);
            }
        } else {
            $max = @$maxCodPrice[0]['max'];
            if ($max !== '' && $max !== null && $total >= $max) {
                $shipmentCartModel->setDisableCod(true);
                $shipmentCartModel->setCodFee(100000);
                $shipmentCartModel->setCost(100000);
            } else {
                $isCod = $paymentMethod === $shipmentCartModel->getCodPayment();
                $freeCodPrice = $currencySetting->getCostOrderFreeCod();

                if ($isCod
                    && $freeCodPrice != null
                    && $freeCodPrice <= $total) {
                    if ($currencySetting->getCostCodFeeAlways())
                        $shipmentCartModel->setCodFee($currencySetting->getCostCodFee() ?: 0);
                    else
                        $shipmentCartModel->setCodFee(0);
                    $shipmentCartModel->setCost(0);
                } else if ($isCod) {
                    $shipmentCartModel->setCodFee($currencySetting->getCostCodFee() ?: 0);
                    $shipmentCartModel->setCost($selectedWeightPrice ?: 0);
                } else {
                    $shipmentCartModel->setCodFee(0);
                    $costorderfree = $currencySetting->getCostOrderFree();

                    if ($costorderfree != null && floatval($costorderfree) <= $total)
                        $shipmentCartModel->setCost(0);
                    else
                        $shipmentCartModel->setCost($selectedWeightPrice ?: 0);
                }
            }
        }

        $shipmentCartModel->setDisabledByProduct(false);

        $method = MethodSetting::getMethod($serviceCode);

        if ($method->getMaxWeight() && $totalWeight > $method->getMaxWeight()) {
            $shipmentCartModel->setDisabledByWeight(true);
        }

        $packagesSizes = [];

        foreach ($cart->products as $product) {

            $product_id = $product->virtuemart_product_id;
            $quantity = $product->quantity;

            $length = $this->unitConverter($product->product_lwh_uom, $product->product_length);
            $width = $this->unitConverter($product->product_lwh_uom, $product->product_width);
            $height = $this->unitConverter($product->product_lwh_uom, $product->product_height);

            $productModel = Serializer::getInstance()->denormalize($product, ProductModel::class);
            $productSize = null;
            if ($length || $width || $height) {
                $productSize = array_values(array_filter([floatval($length), floatval($width), floatval($height)]));
                $max = max($length, $width, $height);
                if ($max > 0) {
                    while (count($productSize) < 3) {
                        $productSize[] = floatval($max);
                    }
                    $productSize['name'] = $product->product_name;
                    $productSize['qty'] = $quantity;
                } else {
                    $productSize = null;
                }
            }

            /**
             * @var ProductModel $productModel
             * @var CategoryModel $categoryModel
             */
            $productModel = Serializer::getInstance()->denormalize($product, ProductModel::class);

            $pplSizes = [];

            if ($method->getMaxDimension()) {

                if ($productModel->getPplSizes()) {
                    foreach ($productModel->getPplSizes() as $pplSize) {
                        if ($pplSize) {
                            $current = array_values(array_filter([floatval($pplSize->getYSize()), floatval($pplSize->getZSize()), floatval($pplSize->getXSize())]));
                            $max = floatval(max($current));
                            if ($max > 0) {
                                while (count($current) < 3) {
                                    $current[] = $max;
                                }
                                $current['name'] = $product->product_name;
                                $current['qty'] = $quantity;
                                $pplSizes[] = $current;
                            }
                        }
                    }
                }
                if (!$pplSizes && $productSize)
                    $pplSizes[] = $productSize;
            }

            if (in_array($codServiceCode, $productModel->getPplDisabledTransport() ?? [], true)) {
                $shipmentCartModel->setDisableCod(true);
            }

            if (in_array($serviceCode, $productModel->getPplDisabledTransport() ?? [], true)) {
                $shipmentCartModel->setDisabledByProduct(true);
                break;
            }

            $ageProductValidation = false;
            if (in_array($method->getAgeValidation(), [true, false], true) && ($productModel->getPplConfirmAge18() || $productModel->getPplConfirmAge15())) {
                $ageProductValidation = true;
            }

            $shipmentCartModel->setParcelBoxEnabled(!$ageProductValidation && !$productModel->getPplDisabledParcelBox() && $shipmentCartModel->getParcelBoxEnabled());
            $shipmentCartModel->setParcelShopEnabled(!$productModel->getPplDisabledParcelShop() && $shipmentCartModel->getParcelShopEnabled());
            $shipmentCartModel->setAlzaBoxEnabled(!$ageProductValidation && !$productModel->getPplDisabledAlzaBox() && $shipmentCartModel->getAlzaBoxEnabled());

            $get_parents = $product->categories;
            $ids = [];

            while ($get_parents) {
                $curId = array_shift($get_parents);
                if (in_array($curId, $ids)) {
                    continue;
                }

                $categoryModel = \VmModel::getModel('category');
                $category = $categoryModel->getCategory($curId);

                $ids[] = $curId;
                $parId = $category->category_parent_id;
                if ($parId)
                    $get_parents[] = $parId;
            }

            foreach ($ids as $category_id) {
                $db = Factory::getContainer()->get('DatabaseDriver');

                $query = $db->getQuery(true)
                    ->select($db->quoteName('params'))
                    ->from($db->quoteName('#__pplcz_category'))
                    ->where($db->quoteName('virtuemart_category_id') . ' = ' . (int)$category_id);

                $db->setQuery($query);
                $result = json_decode($db->loadResult(), true);

                $categoryModel = Serializer::getInstance()->denormalize($result, CategoryModel::class);

                if ($method->getMaxDimension() && !$pplSizes && $categoryModel->getPplSize()) {
                    $size = $categoryModel->getPplSize();
                    $current = array_values(array_filter([floatval($size->getYSize()), floatval($size->getZSize()), floatval($size->getXSize())]));
                    $max = max($size->getYSize(), $size->getZSize(), $size->getXSize());
                    if ($max > 0) {
                        while (count($current) < 3) {
                            $current[] = floatval($max);
                        }

                        $current['name'] = $product->product_name;
                        $current['qty'] = $quantity;
                    }
                    if ($current) {
                        $packagesSizes[] = $current;
                    }
                }

                if (in_array($codServiceCode, $categoryModel->getPplDisabledTransport() ?? [], true)) {
                    $shipmentCartModel->setDisableCod(true);
                }
                if (in_array($serviceCode, $categoryModel->getPplDisabledTransport() ?? [], true)) {
                    $shipmentCartModel->setDisabledByProduct(true);
                    break 2;
                }

                $ageProductValidation = false;
                if (in_array($method->getAgeValidation(), [true, false], true) && ($categoryModel->getPplConfirmAge18() || $categoryModel->getPplConfirmAge15())) {
                    $ageProductValidation = true;
                }

                $shipmentCartModel->setParcelBoxEnabled(!$ageProductValidation && !$categoryModel->getPplDisabledParcelBox() && $shipmentCartModel->getParcelBoxEnabled());
                $shipmentCartModel->setParcelShopEnabled(!$categoryModel->getPplDisabledParcelShop() && $shipmentCartModel->getParcelShopEnabled());
                $shipmentCartModel->setAlzaBoxEnabled(!$ageProductValidation && !$categoryModel->getPplDisabledAlzaBox() && $shipmentCartModel->getAlzaBoxEnabled());
            }

            $packagesSizes = array_merge($packagesSizes, $pplSizes);
        }

        if (!$shipmentCartModel->getParcelShopEnabled() && !$shipmentCartModel->getParcelBoxEnabled() && !$shipmentCartModel->getAlzaBoxEnabled() && $shipmentCartModel->getParcelRequired()) {
            $shipmentCartModel->setDisabledByRules(true);
        }

        if (!$shipmentCartModel->getParcelShopEnabled() && $shipmentCartModel->getAgeRequired()) {
            $shipmentCartModel->setDisabledByRules(true);
        }

        $shipmentCartModel->setMapEnabled(
            $shipmentCartModel->getMapEnabled()
            && ($shipmentCartModel->getParcelShopEnabled() || $shipmentCartModel->getParcelBoxEnabled() || $shipmentCartModel->getAlzaBoxEnabled())
            && !$shipmentCartModel->getDisabledByCountry()
        );

        if ($method->getMaxDimension() && $packagesSizes) {
            $sizes = $method->getMaxDimension();
            $max = max($sizes);
            if ($max > 0) {
                while (count($sizes) < 3) {
                    $sizes[] = $max;
                }

                $boxPacker = new BoxPacker();


                $boxPacker->addBox("max", floatval($sizes[0]), floatval($sizes[1]), floatval($sizes[2]));

                if ($method->getMaxPackages())
                    $boxPacker->setMaxPackages($method->getMaxPackages());

                foreach ($packagesSizes as $package) {
                    $boxPacker->addItem($package['name'], floatval($package[0]), floatval($package[1]), floatval($package[2]), floatval($package['qty']));
                }
                $boxPacker->setStackingMode("all");
                $resolved = $boxPacker->pack();
                if (!$resolved || !$resolved['success']) {
                    $shipmentCartModel->setDisabledBySize(true);
                } else {
                    foreach ($resolved['boxes'] as $box) {
                        if ($box['metrics']['shape_efficiency'] < 65) {
                            $shipmentCartModel->setDisabledBySize(true);
                            break;
                        }
                    }
                }
            }
        }

        // -----------------------------------------------------------------------------------------------------------------------
        // TaxSelector: -1 when "Apply no rules", 0 when "Apply default rules", 1, 2, 3, etc. when applying own tax rules (based od database id)
        $isPriceWithDph = $shipmentCartModel->getIsPriceWithDph();

        $taxModel = \VmModel::getModel('calc');

        // Výběr a přiřazení nejvyšší sazby
        $taxMethods = $taxModel->getCalcs();
        $maxTax = null;

        foreach ($taxMethods as $tax) {
            if ($maxTax === null || $tax->calc_value > $maxTax->calc_value) {
                $maxTax = $tax;
            }
        }

        $selected_rate = $maxTax;

        $shipmentCartModel->setTaxableName($selected_rate->virtuemart_calc_id);

        //Násobitel DPH
        $multiplier = ((float)$selected_rate->calc_value / 100) + 1;

        $selectedWeightPrice = $shipmentCartModel->getCost();

        if ($isPriceWithDph) {
            $basePrice = ($selectedWeightPrice / $multiplier);
        } else {
            $basePrice = $selectedWeightPrice;
        }

        $dph = $basePrice * ((float)$selected_rate->calc_value / 100);
        $priceWithDph = $basePrice + $dph;

        $costDPH = new CalculatedDPH();
        $costDPH->setValue($dph);
        $costDPH->setDphId($selected_rate->virtuemart_calc_id);

        $shipmentCartModel->setCostDPH($costDPH);
        $shipmentCartModel->setCost($basePrice);

        if ($shipmentCartModel->getCodFee()) {
            $codFee = $shipmentCartModel->getCodFee();
            if ($isPriceWithDph) {
                $codFeeBase = ($codFee / $multiplier);
            } else {
                $codFeeBase = $codFee;
            }

            $dph = $codFeeBase * ((float)$selected_rate->calc_value / 100);
            $codFeeDPH = $codFeeBase + $dph;

            $costDPH = new CalculatedDPH();
            $costDPH->setValue($dph);
            $costDPH->setDphId($selected_rate->virtuemart_calc_id);
            $shipmentCartModel->setCodFeeDPH($costDPH);
            $shipmentCartModel->setCodFee($codFeeBase);

        }

        // -------------------------------------------------------------------------------------------------------------------

        return $shipmentCartModel;
    }

    private function unitConverter($productUnit, $productValue)
    {

        $unit = strtoupper(trim($productUnit));
        $value = floatval($productValue);

        switch ($unit) {
            case "M":   // metr
                return $value * 100;
            case "MM":  // milimetr
                return $value / 10;
            case "YD":  // yard
                return $value * 91.44;
            case "FT":  // footy
                return $value * 30.48;
            case "IN":  // inch
                return $value * 2.54;
            case "CM":  // centimetr
                return $value;
            case "G":   // gram
                return $value / 1000;
            case "MG":  // miligram
                return $value / 1000000;
            case "LB":  // libra
                return $value * 0.453592;
            case "OZ":  // unce
                return $value * 0.0283495;
            case "KG":  // kilogram
                return $value;

            default:
                return $value;
        }
    }

    public
    function supportsDenormalization($data, string $type, ?string $format = null)
    {
        if ($data instanceof \TableShipmentmethods && $type === CartModel::class) {
            return true;
        }
        return false;
    }
}