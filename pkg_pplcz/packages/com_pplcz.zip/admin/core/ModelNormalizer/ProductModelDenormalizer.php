<?php
namespace PPLCZ\ModelNormalizer;

defined("_JEXEC") or die();

use Joomla\CMS\Factory;
use PPLCZVendor\Symfony\Component\Serializer\Normalizer\DenormalizerInterface;
use PPLCZ\Model\Model\ProductModel;
use PPLCZ\Serializer;
use Joomla\Registry\Registry;


class ProductModelDenormalizer  implements DenormalizerInterface {

    public function denormalize($data, string $type, ?string $format = null, array $context = [])
    {
        if ($data instanceof \TableProducts && $type === ProductModel::class)
        {
            //Intnotes nelze použít
            $db = Factory::getContainer()->get('DatabaseDriver');
            $query = $db->getQuery(true);

            $query->select('params')
                ->from($db->quoteName('#__pplcz_product'))
                ->where($db->quoteName('virtuemart_product_id') . '=' . $data->virtuemart_product_id);

             $db->setQuery($query);
             $results = $db->loadResult();
             if($results !== null && $results !== ''){
                 $data = json_decode($results, true);
             }else{
                 $data =  [];
             }

            if (!is_array($data))
                return new ProductModel();
            return Serializer::getInstance()->denormalize($data, ProductModel::class);
        }
        else if ($data instanceof ProductModel && $type === \TableProducts::class)
        {
            if (!isset($context["product"]) || !($context['product'] instanceof \WC_Product)) {
                throw new \Exception("Undefined product");
            }
            $normalized = Serializer::getInstance()->normalize($data, "array");
            $context["product"]->add_meta_data("_pplProductData", $normalized, true) || $context['product']->update_meta_data("_pplProductData", $normalized);
            return  $context['product'];
        }
        throw new \Exception("Undefined denormalize");
    }

    public function supportsDenormalization($data, string $type, ?string $format = null)
    {
        if ($data instanceof \TableProducts && $type === ProductModel::class) {
            return true;
        } else if ($type === \TableProducts::class && $data instanceof ProductModel) {
            return true;
        }
        return false;
    }
}