<?php

namespace PPLCZ\ModelNormalizer;


use PPLCZ\Admin\Errors;
use PPLCZ\Data\OrderProxy;
use PPLCZ\Data\ShipmentData;
use PPLCZ\Model\Model\ShipmentModel;
use PPLCZ\Model\Model\ShipmentWithAdditionalModel;
use PPLCZ\Model\Model\ErrorModel;
use PPLCZ\Validator\Validator;
use PPLCZVendor\Symfony\Component\Serializer\Normalizer\DenormalizerInterface;
use PPLCZVendor\Symfony\Component\Serializer\Normalizer\NormalizerInterface;

class ShipmentWithAdditionalModelDenormalizer implements DenormalizerInterface, NormalizerInterface
{

    public function normalize($object, ?string $format = null, array $context = [])
    {
        /**
         * @var ShipmentWithAdditionalModel $object
         */
        $data = [];

        if ($object->isInitialized('shipment') && $object->getShipment()) {
            $data['shipment'] = pplcz_normalize($object->getShipment());
        }

        if ($object->isInitialized('errors') && $object->getErrors()) {
            $data['errors'] = array_map(function($error) {
                return pplcz_normalize($error);
            }, $object->getErrors());
        }

        return $data;
    }

    public function supportsNormalization($data, ?string $format = null)
    {
        return $data instanceof ShipmentWithAdditionalModel;
    }

    public function denormalize($data, string $type, ?string $format = null, array $context = [])
    {
        $shipmentModel = pplcz_denormalize($data, ShipmentModel::class);
        $errors = new Errors();

        $shipment = new ShipmentWithAdditionalModel();
        $shipment->setShipment($shipmentModel);


        pplcz_validate($shipmentModel, $errors);

        if ($errors->hasErrors())
        {
            $errorModels = pplcz_denormalize($errors, ErrorModel::class . '[]');
            $shipment->setErrors($errorModels);
        }

        return $shipment;
    }

    public function supportsDenormalization($data, string $type, ?string $format = null)
    {
        if (($data instanceof ShipmentData || $data instanceof \TableOrders)
            && $type === ShipmentWithAdditionalModel::class)
        {
            return true;
        }
        return false;
    }
}