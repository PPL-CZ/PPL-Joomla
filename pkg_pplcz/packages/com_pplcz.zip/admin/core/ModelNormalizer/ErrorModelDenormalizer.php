<?php
namespace PPLCZ\ModelNormalizer;

use PPLCZ\Admin\Errors;
use PPLCZ\Model\Model\ErrorModel;
use PPLCZVendor\Symfony\Component\Serializer\Normalizer\DenormalizerInterface;

class ErrorModelDenormalizer implements DenormalizerInterface
{

    public function denormalize($data, string $type, ?string $format = null, array $context = [])
    {
        /**
         * @var Errors $data
         */
        $output = [];
        $errors = $data->getErrors();

        foreach ($errors as $key => $values)
        {
            $errorModel = new ErrorModel();
            $errorModel->setKey($key);
            $errorModel->setValues($values);
            $output[] = $errorModel;
        }
        return $output;
    }

    public function supportsDenormalization($data, string $type, ?string $format = null)
    {
        return $data instanceof Errors && $type === ErrorModel::class . "[]";
    }
}
