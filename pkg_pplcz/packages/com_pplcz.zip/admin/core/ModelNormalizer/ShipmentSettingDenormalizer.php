<?php

namespace PPLCZ\ModelNormalizer;

defined("_JEXEC") or die;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\Registry\Registry;
use PPLCZ\Model\Model\ShipmentMethodSettingCurrencyModel;
use PPLCZ\Model\Model\ShipmentMethodSettingModel;
use PPLCZ\Model\Model\ShipmentMethodSettingPriceRuleModel;
use PPLCZ\Model\Model\ShipmentMethodSettingWeightModel;
use PPLCZ\Model\Model\ShipmentMethodSettingWeightRuleModel;
use PPLCZ\Setting\MethodSetting;
use Joomla\CMS\Table\Table;
use VmModel;
use PPLCZVendor\Symfony\Component\Serializer\Normalizer\DenormalizerInterface;

require_once __DIR__ . '/../globals.php';

class ShipmentSettingDenormalizer implements DenormalizerInterface
{

    public function denormalize($data, string $type, ?string $format = null, array $context = [])
    {
        //----------------
        $vendorModel = \VmModel::getModel('vendor');
        $vendorCurrencyId = $vendorModel->getVendor()->vendor_currency;
        $id = $data->virtuemart_shipmentmethod_id;

        $currencyModel = \VmModel::getModel('currency');
        $vendorCurrencyCode = $currencyModel->getCurrency($vendorCurrencyId)->currency_code_3;

        $currencies = include __DIR__ . '/../config/currencies.php';
        $currencies = array_unique(array_merge([$vendorCurrencyCode], array_values($currencies)));
        //----------------
        if ($type === ShipmentMethodSettingModel::class) {
            /**
             * @var  $data
             */
            $shipment = new ShipmentMethodSettingModel();


            $db = Factory::getContainer()->get('DatabaseDriver');
            $query = $db->getQuery(true)
                ->select('params')
                ->from($db->quoteName('#__pplcz_shipment_method'))
                ->where($db->quoteName('virtuemart_shipmentmethod_id') . ' = ' . $id);

            $db->setQuery($query);
            $registry = new Registry;
            $registry->loadString($db->loadResult());
            $params = $registry->toArray();


            $cart = \VirtueMartCart::getCart();

            $countryId = $_POST['virtuemart_country_id'] ?? $cart->BT['virtuemart_country_id'] ?? null;

            if (isset($countryId)) {
                $countryModel = VmModel::getModel('country')->getCountry($countryId);
            } else {
                $countryModel = null;
            }
            $country = $countryModel ? $countryModel->country_2_code : null;

            $methodCode = MethodSetting::getMethodForCountry($country, $data->code);
            $shipment->setCode(pplcz_create_name($methodCode));
            $shipment->setParcelBoxes(in_array($methodCode, MethodSetting::parcelMethods()));

            $shipment->setIsPriceWithDph($params['isPriceWithDph'] ?? false);
            $shipment->setCodPayment($params['codPayment'] ?? '');
            $shipment->setDisablePayments($params['disablePayments'] ?? []);
            $shipment->setCostByWeight($params['costByWeight'] ?? false);

            // před nastavením výdejních míst podmínka na SBOX

            if ($shipment->getCode() === pplcz_create_name("SBOX")) {
                $shipment->setDisabledAlzaBox(true);
                $shipment->setDisabledParcelShop(true);
                $shipment->setDisabledParcelBox(false);
            } else {
                $shipment->setDisabledAlzaBox($params['disabledAlzaBox'] ?? false);
                $shipment->setDisabledParcelBox($params['disabledParcelBox'] ?? false);
                $shipment->setDisabledParcelShop($params['disabledParcelShop'] ?? false);
            }

            $allowedCoutries = array_map(function($item) {
                return $item->country_2_code;
            }, pplcz_get_allowed_countries());

            // NOVÁ LOGIKA - uložit přímo povolené země
            if ($params['code'] === 'SMAR') {
                // Získat všechny parcel countries dostupné v systému
                $parcelCountries = pplcz_get_parcel_countries();

                // Odfiltrovat parcel countries, které nejsou v systému
                $availableParcelCountries = array_intersect($parcelCountries, $allowedCoutries);

                // Uložit POVOLENÉ země (přímo z parametrů)
                $savedAllowedParcel = array_intersect($params['allowedParcelCountries'], $availableParcelCountries);
            } elseif ($params['code'] === 'SBOX') {

                $parcelCountries = pplcz_get_parcel_countries();
                $savedAllowedParcel = in_array('CZ', $parcelCountries, true) ? ['CZ'] : [];

            } elseif ($params['code'] === 'PRIV') {
                $savedAllowedParcel = array_intersect($params['allowedParcelCountries'], $allowedCoutries);
            }

            if (!is_array($savedAllowedParcel))
                $savedAllowedParcel = [];

            $shipment->setAllowedParcelCountries($savedAllowedParcel);

            $shipment->setCurrencies([]);
            $shipment->setWeights([]);

            foreach ($params['currencies'] as $c) {

                $currency = $c;
                if (in_array($currency['currency'], $currencies)) {
                    $item = array_filter($shipment->getCurrencies(), function (ShipmentMethodSettingCurrencyModel $item) use ($currency) {
                        return $item->getCurrency() === $currency['currency'];
                    });
                    if (!$item) {
                        $item = [new ShipmentMethodSettingCurrencyModel()];
                        $item[0]->setCurrency($currency['currency']);
                        $shipment->setCurrencies(array_merge($shipment->getCurrencies(), $item));
                    }
                    /**
                     * @var ShipmentMethodSettingCurrencyModel $item
                     */
                    $item = reset($item);
                    $isNumberRegex = "/^[0-9]+(\.[0-9]*)?$/";
                    $item->setEnabled($currency['enabled'] ?? false);
                    $item->setCostOrderFree(isset($currency['costOrderFree']) && preg_match($isNumberRegex, $currency['costOrderFree']) ? floatval($currency['costOrderFree']) : null);
                    $resolved = isset($currency['costCodFee']) && preg_match($isNumberRegex, $currency['costCodFee']) ? floatval($currency['costCodFee']) : null;
                    $item->setCostCodFee($resolved);
                    $item->setCostCodFeeAlways($currency['costCodFeeAlways'] ?? false);
                    $item->setCostOrderFreeCod(isset($currency['costOrderFreeCod']) && preg_match($isNumberRegex, $currency['costOrderFreeCod']) ? floatval($currency['costOrderFreeCod']) : null);
                    $item->setCost(isset($currency['cost']) && preg_match($isNumberRegex, $currency['cost']) ? floatval($currency['cost']) : null);
                }
            }


            $weight = $params['weights'];
            $weightArray = [];

            foreach ($weight as $rule) {

                $weightArray[] = (array)$rule;
            };
            if (is_array($weightArray)) {
                try {
                    foreach ($weightArray as $key => $value) {
                        // denormalizace nefunguje správně - nutno upravit
                        $weightArray[$key] = pplcz_denormalize($value, ShipmentMethodSettingWeightRuleModel::class);
                    }

                    usort($weightArray, function (ShipmentMethodSettingWeightRuleModel $item1, ShipmentMethodSettingWeightRuleModel $item2) {
                        $to1 = $item1->getTo() ?: 1000000000;
                        $to2 = $item2->getTo() ?: 1000000000;

                        if ($to2 == $to1) {
                            $to1 = $item1->getFrom() ?: 0;
                            $to2 = $item2->getFrom() ?: 0;
                            if ($to1 == $to2)
                                return 0;
                            if ($to2 > $to1)
                                return -1;
                            return 1;
                        } else {
                            if ($to2 > $to1)
                                return -1;
                            return 1;
                        }
                    });


                    $shipment->setWeights($weightArray);
                } catch (\Throwable $exception) {

                }

            }

            return $shipment;
        }
    }


    public
    function supportsDenormalization($data, string $type, ?string $format = null)
    {
        return $data instanceof \TableShipmentmethods && $type === ShipmentMethodSettingModel::class;
    }

}