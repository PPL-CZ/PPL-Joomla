<?php

namespace PPLCZ\ModelNormalizer;

defined("_JEXEC") or die();


use Joomla\CMS\Factory;
use PPLCZ\Setting\MethodSetting;
use PPLCZVendor\Symfony\Component\Serializer\Normalizer\DenormalizerInterface;
use PPLCZ\Data\AddressData;
use PPLCZ\Data\CodBankAccountData;
use PPLCZ\Data\PackageData;
use PPLCZ\Data\ParcelData;
use PPLCZ\Data\ShipmentData;
use PPLCZ\Model\Model\BankAccountModel;
use PPLCZ\Model\Model\PackageModel;
use PPLCZ\Model\Model\ParcelAddressModel;
use PPLCZ\Model\Model\ParcelDataModel;
use PPLCZ\Model\Model\ProductModel;
use PPLCZ\Model\Model\RecipientAddressModel;
use PPLCZ\Model\Model\SenderAddressModel;
use PPLCZ\Model\Model\ShipmentModel;
use PPLCZ\Model\Model\UpdateShipmentBankAccountModel;
use PPLCZ\Model\Model\UpdateShipmentModel;
use PPLCZ\Model\Model\UpdateShipmentSenderModel;
use PPLCZ\ShipmentMethod;
use PPLCZ\Serializer;
use PPLCZ\Traits\ParcelDataModelTrait;
use TableOrders;

require_once __DIR__ . '/../globals.php';

class ShipmentDataDenormalizer implements DenormalizerInterface
{

    use ParcelDataModelTrait;

    private function getServiceCodeFromOrder($order)
    {
        $shippingMethod = \VmModel::getModel('shipmentmethod')->getShipment($order->virtuemart_shipmentmethod_id);
        $order = \VmModel::getModel('orders')->getOrder($order->virtuemart_order_id);

        if ($shippingMethod) {

            $code = str_replace(pplcz_create_name(''), '', $shippingMethod->code);

            $method2 = MethodSetting::getMethod($code);

            if (!$method2)
                return [null, null, false, false];

            $country = \VmModel::getModel('country')->getCountry($order['details']['BT']->virtuemart_country_id);
            $country = $country->country_2_code;

            $code = MethodSetting::getMethodForCountry($country, $code);

            if (!$code)
                return [null, null, false, false];

            $method2 = MethodSetting::getMethod($code);

            $isCOD = MethodSetting::isCOD($shippingMethod->virtuemart_shipmentmethod_id, $order['details']['BT']->virtuemart_paymentmethod_id);

            if ($isCOD) {
                $code = MethodSetting::getCodMethods($method2->getCode());
            }
            if (!$code)
                return [null, null, false, false];

            if ($code !== $method2->getCode()) {
                $method2 = MethodSetting::getMethod($code);
            }

            return [$code, $method2->getTitle(), $method2->getCodAvailable(), $method2->getParcelRequired()];
        }
        return [null, null, false, false];
    }

    private function ShipmentDataToModel(ShipmentData $data, array $context = [])
    {
        $shipmentModel = new ShipmentModel();
        $shipmentModel->setId($data->get_id());
        $shipmentModel->setImportState($data->get_import_state());

        $shipmentModel->setPrintState(pplcz_get_shipment_print($data->get_id()) ?: pplcz_get_batch_print($data->get_batch_id()));

        if ($data->get_wc_order_id())
            $shipmentModel->setOrderId($data->get_wc_order_id());

        if ($data->get_note())
            $shipmentModel->setNote($data->get_note());

        if ($data->get_has_parcel())
            $shipmentModel->setHasParcel($data->get_has_parcel());

        if ($data->get_reference_id())
            $shipmentModel->setReferenceId($data->get_reference_id());

        if ($data->get_service_code())
            $shipmentModel->setServiceCode($data->get_service_code());

        if ($data->get_service_name())
            $shipmentModel->setServiceName($data->get_service_name());

        if ($data->get_batch_id())
            $shipmentModel->setBatchRemoteId($data->get_batch_id());

        if ($data->get_batch_local_id())
            $shipmentModel->setBatchId($data->get_batch_local_id());

        if ($data->get_cod_value())
            $shipmentModel->setCodValue($data->get_cod_value());

        if ($data->get_cod_value_currency())
            $shipmentModel->setCodValueCurrency($data->get_cod_value_currency());

        if ($data->get_cod_variable_number()) {
            $cod = $data->get_cod_variable_number();
            $shipmentModel->setCodVariableNumber($cod);
        }

        $id = $data->get_sender_address_id() ?? $data->get_sender_address_id("default");
        if ($id) {
            $sender = new AddressData();
            $sender->load($id);
            if ($sender->get_id())
                $shipmentModel->setSender(Serializer::getInstance()->denormalize($sender, SenderAddressModel::class));
        }

        $id = $data->get_recipient_address_id();
        if ($id) {
            $recipient = new AddressData();
            $recipient->load($id);
            if ($recipient->get_id())
                $shipmentModel->setRecipient(Serializer::getInstance()->denormalize($recipient, RecipientAddressModel::class));
        }
        // Parcel
        if ($data->get_parcel_id()) {
            $parcel = new ParcelData();
            $parcel->load($data->get_parcel_id());
            if ($parcel) {
                $shipmentModel->setParcel(Serializer::getInstance()->denormalize($parcel, ParcelAddressModel::class));
            }
        }

        if ($data->get_note())
            $shipmentModel->setNote($data->get_note());
        if ($data->get_age())
            $shipmentModel->setAge($data->get_age());
        if ($data->get_lock())
            $shipmentModel->setLock($data->get_lock());

        if ($data->get_import_errors())
            $shipmentModel->setImportErrors(array_filter(explode("\n", $data->get_import_errors()), "trim"));
        else
            $shipmentModel->setImportErrors([]);

        $packages = array_map(function ($item) {
            $model = new PackageData();
            $model->load($item);
            return Serializer::getInstance()->denormalize($model, PackageModel::class);
        }, $data->get_package_ids());
        if (!$packages) {
            $orderId = $shipmentModel->getOrderId();

            $model = new PackageModel();
            $model->setReferenceId($orderId);
            $model->setPhase("None");
            $package = Serializer::getInstance()->denormalize($model, PackageData::class);
            $package->set_phase("None");
            $package->store();
            $data->set_package_ids([$package->get_id()]);
            $data->store();

            $packages[] = $model;
        }
        $shipmentModel->setPackages($packages);
        return $shipmentModel;
    }


    private function OrderToModel($data, array $context = [])
    {
        $shipmentModel = new ShipmentModel();

        $shipment = new ShipmentData();


        $shipmentModel->setImportState("None");
        $shipmentModel->setOrderId($data->virtuemart_order_id);
        if ($data->order_note)
            $shipmentModel->setNote($data->order_note);

        // $dm = gmdate("ymd");
        $count = 10 - strlen("");


        $shipmentModel->setReferenceId($data->virtuemart_order_id . '#' . gmdate("YdmHis"));
        $shipmentModel->setImportErrors([]);

        list($code, $title, $isCod, $parcel) = $this->getServiceCodeFromOrder($data);

        if ($code)
            $shipmentModel->setServiceCode($code);
        if ($title)
            $shipmentModel->setServiceName($title);

        if ($isCod) {

            $variableNumber = str_pad($data->virtuemart_order_id, $count, "0", STR_PAD_LEFT);

            $currency = \VmModel::getModel('currency')->getCurrency($data->order_currency);
            $db = Factory::getContainer()->get('DatabaseDriver');

            if (strlen($variableNumber) > 10)
                $variableNumber = "";

            $shipmentModel->setCodVariableNumber($variableNumber);
            $shipmentModel->setCodValue($data->order_total);
            $shipmentModel->setCodValueCurrency($currency->currency_code_3);
        }

        $id = $shipment->get_sender_address_id("default");
        if ($id) {
            $sender = new AddressData();
            $sender->load($id);
            if ($sender->get_id())
                $shipmentModel->setSender(Serializer::getInstance()->denormalize($sender, SenderAddressModel::class));
        }

        $db = Factory::getContainer()->get('DatabaseDriver');
        $query = $db->getQuery(true)
            ->select('*')
            ->from($db->quoteName('#__virtuemart_order_userinfos'))
            ->where($db->quoteName('virtuemart_order_id') . ' = ' . (int)$data->virtuemart_order_id);

        $db->setQuery($query);
        $row = $db->loadAssoc();

        $shipmentModel->setRecipient(Serializer::getInstance()->denormalize($row, RecipientAddressModel::class));

        if ($parcel) {
            $parcel = self::getParcelshopOrderData($data->virtuemart_order_id);
            if ($parcel) {
                /**
                 * @var ParcelDataModel $parcel
                 */
                $code = $parcel->getCode();
                $country = $parcel->getCountry();
                $founded = ParcelData::getAccessPointByCode($code, $country);
                if (!$founded) {
                    $founded = new ParcelData();
                    $founded->set_country($parcel->getCountry());
                    $founded->set_code($parcel->getCode());
                    $founded->set_zip($parcel->getZipCode());
                    $founded->set_city($parcel->getCity());
                    $founded->set_type($parcel->getAccessPointType());
                    $founded->set_street($parcel->getStreet());
                    $founded->set_name($parcel->getName());
                    $founded->set_lat($parcel->getGps()->getLatitude() ?: 0);
                    $founded->set_lng($parcel->getGps()->getLongitude() ?: 0);
                    $founded->set_valid(false);
                    $founded->store();
                }
                $founded = Serializer::getInstance()->denormalize($founded, ParcelAddressModel::class);
                $shipmentModel->setParcel($founded);
                $shipmentModel->setHasParcel(true);
            }
        }

        $shipmentModel->setAge("");

        $db = Factory::getContainer()->get('DatabaseDriver');
        $query = $db->getQuery(true)
            ->select('*')
            ->from($db->quoteName('#__virtuemart_order_items'))
            ->where($db->quoteName('virtuemart_order_id') . ' = ' . (int)$data->virtuemart_order_id);

        $db->setQuery($query);
        $rows = $db->loadAssocList();

        foreach ($rows as $r) {

            $age = Serializer::getInstance()->denormalize($r, ProductModel::class);
            if ($age->getPplConfirmAge18()) {
                $shipmentModel->setAge("18");
            } else if ($age->getPplConfirmAge15()) {
                if ($shipmentModel->getAge() < 18)
                    $shipmentModel->setAge("15");
            }
            if ($shipmentModel->getAge() == "18")
                break;
        }

        $packageModel = new PackageModel();

        $packageModel->setReferenceId("{$data->virtuemart_order_id}");

        $shipmentModel->setPackages([
            $packageModel
        ]);

        return $shipmentModel;
    }

    public function ShipmentModelToShipmentData(ShipmentModel $model, $context = [])
    {
        $shipmentData = $context["data"] ?? new ShipmentData();
        if ($shipmentData->get_lock()) {
            $oldData = $shipmentData;
            $shipmentData = new ShipmentData();
            $shipmentData->set_import_state("None");
            $shipmentData->set_wc_order_id($oldData->get_wc_order_id());
        } else if (!$shipmentData->get_id()) {
            $shipmentData->set_import_state("None");
            if ($model->isInitialized("orderId"))
                $shipmentData->set_wc_order_id($model->getOrderId());
        }

        $shipmentData->set_reference_id($model->getReferenceId());
        if ($model->isInitialized("orderId"))
            $shipmentData->set_wc_order_id($model->getOrderId());

        if ($model->isInitialized("note")) {
            $shipmentData->set_note($model->getNote());
        } else {
            $shipmentData->set_note(null);
        }
        if ($model->isInitialized("sender"))
            $shipmentData->set_sender_address_id($model->getSender()->getId());

        if ($model->isInitialized("serviceCode")) {
            $shipmentData->set_service_code($model->getServiceCode());
            $serviceCode = $model->getServiceCode();

            $method = MethodSetting::getMethod($serviceCode);

            $shipmentData->set_service_name($method->getTitle());

            if ($method->getCodAvailable()) {
                if ($model->isInitialized("codVariableNumber"))
                    $shipmentData->set_cod_variable_number($model->getCodVariableNumber());
                if ($model->isInitialized("codValue"))
                    $shipmentData->set_cod_value($model->getCodValue());
                if ($model->isInitialized("codValueCurrency"))
                    $shipmentData->set_cod_value_currency($model->getCodValueCurrency());

            } else {
                $shipmentData->set_cod_variable_number(null);
                $shipmentData->set_cod_value(null);
                $shipmentData->set_cod_value_currency(null);
            }

            if ($method->getParcelRequired()) {
                if ($model->isInitialized("hasParcel") && $model->getHasParcel()) {
                    $shipmentData->set_has_parcel(true);
                    if ($model->isInitialized("parcel")) {
                        $parcel = $model->getParcel();
                        $shipmentData->set_parcel_id($parcel->getId());
                    }

                } else {
                    $shipmentData->set_has_parcel(false);
                }
            } else {
                $shipmentData->set_has_parcel(false);
            }
        }

        if ($model->isInitialized("packages")) {
            $modelPackages = $model->getPackages();
            foreach ($modelPackages as $key => $package) {
                if ($package->getId()) {
                    $packageData = new PackageData($package->getId());
                } else {
                    $packageData = null;
                }
                $modelPackages[$key] = Serializer::getInstance()->denormalize($package, PackageData::class, null, array("data" => $packageData));
                if (!$modelPackages[$key]->get_phase())
                    $modelPackages[$key]->set_phase("None");
                $modelPackages[$key]->store();

                $modelPackages[$key] = $modelPackages[$key]->get_id();
            }
            $shipmentData->set_package_ids($modelPackages);
        }

        if ($model->isInitialized("recipient")) {
            $recipient = Serializer::getInstance()->denormalize($model->getRecipient(), AddressData::class);
            if (!$recipient->get_id())
                $recipient->store();
            $shipmentData->set_recipient_address_id($recipient->get_id());
        }

        return $shipmentData;

    }

    public function UpdateShipmentToData(UpdateShipmentModel $model, $context = [])
    {
        $shipmentData = new ShipmentData();
        $shipmentData->load($context["data"]);

        if ($shipmentData->get_lock()) {
            $oldData = $shipmentData;
            $shipmentData = new ShipmentData();
            $shipmentData->set_import_state("None");
            $shipmentData->set_wc_order_id($oldData->get_wc_order_id());
        } else if (!$shipmentData->get_id()) {
            $shipmentData->set_import_state("None");
            if ($model->isInitialized("orderId"))
                $shipmentData->set_wc_order_id($model->getOrderId());
        }

        if ($model->getReferenceId())
            $shipmentData->set_reference_id($model->getReferenceId());
        if ($model->isInitialized("orderId"))
            $shipmentData->set_wc_order_id($model->getOrderId());

        if ($model->isInitialized("age")) {
            $shipmentData->set_age($model->getAge());
        } else {
            $shipmentData->set_age(null);
        }

        if ($model->isInitialized("note")) {
            $shipmentData->set_note($model->getNote());
        } else {
            $shipmentData->set_note(null);
        }

        if ($model->isInitialized("senderId")) {
            $shipmentData->set_sender_address_id($model->getSenderId());
        }

        if ($model->isInitialized("serviceCode")) {
            $shipmentData->set_service_code($model->getServiceCode());
            $serviceCode = $model->getServiceCode();

            $method = MethodSetting::getMethod($serviceCode);

            $shipmentData->set_service_name($method->getTitle());

            if ($method->getCodAvailable()) {
                if ($model->isInitialized("codVariableNumber"))
                    $shipmentData->set_cod_variable_number($model->getCodVariableNumber());
                if ($model->isInitialized("codValue"))
                    $shipmentData->set_cod_value($model->getCodValue());
                if ($model->isInitialized("codValueCurrency"))
                    $shipmentData->set_cod_value_currency($model->getCodValueCurrency());

            } else {
                $shipmentData->set_cod_variable_number(null);
                $shipmentData->set_cod_value(null);
                $shipmentData->set_cod_value_currency(null);
            }

            if ($method->getParcelRequired()) {
                if ($model->isInitialized("hasParcel") && $model->getHasParcel()) {
                    $shipmentData->set_has_parcel(true);
                    if ($model->isInitialized("parcelId")) {
                        $parceldata = new ParcelData();
                        $parceldata->load($model->getParcelId());
                        if ($parceldata->get_id()) {
                            $shipmentData->set_parcel_id($parceldata->get_id());
                        }

                    }
                } else {
                    $shipmentData->set_has_parcel(false);
                }
            } else {
                $shipmentData->set_has_parcel(false);
                $shipmentData->set_parcel_id(null);
            }
        }

        if ($model->isInitialized("packages")) {
            $modelPackages = $model->getPackages();
            foreach ($modelPackages as $key => $package) {
                if ($package->isInitialized("id") && $package->getId()) {
                    $packageData = new PackageData();
                    $packageData->load($package->getId());
                } else {
                    $packageData = null;
                }
                $modelPackages[$key] = Serializer::getInstance()->denormalize($package, PackageData::class, null, array("data" => $packageData));
                if (!$modelPackages[$key]->get_phase())
                    $modelPackages[$key]->set_phase("None");
                $modelPackages[$key]->store();

                $modelPackages[$key] = $modelPackages[$key]->get_id();
            }
            $shipmentData->set_package_ids($modelPackages);
        }

        if (!$shipmentData->get_id()) {
            if ($shipmentData->get_wc_order_id()) {

                $order = \VmModel::getModel('orders');
                $order = $order->getTable('orders');
                $order->load($shipmentData->get_wc_order_id());

                /**
                 * @var ShipmentModel $normalizer
                 */
                $normalizer = Serializer::getInstance()->denormalize($order, ShipmentModel::class);
                if ($normalizer->isInitialized('recipient')) {
                    $recipient = $normalizer->getRecipient();
                    $recipient = Serializer::getInstance()->denormalize($recipient, AddressData::class);
                    $recipient->store();
                    $shipmentData->set_recipient_address_id($recipient->get_id());
                }
            }
        }

        return $shipmentData;
    }

    public function UpdateShipmentSenderToData(UpdateShipmentSenderModel $sender, $context)
    {
        /**
         * @var ShipmentData $shipment
         */
        if (!isset($context['data']))
            throw new \Exception("Undefined shipment");
        $shipment = $context["data"];
        if ($sender->isInitialized("senderId")) {
            $addresses = AddressData::get_default_sender_addresses();
            $address = reset($addresses);

            if ($address && $address->get_id() && $address->get_id() == $sender->getSenderId())
                $shipment->set_sender_address_id(null);
            else
                $shipment->set_sender_address_id($sender->getSenderId());
        }
        return $shipment;
    }

    public function UpdateRecipientToData(RecipientAddressModel $recipientAddressModel, $context)
    {
        if (!isset($context["data"]))
            throw new \Exception("Undefined shipment");
        $shipment = $context["data"];
        /**
         * @var ShipmentData $shipment
         */
        $id = $shipment->get_recipient_address_id();
        $founded = new AddressData();
        $founded->load($id);
        $founded->set_type("recipient");
        $address = Serializer::getInstance()->denormalize($recipientAddressModel, AddressData::class, null, ["data" => $founded]);
        $address->store();
        $shipment->set_recipient_address_id($address->get_id());
        return $shipment;
    }

    public function denormalize($data, string $type, ?string $format = null, array $context = [])
    {
        if ($data instanceof ShipmentData && $type == ShipmentModel::class) {
            return $this->ShipmentDataToModel($data, $context);
        } else if ($data instanceof TableOrders && $type == ShipmentModel::class) {
            return $this->OrderToModel($data, $context);
        } else if ($data instanceof ShipmentModel && $type == ShipmentData::class) {
            return $this->ShipmentModelToShipmentData($data, $context);
        } else if ($data instanceof UpdateShipmentModel && $type === ShipmentData::class) {
            return $this->UpdateShipmentToData($data, $context);
        } else if ($data instanceof UpdateShipmentSenderModel && $type === ShipmentData::class) {
            return $this->UpdateShipmentSenderToData($data, $context);
        } else if ($data instanceof RecipientAddressModel && $type === ShipmentData::class) {
            return $this->UpdateRecipientToData($data, $context);
        }
    }

    public function supportsDenormalization($data, string $type, ?string $format = null)
    {
        if ($data instanceof ShipmentData && $type === ShipmentModel::class)
            return true;
        if ($data instanceof TableOrders && $type === ShipmentModel::class)
            return true;
        if ($data instanceof UpdateShipmentModel && $type === ShipmentData::class)
            return true;
        if ($data instanceof UpdateShipmentSenderModel && $type === ShipmentData::class)
            return true;
        if ($data instanceof RecipientAddressModel && $type === ShipmentData::class)
            return true;
        if ($data instanceof ShipmentModel && $type == ShipmentData::class) {
            return true;
        }

        return false;

    }
}