<?php
namespace PPLCZ\ModelNormalizer;

defined('_JEXEC') or die;

use PPLCZ\Admin\CPLOperation;
use PPLCZ\Data\ShipmentData;
use PPLCZ\Model\Model\CategoryModel;
use PPLCZ\Model\Model\ErrorLogCategorySettingModel;
use PPLCZ\Model\Model\ErrorLogItemModel;
use PPLCZ\Model\Model\ErrorLogModel;
use PPLCZ\Model\Model\ErrorLogProductSettingModel;
use PPLCZ\Model\Model\ErrorLogShipmentSettingModel;
use PPLCZ\Model\Model\ProductModel;
use PPLCZ\Model\Model\ShipmentMethodSettingModel;
use PPLCZ\Model\Model\ShipmentModel;
use Joomla\CMS\Factory;
use PPLCZ\Setting\ApiSetting;
use PPLCZ\Setting\MethodSetting;
use PPLCZVendor\Symfony\Component\Serializer\Normalizer\DenormalizerInterface;

require_once __DIR__ . '/../globals.php';

class ErrorLogDenormalizer implements DenormalizerInterface
{


    private function getOrder($orderId)
    {
        // Načtení VirtueMart objednávky
        if (!class_exists('VirtueMartModelOrders')) {
            return null;
        }

        $orderModel = \VmModel::getModel('orders');
        $order = $orderModel->getOrder($orderId);

        if (!$order)
            return null;

        $export['id'] = $order['details']['BT']->virtuemart_order_id;
        $export['status'] = $order['details']['BT']->order_status;
        $export['currency'] = $order['details']['BT']->order_currency;
        $export['payment_method'] = $order['details']['BT']->virtuemart_paymentmethod_id;
        $export['payment_method_title'] = $order['details']['BT']->payment_name ?? '';
        $export['shipping_total'] = $order['details']['BT']->order_shipment ?? 0;
        $export['discount_total'] = $order['details']['BT']->order_discount ?? 0;
        $export['cart_tax'] = $order['details']['BT']->order_tax ?? 0;
        $export['shipping_tax'] = $order['details']['BT']->order_shipment_tax ?? 0;
        $export['total'] = $order['details']['BT']->order_total;
        $export['date_created'] = $order['details']['BT']->created_on;
        $export['date_modified'] = $order['details']['BT']->modified_on;
        $export['customer_ip'] = $order['details']['BT']->customer_ip ?? '';
        $export['customer_user'] = $order['details']['BT']->virtuemart_user_id;

        // Fakturační adresa (BT = Bill To)
        $bt = $order['details']['BT'];
        $export['billing'] = [
            'first_name' => $bt->first_name ?? '',
            'last_name' => $bt->last_name ?? '',
            'company' => $bt->company ?? '',
            'email' => $bt->email ?? '',
            'phone' => $bt->phone_1 ?? '',
            'address_1' => $bt->address_1 ?? '',
            'address_2' => $bt->address_2 ?? '',
            'city' => $bt->city ?? '',
            'postcode' => $bt->zip ?? '',
            'state' => $bt->virtuemart_state_id ?? '',
            'country' => $bt->virtuemart_country_id ?? '',
        ];

        // Dodací adresa (ST = Ship To)
        $st = isset($order['details']['ST']) ? $order['details']['ST'] : $bt;
        $export['shipping'] = [
            'first_name' => $st->first_name ?? '',
            'last_name' => $st->last_name ?? '',
            'company' => $st->company ?? '',
            'address_1' => $st->address_1 ?? '',
            'address_2' => $st->address_2 ?? '',
            'city' => $st->city ?? '',
            'postcode' => $st->zip ?? '',
            'state' => $st->virtuemart_state_id ?? '',
            'country' => $st->virtuemart_country_id ?? '',
        ];

        // Položky objednávky
        $export['items'] = [];
        if (isset($order['items'])) {
            foreach ($order['items'] as $item) {
                $export['items'][] = [
                    'item_id' => $item->virtuemart_order_item_id ?? 0,
                    'product_id' => $item->virtuemart_product_id ?? 0,
                    'variation_id' => 0, // VirtueMart nemá varianty stejně jako WooCommerce
                    'name' => $item->order_item_name ?? '',
                    'quantity' => $item->product_quantity ?? 0,
                    'subtotal' => $item->product_item_price ?? 0,
                    'total' => $item->product_final_price ?? 0,
                    'tax' => $item->product_tax ?? 0,
                    'sku' => $item->product_sku ?? '',
                    'meta' => [], // VirtueMart metadata by se musela načíst zvlášť
                ];
            }
        }

        // Doprava
        $export['shipping_lines'] = [];
        if (isset($order['calc_rules'])) {
            foreach ($order['calc_rules'] as $rule) {
                if (strpos($rule->calc_kind, 'shipment') !== false) {
                    $export['shipping_lines'][] = [
                        'method_title' => $rule->calc_name ?? '',
                        'total' => $rule->calc_amount ?? 0,
                        'tax' => 0, // Daň ze dopravy by se musela vypočítat
                        'meta' => [],
                    ];
                }
            }
        }

        // Poplatky
        $export['fees'] = [];
        if (isset($order['calc_rules'])) {
            foreach ($order['calc_rules'] as $rule) {
                if (strpos($rule->calc_kind, 'payment') !== false) {
                    $export['fees'][] = [
                        'name' => $rule->calc_name ?? '',
                        'total' => $rule->calc_amount ?? 0,
                        'tax' => 0,
                        'meta' => [],
                    ];
                }
            }
        }

        // Metadata
        $export['meta_data'] = [];

        $shipments = null;
        try {
            $shipments = ShipmentData::read_order_shipments($export['id']);
            foreach ($shipments as $k => $shipment) {
                $shipments[$k] = pplcz_normalize(pplcz_denormalize($shipment, ShipmentModel::class));
            }
        } catch (\Throwable $ex)
        {
            $shipments = "Error with getting existing ppl shipments\n"
                . $ex->getMessage() . "\n"
                . $ex->getFile() . "\n"
                . $ex->getLine();
        }

        $orderShipments = null;

        try {
            // V Joomla/VirtueMart denormalizujeme export array
            $orderShipments = pplcz_normalize(pplcz_denormalize($export, ShipmentModel::class));
        }
        catch (\Throwable $ex)
        {
            $orderShipments = "Error with creating ppl shipment from order \n"
                . $ex->getMessage() . "\n"
                . $ex->getFile() . "\n"
                . $ex->getLine();
        }

        $export['pplshipments'] = [
            "shipments" => $shipments,
            "orderShipments" => $orderShipments
        ];

        return $export;
    }
    public function denormalize($data, string $type, ?string $format = null, array $context = [])
    {
        /**
         * @var ErrorLogModel $data
         */

        $client_id = null;
        $client_secret = null;
        $accessToken = null;
        try {
            $apisetting = ApiSetting::getApi();
            $client_id = $apisetting->getClientId();
            $client_secret = $apisetting->getClientSecret();

            if ($client_id && $client_secret) {
                $accessToken = (new CPLOperation())->getAccessToken();
            }
        } catch (\Error $e) {

        }


        // Načtení Joomla extensions (podobné jako WordPress plugins)
        $db = \Joomla\CMS\Factory::getContainer()->get('DatabaseDriver');
        $query = $db->getQuery(true);
        $query->select('name, element, type, manifest_cache')
            ->from($db->quoteName('#__extensions'))
            ->where($db->quoteName('enabled') . ' = 1')
            ->where($db->quoteName('type') . ' IN (' . $db->quote('component') . ',' . $db->quote('plugin') . ',' . $db->quote('module') . ')');

        $db->setQuery($query);
        $extensions = $db->loadObjectList();

        $plugins = [];
        foreach ($extensions as $ext) {
            $manifest = json_decode($ext->manifest_cache);
            $version = isset($manifest->version) ? $manifest->version : 'Unknown';
            $plugins[] = $ext->name . ' - ' . $version . ' (' . $ext->element . ')';
            if ($ext->element === 'com_virtuemart'){
                $vmVersion = $version;
            }
        }

        $joomlaVersion = JVERSION;
        $php = phpversion();

        // Načtení VirtueMart shipping metod (pro PPL)
        $shipmentSettings = [];

        $query = $db->getQuery(true);
        $query->select('*')
            ->from($db->quoteName('#__virtuemart_shipmentmethods'))
            ->where($db->quoteName('published') . ' = 1');

        try {
            $db->setQuery($query);
            $vmShipmentMethods = $db->loadObjectList();

            foreach ($vmShipmentMethods as $vmMethod) {
                // Zkontrolovat, jestli je to PPL metoda
                if (strpos($vmMethod->shipment_element, 'pplcz') !== false || strpos($vmMethod->shipment_element, 'pplshipping') !== false) {
                    $shipmentMethodId = $vmMethod->virtuemart_shipmentmethod_id;

                    // Načtení PPL params z #__pplcz_shipment_method
                    $pplQuery = $db->getQuery(true);
                    $pplQuery->select('params')
                        ->from($db->quoteName('#__pplcz_shipment_method'))
                        ->where($db->quoteName('virtuemart_shipmentmethod_id') . ' = ' . (int)$shipmentMethodId);

                    $db->setQuery($pplQuery);
                    $pplParams = $db->loadResult();

                    if ($pplParams) {
                        // Parsování params jako Registry
                        $registry = new \Joomla\Registry\Registry();
                        $registry->loadString($pplParams);
                        $paramsArray = $registry->toArray();

                        // Denormalizace do ShipmentMethodSettingModel
                        try {
                            $shipmentMethodSetting = pplcz_denormalize($paramsArray, ShipmentMethodSettingModel::class);

                            $shipmentSetting = new ErrorLogShipmentSettingModel();
                            $shipmentSetting->setShipmentSetting($shipmentMethodSetting);
                            $shipmentSetting->setName($shipmentMethodSetting->getTitle());
                            $shipmentSettings[] = $shipmentSetting;
                        } catch (\Exception $e) {
                            // Pokud denormalizace selže, přidáme alespoň basic info
                            $shipmentSetting = new ErrorLogShipmentSettingModel();
                            $shipmentSetting->setName($paramsArray['title'] . ' (Error: ' . $e->getMessage() . ')');
                            $shipmentSettings[] = $shipmentSetting;
                        }
                    }
                }
            }
        } catch (\Exception $e) {
            // Ignorovat chybu, pokud tabulka neexistuje
        }

        $data->setShipmentsSetting($shipmentSettings);

        // Načtení VirtueMart kategorií
        $vmLang = defined('VMLANG') ? VMLANG : 'en_gb'; // Fallback na en_gb pokud VMLANG není definována
        $query = $db->getQuery(true);
        $query->select('*')
            ->from($db->quoteName('#__virtuemart_categories'))
            ->where($db->quoteName('published') . ' = 1');

        $output = [];

        try {
            $db->setQuery($query);
            $categories = $db->loadObjectList();

            foreach ($categories as $category) {
                /**
                 * @var CategoryModel $cat
                 */
                // Konverze stdClass na array pro denormalizer
                $categoryArray = json_decode(json_encode($category), true);
                $cat = pplcz_denormalize($categoryArray, CategoryModel::class);
                if ($cat) {
                    $setting = new ErrorLogCategorySettingModel();
                    $setting->setName($category->category_name ?? 'Unnamed');
                    $setting->setId($category->virtuemart_category_id);
                    $setting->setSetting($cat);

                    if (isset($category->category_parent_id) && $category->category_parent_id)
                        $setting->setParent($category->category_parent_id);
                    $output[] = $setting;
                }
            }
        } catch (\Exception $e) {
            // Ignorovat chybu, pokud tabulka neexistuje
        }

        $data->setCategorySetting($output);

        $data->setGlobalParcelSetting(MethodSetting::getGlobalParcelboxesSetting());

        $data->setOrders([]);

        if (isset($context['order_ids']) && $context['order_ids']) {
            $orders = [];
            $product_ids = [];
            foreach ($context['order_ids'] as $orderId)
            {
                $order = $this->getOrder($orderId);
                if ($order) {
                    $product_ids = array_merge($product_ids, array_map(function ($item) {
                        return $item['product_id'];
                    }, $order['items']));
                    $orders[] = $order;
                }
            }

            if (!isset($context['product_ids']))
                $context['product_ids'] = [];

            $context['product_ids'] = array_unique(array_merge($context['product_ids'], $product_ids));

            $data->setOrders($orders);
        }

        $products = [];

        $get_product = function ($id) use ($db)
        {
            // Načtení VirtueMart produktu
//            $vmLang = defined('VMLANG') ? VMLANG : 'en_gb'; // Fallback na en_gb pokud VMLANG není definována
            $query = $db->getQuery(true);
            $query->select('*')
                ->from($db->quoteName('#__virtuemart_products'))
                ->where($db->quoteName('virtuemart_product_id') . ' = ' . (int)$id);

            $query2 = $db->getQuery(true);
            $query2->select('product_name')
                ->from($db->quoteName('#__virtuemart_products_en_gb'))
                ->where($db->quoteName('virtuemart_product_id') . ' = ' . (int)$id);

            try {
                $db->setQuery($query);
                $product = $db->loadObject();

                $db->setQuery($query2);
                $productName = $db->loadObject();

                if ($product) {
                    $productSetting = new ErrorLogProductSettingModel();
                    $productSetting->setId($product->virtuemart_product_id);
                    $productSetting->setName($productName->product_name ?? 'Unnamed');
                    $productSetting->setParent($product->product_parent_id ?? 0);

                    // Konverze stdClass na array pro denormalizer
                    $productArray = json_decode(json_encode($product), true);
                    $productSetting->setSetting(pplcz_denormalize($productArray, ProductModel::class));

                    // Načtení kategorií produktu
                    $catQuery = $db->getQuery(true);
                    $catQuery->select('virtuemart_category_id')
                        ->from($db->quoteName('#__virtuemart_product_categories'))
                        ->where($db->quoteName('virtuemart_product_id') . ' = ' . (int)$id);

                    $db->setQuery($catQuery);
                    $categoryIds = $db->loadColumn();

                    if (!empty($categoryIds)) {
                        $productSetting->setCategoryIds($categoryIds);
                    }

                    return $productSetting;
                }
            } catch (\Exception $e) {
                // Ignorovat chybu
            }

            return null;
        };

        if (isset($context['product_ids']) && is_array($context['product_ids'])) {
            foreach ($context['product_ids'] as $product_id)
            {
                $products[$product_id] = call_user_func($get_product, $product_id);
            }
        }

        $data->setProductsSetting(array_filter($products));

        if ($accessToken)
            $accessToken = "ano";
        else
            $accessToken = "ne";

        $summary = [
            "### Přístup",
            "Client ID: $client_id",
            "Získá accessToken: {$accessToken}",
            "***",
            "### Verze",
            "Joomla: $joomlaVersion",
            "PHP: $php",
            "VirtueMart: " . ($vmVersion ?: 'Unknown'),
            "***",
            "### Extensions",
            join("\n", $plugins)
        ];

        // Načtení admin emailu z Joomla config
        $app = Factory::getApplication();
        $config = $app->getConfig();
        $adminEmail = $config->get('mailfrom', '');

        $data->setMail($adminEmail);
        $data->setInfo(join("\n", $summary));
        $items = [];

        // Načtení logů z databáze
        $query = $db->getQuery(true);
        $query->select('*')
            ->from($db->quoteName('#__pplcz_log'))
            ->order('timestamp DESC');

        try {
            $db->setQuery($query);
            $logs = $db->loadObjectList();

            foreach ($logs as $log) {
                $item = new ErrorLogItemModel();
                $item->setTrace($log->message ?? '');
                $item->setId($log->ppl_log_id);
                $items[] = $item;
            }
        } catch (\Exception $e) {
            // Ignorovat chybu, pokud tabulka neexistuje
        }

        $data->setErrors($items);

        return $data;
    }

    public function supportsDenormalization($data, string $type, ?string $format = null)
    {
        return $data instanceof ErrorLogModel && $type === ErrorLogModel::class;
    }
}