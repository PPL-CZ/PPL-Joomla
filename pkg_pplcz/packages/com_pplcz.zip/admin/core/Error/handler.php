<?php

defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Table\Table;
use Joomla\Registry\Registry;

/**
 * Format function arguments for stack trace display
 *
 * @param array $args Function arguments
 * @return string Formatted arguments string
 */
function pplcz_format_args($args)
{
    $formatted = [];
    foreach ($args as $arg) {
        if (is_object($arg)) {
            $formatted[] = get_class($arg);
        } elseif (is_array($arg)) {
            $formatted[] = 'Array(' . count($arg) . ')';
        } elseif (is_resource($arg)) {
            $formatted[] = 'Resource';
        } elseif (is_null($arg)) {
            $formatted[] = 'NULL';
        } elseif (is_bool($arg)) {
            $formatted[] = $arg ? 'true' : 'false';
        } elseif (is_string($arg)) {
            $formatted[] = "'" . (mb_strlen($arg) > 70 ? mb_substr($arg, 0, 70) . '...' : $arg) . "'";
        } else {
            $formatted[] = (string)$arg;
        }
    }
    return join(', ', $formatted);
}

/**
 * Get error count from component params
 *
 * @return int Current error count
 */
function pplcz_get_error_count()
{
    $table = Table::getInstance('extension');
    $table->load(['element' => 'com_pplcz', 'type' => 'component']);

    $params = new Registry($table->params);
    return intval($params->get('pplcz_error_log_count', 0));
}

/**
 * Get error hashes from component params
 *
 * @return string Comma-separated hash list
 */
function pplcz_get_error_hashes()
{
    $table = Table::getInstance('extension');
    $table->load(['element' => 'com_pplcz', 'type' => 'component']);

    $params = new Registry($table->params);
    return $params->get('pplcz_error_log_hashes', '');
}

/**
 * Update component parameter value
 *
 * @param string $key Parameter key
 * @param mixed $value Parameter value
 * @return bool Success status
 */
function pplcz_update_component_param($key, $value)
{
    try {
        $table = Table::getInstance('extension');
        $table->load(['element' => 'com_pplcz', 'type' => 'component']);

        $params = new Registry($table->params);
        $params->set($key, $value);
        $table->params = $params->toString();

        return $table->store();
    } catch (\Throwable $ex) {
        return false;
    }
}

/**
 * Increment error count and add hash to component params
 *
 * @param int|null $logId Database log ID (for compatibility, not used in Joomla)
 * @param string $hash Error hash
 * @return bool Success status
 */
function pplcz_add_log_to_options($logId, $hash)
{
    try {
// Increment error count
        $count = pplcz_get_error_count();
        pplcz_update_component_param('pplcz_error_log_count', $count + 1);

// Add hash to list if not already present
        $hashes = pplcz_get_error_hashes();
        if (strpos($hashes, $hash) === false) {
            $newHashes = trim($hashes . ',' . $hash, ',');

// Keep only last 100 hashes (prevent params from growing too large)
            $hashArray = explode(',', $newHashes);
            if (count($hashArray) > 100) {
                $hashArray = array_slice($hashArray, -100);
                $newHashes = implode(',', $hashArray);
            }

            pplcz_update_component_param('pplcz_error_log_hashes', $newHashes);
        }

        return true;
    } catch (\Throwable $ex) {
        return false;
    }
}

/**
 * Custom error handler - captures non-fatal PHP errors
 *
 * @param int $errno Error level
 * @param string $errstr Error message
 * @param string $errfile File where error occurred
 * @param int $errline Line number where error occurred
 * @return void
 */
function pplcz_error_handler($errno, $errstr, $errfile, $errline)
{
// Prevent recursive error handling
    static $resolve;

    if ($resolve) {
        return;
    }

    $resolve = true;

    if($errno === E_DEPRECATED || $errno === E_USER_DEPRECATED) {
        $resolve = false;
        return;
    }


// Build stack trace
    $backtrace = debug_backtrace();
    $path = realpath(__DIR__ . '/../../');  // Path to com_pplcz/admin
    $inplugin = strpos($errfile, $path) !== false;

    $out = [
        $errstr,
        "Stack trace:",
    ];

    foreach ($backtrace as $key => $frame) {
        $file = "emptyfile";
        if (isset($frame['file'])) {
            $file = $frame['file'];
        }

// Check if any frame is in our component
        $inplugin = $inplugin || strpos($file, $path) !== false;

        $file = isset($frame['file']) ? $frame['file'] : '[internal function]';
        $line = isset($frame['line']) ? $frame['line'] : '';
        $function = isset($frame['function']) ? $frame['function'] : '';
        $args = isset($frame['args']) ? pplcz_format_args($frame['args']) : '';
        $out[] = "#$key $file($line): $function($args)";
    }

// Only log errors from our component
    if ($inplugin) {
        $max = pplcz_get_error_count();
        $hashes = pplcz_get_error_hashes();
        $error = $errstr . "\n" . join("\n", $out);
        $hash = sha1($error);

// Check rate limit and deduplication
        if ($max < 100 && strpos("$hashes", $hash) === false) {
            try {
// Save to database using LogData
                $logdata = new \PPLCZ\Data\LogData();
                $logdata->set_message($error);
                $logdata->set_errorhash($hash);
                $logdata->set_timestamp(date('Y-m-d H:i:s'));
                $logdata->store();

// Update component params
                pplcz_add_log_to_options($logdata->get_id(), $logdata->get_errorhash());
            } catch (\Throwable $ex) {
// Silent fail - don't create cascade of errors
            }
        }
    }

    $resolve = false;
}

/**
 * Shutdown handler - captures fatal PHP errors
 *
 * Called when PHP script terminates (including fatal errors)
 *
 * @return void
 */
function pplcz_shutdown_handler()
{
// Prevent recursive error handling
    static $resolve;
    if ($resolve) {
        return;
    }
    $resolve = true;

    $error = error_get_last();
    if ($error) {
        $message = explode("\n", $error['message']);
        $path = realpath(__DIR__ . '/../../');  // Path to com_pplcz/admin

// Check if error is from our component
        $inComponent = array_filter($message, function ($item) use ($path) {
            return strpos($item, $path) !== false;
        });

        if ($inComponent) {
            $max = pplcz_get_error_count();
            $hashes = pplcz_get_error_hashes();
            $hash = sha1($error['message']);

// Check rate limit and deduplication
            if ($max < 100 && strpos("$hashes", $hash) === false) {
                try {
// Save to database using LogData
                    $logdata = new \PPLCZ\Data\LogData();
                    $logdata->set_message($error['message']);
                    $logdata->set_errorhash(sha1($error['message']));
                    $logdata->set_timestamp(date('Y-m-d H:i:s'));
                    $logdata->store();

// Update component params
                    pplcz_add_log_to_options($logdata->get_id(), $logdata->get_errorhash());
                } catch (\Throwable $ex) {
// Silent fail - don't create cascade of errors
                }
            }
        }
    }

    $resolve = false;
}

// Register error handlers with PHP
set_error_handler("pplcz_error_handler");
register_shutdown_function("pplcz_shutdown_handler");