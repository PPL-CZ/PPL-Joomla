<?php

namespace PPLCZ\Admin\Order;
defined("_JEXEC") or die();


use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use PPLCZ\Admin\Page\OptionPage;
use PPLCZ\ModelNormalizer\ShipmentDataDenormalizer;
use PPLCZCPL\ApiException;
use PPLCZ\Admin\Assets\JsTemplate;
use PPLCZ\Admin\CPLOperation;
use PPLCZ\Data\AddressData;
use PPLCZ\Data\PackageData;
use PPLCZ\Data\ShipmentData;
use PPLCZ\Admin\Errors;
use PPLCZ\Model\Model\SenderAddressModel;
use PPLCZ\Model\Model\ShipmentModel;
use PPLCZ\Serializer;
use PPLCZ\Traits\ParcelDataModelTrait;
use PPLCZ\Validator\Validator;
use PPLCZ\Template\Template;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\Event\Dispatcher;


require_once JPATH_ADMINISTRATOR . '/components/com_pplcz/core/globals.php';


class OrderPanel
{

    use ParcelDataModelTrait;

    public static function render($order)
    {

        $shipments = ShipmentData::read_order_shipments($order->virtuemart_order_id);

        foreach ($shipments as $key => $shipment) {
            $shipments[$key] = Serializer::getInstance()->denormalize($shipment, ShipmentModel::class);
        }

        if (!$shipments) {
//            if (self::hasPPLShipment($order))
            $shipments = [Serializer::getInstance()->denormalize($order, ShipmentModel::class)];
//                $shipments = Serializer::getInstance()->denormalize($order, ShipmentModel::class);
        }

        $jsShipments = [];
        $jsShipmentsOk = [];
        $jsShipmentsErrors = [];
        $jsImage = [];
        $batchs = [];

        // Načíst batch_local_id před převodem na model
        $batchLocalIds = [];
        $shipmentDataList = ShipmentData::read_order_shipments($order->virtuemart_order_id);
        foreach ($shipmentDataList as $key => $shipmentData) {
            $batchLocalIds[$key] = $shipmentData->get_batch_local_id();
        }

        foreach ($shipments as $key => $shipment) {
            // Vytvořit Joomla URL pro navigaci na batch detail v MuiAdmin
            if (isset($batchLocalIds[$key]) && $batchLocalIds[$key]) {
                $baseUrl = \Joomla\CMS\Uri\Uri::base();
                $batchs[$key] = $baseUrl . "index.php?option=com_pplcz&view=dashboard#/batch/" . $batchLocalIds[$key];
            } else {
                $batchs[$key] = false;
            }
            $jsShipments[$key] = Serializer::getInstance()->normalize($shipment, "array");
            /**
             * @var ShipmentModel $shipment
             */
            if ($shipment->getHasParcel()) {
                if ($shipment->getParcel()) {
                    $parcel = $shipment->getParcel();
                    if ($parcel->getType() === "parcelshop") {
                        $jsImage[$key] = pplcz_asset_icon("parcelshop_2609x1033.png");
                    } else {
                        $jsImage[$key] = pplcz_asset_icon("parcelbox_2625x929.png");
                    }
                }
            }
            if (!isset($jsImage[$key])) {
                $jsImage[$key] = pplcz_asset_icon("ppldhl_4084x598.png?height=20");
            }
        }

        foreach ($shipments as $key => $shipment) {
            $tests = new Errors();
            pplcz_validate($shipment, $tests, "");
            if ($tests->hasErrors()) {
                $jsShipmentsOk[$key] = false;
                $jsShipmentsErrors[$key] = $tests->getErrors();
            } else {
                $jsShipmentsOk[$key] = true;
                $jsShipmentsErrors[$key] = [];
            }
        }

        JsTemplate::scripts();

        $params = ComponentHelper::getParams('com_pplcz');
        $availablePrinters = (new CPLOperation())->getAvailableLabelPrinters();
        $format = (new CPLOperation())->getFormat($params->get(pplcz_create_name("print_setting"), ""));

        $output = Template::render("order-panel.php", [
            "availablePrinters" => $availablePrinters,
            "selectedPrint" => $format,
            "order" => $order,
            "shipments" => $shipments,
            "jsShipments" => $jsShipments,
            "jsShipmentsOk" => $jsShipmentsOk,
            "jsShipmentsErrors" => $jsShipmentsErrors,
            "jsImage" => $jsImage,
            "batchs" => $batchs,
            "nonce" => md5(uniqid())
        ]);

        return $output;
    }

    public static function rerender()
    {
        ob_start();
        $app = Factory::getApplication();

        $user = $app->getIdentity();
        if ($user->guest) {
            throw new \Exception('Unauthorized', 401);
        }

        if (!$user->authorise('core.admin', 'com_pplcz')) {
            throw new \Exception('Forbidden', 403);
        }

        $id = $app->input->getInt('order_id');

        $order = \VmModel::getModel('orders');
        $order = $order->getTable('orders');
        $order->load($id);

        PluginHelper::importPlugin('vmshipment');

        $dispatcher = Factory::getApplication()->getDispatcher();

        // Zavolání události
        $results = $dispatcher->dispatch('plgVmOnShowOrderBEShipment', new \Joomla\Event\Event(
            'plgVmOnShowOrderBEShipment', array(
                $id,
                $order->virtuemart_shipmentmethod_id)
        ));
        $pluginHtml = '';
        // $results obsahuje pole s výsledky ze všech pluginů
        foreach ($results as $result) {
            if (!empty($result)) {
                $pluginHtml .= $result; // HTML výstup z pluginu
            }
        }

        $html = self::render($order);

        // Zachytit jakýkoliv neočekávaný výstup
        $unexpectedOutput = ob_get_clean();

        // Pokud render() vrátil string a nic nevypsal, použít return hodnotu
        // Pokud render() vypsal HTML, použít to co bylo vypsáno
        if ($unexpectedOutput) {
            $html = $unexpectedOutput;
        }

        $app->setHeader('Content-Type', 'application/json', true);

        echo json_encode([
            "success" => true,
            "_debug" => [
                "controller" => "OrderPanel::rerender",
                "unexpectedOutputLength" => strlen($unexpectedOutput),
                "htmlLength" => strlen($html)
            ],
            "data" => [
                "html" => $pluginHtml . $html
            ]
        ]);
    }

}