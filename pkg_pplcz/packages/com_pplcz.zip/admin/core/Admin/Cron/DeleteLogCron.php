<?php
namespace PPLCZ\Admin\Cron;
defined("_JEXEC") or die();

use Joomla\CMS\Factory;
use Joomla\Registry\Registry;

class DeleteLogCron {

    /**
     * Delete old log entries, keeping only the most recent 30
     */
    public static function delete_logs()
    {
        $db = Factory::getContainer()->get('DatabaseDriver');

        // First, get IDs of the 30 most recent logs to keep
        $keepQuery = $db->getQuery(true)
            ->select('ppl_log_id')
            ->from($db->quoteName('#__pplcz_log'))
            ->order($db->quoteName('ppl_log_id') . ' DESC')
            ->setLimit(30);

        $db->setQuery($keepQuery);
        $keepIds = $db->loadColumn();

        // If we have logs to keep, delete all others
        if (!empty($keepIds)) {
            $deleteQuery = $db->getQuery(true)
                ->delete($db->quoteName('#__pplcz_log'))
                ->where($db->quoteName('ppl_log_id') . ' NOT IN (' . implode(',', $keepIds) . ')');

            $db->setQuery($deleteQuery);
            $db->execute();
        }

        // Get hashes of remaining logs
        $hashQuery = $db->getQuery(true)
            ->select($db->quoteName('errorhash'))
            ->from($db->quoteName('#__pplcz_log'))
            ->order($db->quoteName('ppl_log_id') . ' DESC');

        $db->setQuery($hashQuery);
        $remainingHashes = $db->loadColumn();

        pplcz_set_option('pplcz_error_log_count', count($remainingHashes));
        pplcz_set_option('pplcz_error_log_hashes', implode(',', array_filter(array_reverse($remainingHashes))));

    }
}