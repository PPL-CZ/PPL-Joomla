<?php
namespace PPLCZ\Admin\Cron;
defined("_JEXEC") or die();


use PPLCZ\Admin\CPLOperation;
use PPLCZ\Data\PackageData;
use PPLCZ\Data\ShipmentData;
use PPLCZ\Setting\PhaseSetting;

class ShipmentPhaseCron {


    /**
     * Refresh shipment phases and package states
     *
     * @param int $iteration Current iteration number (for recursion protection)
     * @param int $maxIterations Maximum number of iterations to prevent infinite loops
     */
    public static function refresh_shipments($iteration = 0, $maxIterations = 10)
    {
        $phases = array_map(function ($item) {
            return $item->getCode();
        }, array_filter(PhaseSetting::getPhases()->getPhases(), function ($item) {
            return $item->getWatch();
        }));

        if (in_array('Canceled', $phases, true))
        {
            $phases[] = 'Deleted';
        }

        $from = (new \DateTime())->sub(new \DateInterval("PT120M"));
        $lastUpdate = (new \DateTime())->sub(new \DateInterval("P16D"));
        $max = PhaseSetting::getPhases()->getMaxSync();

        $packages = PackageData::find_packages_by_phases_and_time(array_merge($phases, ['None']), $from->format("Y-m-d H:i:s"), $lastUpdate->format("Y-m-d H:i:s"), $max+1);
        $next = $max < count($packages);

        if ($packages) {
            $operation = new CPLOperation();
            if ($operation->getAccessToken()) {
                $packages = array_values($packages);
                $update = array_slice($packages, 0, 40);
                if ($update) {
                    $operation->testPackageStates($update);
                }
            }
        }

        $items = ShipmentData::read_progress_shipments();
        if ($items) {
            $operation = new CPLOperation();
            $operation->loadingShipmentNumbers(array_map(function ($item) {
                return $item->get_batch_id();
            }, $items));
        }

        // Pokud jsou další balíky k synchronizaci, zavolej znovu
        if ($next) {
            self::refresh_shipments($iteration + 1, $maxIterations);
        }
    }
}