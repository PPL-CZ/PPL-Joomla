import React, { useMemo, useEffect } from "react";
import { useForm, Controller, useFormContext, FormProvider } from "react-hook-form";
import { CSSProperties } from "react";
import { components } from "../schema";

type Data = components["schemas"]["CategoryModel"];
type ShipmentMethodModel = components["schemas"]["ShipmentMethodModel"];

interface CategoryProps {
    data: Data;
    methods: ShipmentMethodModel[];
    nonce: string;
    element: HTMLElement;
}

const Category = (props: CategoryProps) => {
    const formCtx = useForm<Data>({
        defaultValues: { ...(props.data || {}) },
    });

    const { register, control, watch } = formCtx;

    const float: CSSProperties = {
        float: "none",
        width: "auto"
    };

    const inputSize: CSSProperties = {
        display: "inline",
        width: '5em'
    };

    const methods = useMemo(() => {
        const sortedMethods = props.methods.map(x => x);
        sortedMethods.sort((x, y) => {
            return x.title.localeCompare(y.title);
        });
        return sortedMethods;
    }, [props.methods]);

    // Sledovat všechny hodnoty formuláře
    const formValues = watch();

    // Synchronizovat s hidden inputy v hlavním VirtueMart formuláři
    useEffect(() => {
        // Najít rodičovský VirtueMart formulář (MIMO shadow DOM)
        const vmForm = document.querySelector('form[name="adminForm"]') as HTMLFormElement;

        if (!vmForm) {
            return;
        }

        // Vytvořit/aktualizovat hidden inputy
        const fieldNames = [
            'pplConfirmAge15',
            'pplConfirmAge18',
            'pplDisabledParcelBox',
            'pplDisabledAlzaBox',
            'pplDisabledParcelShop',
            'pplDisabledTransport'
        ] as const;

        fieldNames.forEach(fieldName => {
            const value = formValues[fieldName as keyof Data];

            if (fieldName === 'pplDisabledTransport') {
                // Smazat staré pplDisabledTransport[] inputy
                vmForm.querySelectorAll('input[name="pplDisabledTransport[]"]').forEach(el => el.remove());

                // Vytvořit nové pro každou hodnotu v poli
                if (Array.isArray(value) && value.length > 0) {
                    value.forEach(code => {
                        if (typeof code === 'string') {
                            const input = document.createElement('input');
                            input.type = 'hidden';
                            input.name = 'pplDisabledTransport[]';
                            input.value = code;
                            input.setAttribute('data-pplcz-category', 'true');
                            vmForm.appendChild(input);
                        }
                    });
                }
            } else {
                // Ostatní pole - checkbox hodnoty
                let input = vmForm.querySelector(`input[name="${fieldName}"][data-pplcz-category="true"]`) as HTMLInputElement;
                if (!input) {
                    input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = fieldName;
                    input.setAttribute('data-pplcz-category', 'true');
                    vmForm.appendChild(input);
                }
                input.value = value ? '1' : '0';
            }
        });

        // Synchronizovat pplSize (single object, not array)
        // Smazat staré pplSize inputy
        vmForm.querySelectorAll('input[name^="pplSize_"][data-pplcz-category="true"]').forEach(el => el.remove());

        // Vytvořit nové pro pplSize
        if (formValues.pplSize && typeof formValues.pplSize === 'object') {
            const size = formValues.pplSize;

            // Vytvořit input pro xSize
            if (size.xSize !== null && size.xSize !== undefined) {
                const inputX = document.createElement('input');
                inputX.type = 'hidden';
                inputX.name = 'pplSize_xSize';
                inputX.value = String(size.xSize);
                inputX.setAttribute('data-pplcz-category', 'true');
                vmForm.appendChild(inputX);
            }

            // Vytvořit input pro ySize
            if (size.ySize !== null && size.ySize !== undefined) {
                const inputY = document.createElement('input');
                inputY.type = 'hidden';
                inputY.name = 'pplSize_ySize';
                inputY.value = String(size.ySize);
                inputY.setAttribute('data-pplcz-category', 'true');
                vmForm.appendChild(inputY);
            }

            // Vytvořit input pro zSize
            if (size.zSize !== null && size.zSize !== undefined) {
                const inputZ = document.createElement('input');
                inputZ.type = 'hidden';
                inputZ.name = 'pplSize_zSize';
                inputZ.value = String(size.zSize);
                inputZ.setAttribute('data-pplcz-category', 'true');
                vmForm.appendChild(inputZ);
            }
        }

        // Cleanup při unmount
        return () => {
            vmForm.querySelectorAll('input[data-pplcz-category="true"]').forEach(el => el.remove());
        };
    }, [formValues]);

    return (
        <div className="pplcz-category-tab">
            <div>
                <label style={float}><strong>Věkové omezení (pouze v případě ČR se tato služba poskytuje)</strong></label>
            </div>
            <label style={float} htmlFor={"pplConfirmAge15"}>
                <input
                    style={float}
                    id={"pplConfirmAge15"}
                    type="checkbox"
                    {...register("pplConfirmAge15")}
                />
                &nbsp;Ověření věku 15+
            </label>
            <br/>
            <label style={float} htmlFor={"pplConfirmAge18"}>
                <input
                    style={float}
                    id={"pplConfirmAge18"}
                    type="checkbox"
                    {...register("pplConfirmAge18")}
                />
                &nbsp;Ověření věku 18+
            </label>
            <br/>
            <label style={float}><strong>Seznam zakázaných míst (pro výdejní místa)</strong></label>
            <div>
                <label style={float}>
                    <input
                        id="pplDisabledParcelBox"
                        value="1"
                        type="checkbox"
                        {...register('pplDisabledParcelBox')}
                    />
                    &nbsp;ParcelBoxy
                </label>
            </div>
            <div>
                <label style={float}>
                    <input
                        id="pplDisabledAlzaBox"
                        value="1"
                        type="checkbox"
                        {...register('pplDisabledAlzaBox')}
                    />
                    &nbsp;AlzaBoxy
                </label>
            </div>
            <div>
                <label style={float}>
                    <input
                        id="pplDisabledParcelShop"
                        value="1"
                        type="checkbox"
                        {...register('pplDisabledParcelShop')}
                    />
                    &nbsp;Obchody
                </label>
            </div>

            <FormProvider {...formCtx}>
                <div>
                    <label style={float}><strong>Velikost balíku pro tuto kategorii</strong></label>
                    <div style={{marginTop: '10px', marginBottom: '10px'}}>
                        <label style={{...float, marginRight: '10px'}}>
                            Šířka (cm):&nbsp;
                            <input
                                id="pplSize_xSize"
                                size={7}
                                style={inputSize}
                                type="number"
                                {...register("pplSize.xSize")}
                            />
                        </label>
                        <label style={{...float, marginRight: '10px'}}>
                            Výška (cm):&nbsp;
                            <input
                                id="pplSize_ySize"
                                size={7}
                                style={inputSize}
                                type="number"
                                {...register("pplSize.ySize")}
                            />
                        </label>
                        <label style={float}>
                            Hloubka (cm):&nbsp;
                            <input
                                id="pplSize_zSize"
                                size={7}
                                style={inputSize}
                                type="number"
                                {...register("pplSize.zSize")}
                            />
                        </label>
                    </div>
                </div>
            </FormProvider>

            <label style={float}><strong>Seznam zakázaných metod</strong></label>
            <br/>
            {methods.map(shipment => (
                <Controller
                    key={shipment.code}
                    control={control}
                    name="pplDisabledTransport"
                    render={(fieldProps) => {
                        const value = (fieldProps.field.value || []) as string[];
                        const checked = value.indexOf(shipment.code) > -1;

                        return (
                            <div>
                                <label style={float} htmlFor={`pplDisabledTransport_${shipment.code}`}>
                                    <input
                                        value={shipment.code}
                                        style={float}
                                        id={`pplDisabledTransport_${shipment.code}`}
                                        type="checkbox"
                                        checked={checked}
                                        onChange={() => {
                                            if (value.indexOf(shipment.code) > -1) {
                                                fieldProps.field.onChange(value.filter(x => x !== shipment.code));
                                            } else {
                                                fieldProps.field.onChange(value.concat([shipment.code]));
                                            }
                                        }}
                                    />
                                    &nbsp;{shipment.title}
                                </label>
                            </div>
                        );
                    }}
                />
            ))}
        </div>
    );
};

export default Category;
