import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { baseConnectionUrl, makeApiUrl } from "../connection";

import { components } from "../schema";

type BatchModel = components["schemas"]["BatchModel"];
type ShipmentWithAdditionalModel = components["schemas"]["ShipmentWithAdditionalModel"];
type PrepareShipmentBatchModel = components["schemas"]["PrepareShipmentBatchModel"];

export const useBatchs = (onlyfree: boolean = false) => {
  return useQuery({
    queryKey: ["batchs-" + (onlyfree ? "free" : "all")],
    retry: (count, error) => {
      return count < 3;
    },
    queryFn: async () => {
      const params = onlyfree ? { free: '1' } : undefined;
      const url = makeApiUrl('batch.get_batchs', params);

      const response = await fetch(url, {
        method: "GET",
      });
      const data = await response.json();

      return data as BatchModel[];
    },
  });
};

export const useBatchShipment = (batchId: string) => {

  return useQuery({
    queryKey: ["batchs-" + batchId],
    retry: (count, error) => {
      return count < 3;
    },
    queryFn: async () => {
      if (!batchId) {
        return [];
      }

      const url = makeApiUrl('batch.get_batch', { batch_id: batchId });

      const response = await fetch(url, {
        method: "GET",
      });

      const data = await response.text();

      const jsondata = JSON.parse(data);
      jsondata.refresher = new Date();
      return jsondata as ShipmentWithAdditionalModel[];
    },
  });
};

export const useRemoveShipmentFromBatch = (batchId: string) => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationKey: ["batchs-remove-" + batchId],
    mutationFn: async (variables: { shipment_id: number }) => {
      const url = makeApiUrl('batch.remove_batch_shipment', { shipment_id: variables.shipment_id });
      const result = await fetch(url, {
        method: "DELETE",
      });

      if (result.status < 300)
        return;

      const data = await result.text();
      throw new Error(JSON.stringify(JSON.parse(data)));
    },
    onSuccess: (data, error, context) => {
      queryClient.invalidateQueries({ queryKey: ["batchs-" + batchId] });
    },
  });
};

export const useRefreshBatch = (batchId: string) => {
  const queryClient = useQueryClient();
  return () => {
    return queryClient.refetchQueries({ queryKey: ["batchs-" + batchId] });
  }
};

export const useReorderShipmentInBatch = (batchId: string) => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationKey: ["batchs-reorder-" + batchId],
    mutationFn: async (variables: { shipment_id: (string | number)[] }) => {
      const url = makeApiUrl('batch.reorder', { batch_id: batchId });

      await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(variables.shipment_id),
      });
    },
    onSuccess: (data, error, context) => {
      queryClient.invalidateQueries({ queryKey: ["batchs-" + batchId] });
    },
  });
};

export const useCancelShipment = (batchId: string) => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationKey: ["batchs-cancel-" + batchId],
    mutationFn: async (variables: { shipmentId: number | string; packageId: number | string }) => {
      const url = makeApiUrl('shipment.cancel', {
        shipment_id: variables.shipmentId,
        package_id: variables.packageId
      });

      await fetch(url, {
        method: "DELETE",
      });
    },
    onSuccess: (data, error, context) => {
      queryClient.invalidateQueries({ queryKey: ["batchs-" + batchId] });
    },
  });
};

export const useTestState = (batchId: string) => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationKey: ["batchs-test-" + batchId],
    mutationFn: async (variables: { shipmentId: number | string; packageId: number | string }) => {
      const url = makeApiUrl('shipment.update_state', {
        shipment_id: variables.shipmentId,
        package_id: variables.packageId
      });

      await fetch(url, {
        method: "POST",
      });
    },
    onSuccess: (data, error, context) => {
      queryClient.invalidateQueries({ queryKey: ["batchs-" + batchId] });
    },
  });
};

export const useCreateBatch = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationKey: ["batch-create"],
    mutationFn: async () => {
      const url = makeApiUrl('batch.create_batch');

      const response = await fetch(url, {
        method: "POST",
      });

      if (!response.ok) {
        throw new Error(`Failed to create batch: ${response.status}`);
      }

      const data = await response.json();

      if (!data.id) {
        throw new Error('Batch created but ID is missing from response');
      }

      return data.id;
    },
    onSuccess: (data, error, context) => {
      queryClient.invalidateQueries({ queryKey: ["batchs-free", "batchs-all"] });
    },
  });
};

export const  useAddShipments = () => {
  const queryClient = useQueryClient();
  const addBatch = useCreateBatch();
  return useMutation({

    mutationKey: ["batch-add-shipment"],
    mutationFn: async (variables: { batchId: string | undefined; items: PrepareShipmentBatchModel }) => {
      let { batchId, items } = variables;

      if (!batchId) batchId = await addBatch.mutateAsync();

      const url = makeApiUrl('batch.add_shipment_to_batch', { batch_id: batchId || "" });

      await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(items),
      });
      return batchId;
    },
    onSuccess: (data, error, context) => {
      queryClient.invalidateQueries({ queryKey: ["batchs-" + data] });
    },
  });
};
