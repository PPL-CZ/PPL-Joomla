export const baseConnectionUrl = (): {
  nonce: "string";
  url: "string";
} => {
  const data = (window as any).Joomla?.getOptions?.('pplcz_data') || {};
  // @ts-ignore
  return {
    nonce: data.token || data.nonce || "",
    url: data.url || ""
  };
};

/**
 * Vytvoří API URL pro Joomla backend
 * @param task - task parameter (např. "shipment.get_all")
 * @param additionalParams - další URL parametry
 * @returns Kompletní URL string
 */
export const makeApiUrl = (task: string, additionalParams?: Record<string, string | number>): string => {
  const { url } = baseConnectionUrl();

  if (url) {
    // URL z Joomla options už obsahuje base URL a option=com_pplcz&format=json
    const apiUrl = new URL(url);
    apiUrl.searchParams.set('task', task);

    if (additionalParams) {
      Object.entries(additionalParams).forEach(([key, value]) => {
        apiUrl.searchParams.set(key, String(value));
      });
    }

    return apiUrl.toString();
  }

  // Fallback - vytvořit URL z aktuální location
  const fallbackUrl = new URL(window.location.origin + '/administrator/index.php');
  fallbackUrl.searchParams.set('option', 'com_pplcz');
  fallbackUrl.searchParams.set('format', 'json');
  fallbackUrl.searchParams.set('task', task);

  if (additionalParams) {
    Object.entries(additionalParams).forEach(([key, value]) => {
      fallbackUrl.searchParams.set(key, String(value));
    });
  }

  return fallbackUrl.toString();
};

export const makePrintUrl = (
  batchRemoteId: string,
  shipmentId: string | null,
  packageId?: string | null,
  print?: string | null
) => {
  const a = document.createElement("a");
  a.href = `${document.location}`;
  const url = new URL(a.href);
  url.search = "";
  url.hash = "";

  // Joomla format - raw format for file download without template
  url.searchParams.set("option", "com_pplcz");
  url.searchParams.set("task", "file.download");
  url.searchParams.set("format", "raw");
  url.searchParams.set("pplcz_download", packageId || batchRemoteId);
  if (shipmentId && !packageId) {
    url.searchParams.set("pplcz_reference", shipmentId);
  }
  if (print) url.searchParams.set("pplcz_print", print);
  return `${url}`;
};

export const makeOrderUrl = (orderId: string) => {
  const a = document.createElement("a");
  a.href = `${document.location}`;

  const url = new URL(a.href);
  url.search = "";
  url.hash = "";

  // Joomla VirtueMart format
  url.searchParams.set("option", "com_virtuemart");
  url.searchParams.set("view", "orders");
  url.searchParams.set("task", "edit");
  url.searchParams.set("virtuemart_order_id", `${orderId}`);
  return `${url}`;
};
