import { useMutation, useQueryClient } from "@tanstack/react-query";
import { makeApiUrl } from "../connection";

/**
 * Mutation pro objednání/zrušení svozu
 */
export const useCollectionOrderMutation = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationKey: ["collection-order"],
    mutationFn: async (variables: { collectionId: string; action: "DELETE" | "PUT" }) => {
      // Určíme task podle akce: DELETE = delete_order, PUT = order
      const task = variables.action === "DELETE" ? "collection.delete_order" : "collection.order";
      const url = makeApiUrl(task, { id: variables.collectionId });

      const response = await fetch(url, {
        method: "POST", // Joomla používá POST pro všechny akce
      });

      if (response.status === 204) {
        return true;
      }

      // Pokud je to 200 nebo jiný úspěšný status, také to považujeme za úspěch
      if (response.ok) {
        return true;
      }

      const errorText = await response.text();
      throw new Error(`Failed to update collection order: ${response.status} - ${errorText}`);
    },
    onSuccess: () => {
      queryClient.refetchQueries({
        queryKey: ["collections"],
      });
    },
  });
};
