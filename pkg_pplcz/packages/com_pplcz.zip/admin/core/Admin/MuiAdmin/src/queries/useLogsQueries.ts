import { makeApiUrl } from "../connection";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { baseConnectionUrl } from "../connection";
import { components } from "../schema";

type SendErrorLogModel = components['schemas']['SendErrorLogModel'];
type ErrorLogItemModel = components['schemas']['ErrorLogItemModel'];

export const deleteLog = (data: ErrorLogItemModel) => {
    const url = makeApiUrl("log.delete_error");

    return fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ id: data.id })
    })
}

export const sendLog = (data: SendErrorLogModel) => {
    const url = makeApiUrl("log.send_log");

    return fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    }).then(x => {
        switch (x.status)
        {
            case 204:
                return null;
            case 400:
                return x.json();
        }
        throw new Error("Problém s odesláním")
    });
}

export const useLogs = (product_ids: string[], order_ids: string[]) => {

    const ids = product_ids.join(',');
    const ids2 = order_ids.join(',')
    return useQuery({
        queryKey: ["logs", ids, ids2 ],
        retry: (count, error) => {
            return count < 3;
        },
        queryFn: async () => {
            const url = makeApiUrl("log.get_log");

            const data = await fetch(url, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    product_ids: ids || undefined,
                    order_ids: ids2 || undefined
                })
            }).then(x => x.json());

            return data as components["schemas"]["ErrorLogModel"];
        },
    });
};
