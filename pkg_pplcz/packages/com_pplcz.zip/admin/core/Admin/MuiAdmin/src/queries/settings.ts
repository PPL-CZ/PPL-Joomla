import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { components } from "../schema";
import { baseConnectionUrl, makeApiUrl } from "../connection";
import { UnknownErrorException, ValidationErrorException } from "./types";

type SenderAddressModel = components["schemas"]["SenderAddressModel"];
type SyncPhasesModel = components["schemas"]["SyncPhasesModel"];

export const useSenderAddressesQuery = () => {
  const { data } = useQuery({
    queryKey: ["sender-addresses"],
    queryFn: () => {
      const url = makeApiUrl('setting.get_addresses');
      return fetch(url, {
        method: 'GET'
      }).then(x => x.json()).then(response => {
        if(response.data){
          return response.data as SenderAddressModel[];
        }
        return response as SenderAddressModel[];
      });
    },
  });
  return data;
};

export const useSenderAddressesMutation = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationKey: ["sender-addresses"],
    mutationFn: (data: SenderAddressModel[]) => {
      const url = makeApiUrl('setting.update_addresses');
      return fetch(url, {
        method: "POST",
        body: JSON.stringify(data),
      }).then(async x => {
        if (x.status === 400) {
          const data = await x.json();
          throw new ValidationErrorException(x.status, data.data);
        } else if (x.status > 400) throw new UnknownErrorException(x.status);
        return x;
      });
    },
    onSuccess: () => {
      qc.refetchQueries({
        queryKey: ["sender-addresses"],
      });
    },
  });
};

export const useLabelPrintSettingQuery = () => {
  return useQuery({
    queryKey: ["print-setting"],
    queryFn: async () => {
      const url = makeApiUrl('setting.get_print');
      return fetch(url, {
        method: "GET",
      }).then(x => x.json() as Promise<string>);
    },
  });
};

export const useLabelPrintSettingMutation = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationKey: ["print-setting"],
    mutationFn: async (data: { printState: string }) => {
      const url = makeApiUrl('setting.update_print');
      return fetch(url, {
        method: "POST",
        body: JSON.stringify(data.printState),
      });
    },
    onSuccess: () => {
      qc.refetchQueries({
        queryKey: [`print-setting`],
      });
    },
  });
};

export const useQueryShipmentStates = () =>
  useQuery({
    queryKey: ["phase-shipments"],
    queryFn: () => {
      const url = makeApiUrl('setting.get_phases');
      return fetch(url, {
        method: "GET",
      }).then(x => x.json() as Promise<SyncPhasesModel>);
    },
  });

type GlobalSettingModel = components["schemas"]["GlobalSettingModel"];
type ParcelPlacesModel = components["schemas"]["ParcelPlacesModel"];
type MyApiModel = components["schemas"]["MyApi2"];
type ShipmentMethodSettingModel = components["schemas"]["ShipmentMethodSettingModel"];

/**
 * Query pro získání globálního nastavení
 */
export const useGlobalSettingQuery = () => {
  return useQuery({
    queryKey: ["globalsetting"],
    queryFn: async () => {
      const url = makeApiUrl('setting.get_globalsetting');
      return fetch(url, {
        method: 'GET'
      }).then(x => x.json() as Promise<GlobalSettingModel>);
    },
  });
};

/**
 * Mutation pro aktualizaci globálního nastavení
 */
export const useGlobalSettingMutation = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: GlobalSettingModel) => {
      const url = makeApiUrl('setting.update_globalsetting');
      await fetch(url, {
        method: "POST",
        body: JSON.stringify(data),
      }).then(async x => {
        if (x.status === 204) {
          return true;
        }
        throw new Error("Failed to update global settings");
      });
    },
    onSuccess: () => {
      queryClient.refetchQueries({
        queryKey: ["globalsetting"],
      });
    },
  });
};

/**
 * Query pro získání nastavení výdejních míst
 */
export const useParcelPlacesQuery = () => {
  return useQuery({
    queryKey: ["parcelplaces"],
    queryFn: async () => {
      const url = makeApiUrl('setting.get_parcelplaces');
      return fetch(url, {
        method: 'GET'
      }).then(x => x.json() as Promise<ParcelPlacesModel>);
    },
  });
};

/**
 * Mutation pro aktualizaci nastavení výdejních míst
 */
export const useParcelPlacesMutation = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: ParcelPlacesModel) => {
      const url = makeApiUrl('setting.update_parcelplaces');
      await fetch(url, {
        method: "POST",
        body: JSON.stringify(data),
      }).then(async x => {
        if (x.status === 204) {
          return true;
        }
        throw new Error("Failed to update parcel places");
      });
    },
    onSuccess: () => {
      queryClient.refetchQueries({
        queryKey: ["parcelplaces"],
      });
    },
  });
};

/**
 * Query pro získání API přístupových údajů
 */
export const useMyApiQuery = () => {
  return useQuery({
    queryKey: ["myapi2"],
    queryFn: async () => {
      const url = makeApiUrl('setting.get_api');
      return fetch(url, {
        method: 'GET'
      }).then(x => x.json() as Promise<MyApiModel>);
    },
  });
};


/**
 * Custom error pro API validaci s detaily chyb
 */
export class MyApiError extends Error {
  constructor(public status: number, public errors?: Record<string, string>) {
    super("API Error");
  }
}

/**
 * Mutation pro aktualizaci API přístupových údajů
 */
export const useMyApiMutation = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: MyApiModel) => {
      const url = makeApiUrl('setting.update_api');
      const response = await fetch(url, {
        method: "POST",
        body: JSON.stringify(data),
      });

      if (response.status === 400) {
        const message = await response.json();
        throw new MyApiError(400, message.data.errors);
      } else if (response.status === 204) {
        return { success: true };
      }

      throw new MyApiError(response.status);
    },
    onSuccess: () => {
      queryClient.refetchQueries({
        queryKey: ["myapi2"],
      });
    },
  });
};

/**
 * Query pro získání nastavení dopravních metod (shipment settings)
 */
export const useShipmentSettings = (shopId?: number) => {
  return useQuery({
    queryKey: ["shipment-settings", shopId],
    queryFn: async () => {
      const url = makeApiUrl('shipmentmethod.get_shipment_methods');
      return fetch(url, {
        method: 'GET'
      }).then(x => x.json() as Promise<ShipmentMethodSettingModel[]>);
    },
  });
};

/**
 * Mutation pro aktualizaci nastavení dopravní metody
 */
export const useShipmentSettingMutation = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (payload: { id?: number; data: ShipmentMethodSettingModel }) => {
      const url = makeApiUrl('shipmentmethod.update_shipment_method', { id: payload.id || 0 });
      const response = await fetch(url, {
        method: "POST",
        body: JSON.stringify(payload.data),
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (response.status === 400) {
        const data = await response.json();
        throw new ValidationErrorException(response.status, data.data);
      } else if (response.status > 400) {
        throw new UnknownErrorException(response.status);
      }

      return response;
    },
    onSuccess: () => {
      queryClient.refetchQueries({
        queryKey: ["shipment-settings"],
      });
    },
  });
};

/**
 * Mutation pro odstranění nastavení dopravní metody
 */
export const useShipmentSettingRemovingMutation = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: number) => {
      const url = makeApiUrl('shipmentmethod.remove_shipment_method', { id });
      const response = await fetch(url, {
        method: "DELETE",
      });

      if (response.status > 400) {
        throw new UnknownErrorException(response.status);
      }

      return response;
    },
    onSuccess: () => {
      queryClient.refetchQueries({
        queryKey: ["shipment-settings"],
      });
    },
  });
};

/**
 * Query pro získání seznamu obchodů/shopů
 */
export const useShopsQuery = () => {
  return useQuery({
    queryKey: ["shops"],
    queryFn: async () => {
      const url = makeApiUrl('setting.get_shops');
      return fetch(url, {
        method: 'GET'
      }).then(x => x.json() as Promise<Array<{ id: number; name: string }>>);
    },
  });
};
