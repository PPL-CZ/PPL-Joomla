import { useQuery } from "@tanstack/react-query";
import { baseConnectionUrl, makeApiUrl } from "../connection";

import { components } from "../schema";

type ShipmentMethodModel = components["schemas"]["ShipmentMethodModel"];
type CurrencyModel = components["schemas"]["CurrencyModel"];
type CountryModel = components["schemas"]["CountryModel"];
type LabelPrintModel = components["schemas"]["LabelPrintModel"];
type OrderStatusModel = components["schemas"]["OrderStatusModel"];

export const useQueryShipmentMethods = () => {
  const { data } = useQuery({
    queryKey: ["methodsCodelist"],
    queryFn: async () => {
      const url = makeApiUrl('codelist.get_methods');
      const response = await fetch(url, {
        method: 'GET'
      });
      const json = await response.json();
      return json as ShipmentMethodModel[];
    },
  });

  return data;
};

export const useQueryCurrencies = () => {
  const { data } = useQuery({
    queryKey: ["currenciesCodelist"],
    queryFn: () => {
      const url = makeApiUrl('codelist.get_currencies');
      return fetch(url, {
        headers: {
          method: 'GET',
        },
      }).then(x => x.json() as Promise<CurrencyModel[]>);
    },
  });

  return data;
};

export const useQueryCountries = () => {
  const { data } = useQuery({
    queryKey: ["countriesCodelist"],
    queryFn: () => {
      const url = makeApiUrl('codelist.get_countries');
      return fetch(url, {
        method: 'GET'
      }).then(x => x.json() as Promise<CountryModel[]>);
    },
  });

  return data;
};

export const useQueryLabelPrint = () =>
  useQuery({
    queryKey: ["print-setting-printers"],
    queryFn: () => {
      const url = makeApiUrl('setting.available_printers');
      return fetch(url, {
        method: "GET",
      }).then(x => x.json() as Promise<LabelPrintModel[]>);
    },
  });

export const useQueryPayments = () => {
  const { data } = useQuery({
    queryKey: ["paymentsCodelist"],
    queryFn: () => {
      const url = makeApiUrl('codelist.get_payments');
      return fetch(url, {
        method: 'GET'
      }).then(x => x.json() as Promise<Record<string, string>>);
    },
  });

  return data;
};

export const useOrderStatuses = () =>
  useQuery({
    queryKey: ["order-statuses"],
    queryFn: async () => {
      const url = makeApiUrl('codelist.get_order_statuses');
      return fetch(url, {
        method: "GET",
      }).then(x => x.json() as Promise<OrderStatusModel[]>);
    },
  });
