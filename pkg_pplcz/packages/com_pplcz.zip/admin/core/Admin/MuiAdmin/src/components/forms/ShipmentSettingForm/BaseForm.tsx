import { Fragment, useEffect, useMemo, useState } from "react";
import { components } from "../../../schema";
import { useForm, Controller, useFieldArray, FormProvider } from "react-hook-form";
import Grid from "@mui/material/Grid";
import FormLabel from "@mui/material/FormLabel";
import TextField from "@mui/material/TextField";
import TextFieldController from "../Controllers/TextFieldController";
import { WeightsForm } from "./WeightsForm";
import Switch from "@mui/material/Switch";
import { Button, FormHelperText } from "@mui/material";
import { useQueryCurrencies } from "../../../queries/codelists";
import CountryController from "../Controllers/CountryController";
import SelectInput from "../Inputs/SelectInput";
import { useShipmentSettingMutation, useShipmentSettingRemovingMutation } from "../../../queries/settings";
import { ValidationErrorException } from "../../../queries/types";

export const BaseForm = (props: {
    data: components["schemas"]["ShipmentMethodSettingModel"];
    countries: components["schemas"]["CountryModel"][];
    payments: Record<string, string>;
    asNew: boolean;
    shipmentMethodId?: number;
    shipmentMethodName?: string;
    shipmentMethodDesc?: string;
    shipmentMethodCode?: string;
}) => {
    const form = useForm<typeof props.data>({
        values: props.data,
    });

    const { control, getValues, watch, handleSubmit } = form;
    const parcelBoxes = props.shipmentMethodCode === 'SMAR' || props.shipmentMethodCode === 'SBOX';
    const isSBOX = props.shipmentMethodCode === 'SBOX';
    const disablePayments = watch("disablePayments");
    const codPayment = watch("codPayment");

    const [save, setSave] = useState(false);
    const [deleted, setDeleted] = useState(false);

    // Automatické odstranění konfliktu mezi codPayment a disablePayments
    useEffect(() => {
        if (codPayment && disablePayments && disablePayments.includes(codPayment)) {
            // Pokud je codPayment v disablePayments, odstraň ho z disablePayments
            const newDisablePayments = disablePayments.filter((id: string) => id !== codPayment);
            form.setValue("disablePayments", newDisablePayments);
        }
    }, [codPayment, disablePayments]);

    // Vynucení SBOX nastavení
    useEffect(() => {
        if (isSBOX) {
            // SBOX vynucuje ParcelBox-only
            form.setValue("disabledParcelBox", false);  // ParcelBox povoleno
            form.setValue("disabledAlzaBox", true);     // AlzaBox zakázáno
            form.setValue("disabledParcelShop", true);  // ParcelShop zakázáno

            // SBOX pouze pro ČR
            form.setValue("allowedParcelCountries", ["CZ"]);
        }
    }, [isSBOX]);

    const settingMutation = useShipmentSettingMutation();
    const settingRemovingMutation = useShipmentSettingRemovingMutation();

    let submitButton = "";

    const onSubmit = async (data: components["schemas"]["ShipmentMethodSettingModel"]) => {
        setSave(true);
        try {
            if (submitButton === "save") {
                // Pro SBOX vynucujeme správné hodnoty
                if (isSBOX) {
                    data.disabledParcelBox = false;
                    data.disabledAlzaBox = true;
                    data.disabledParcelShop = true;
                    data.allowedParcelCountries = ["CZ"];
                }

                // Odfiltrovat pouze enabled měny (nebo měny s nějakým nastavením)
                const filteredData = {
                    ...data,
                    // Přidat read-only hodnoty z props
                    code: props.shipmentMethodCode,
                    parcelBoxes: props.shipmentMethodCode === 'SMAR' || props.shipmentMethodCode === 'SBOX',
                    title: props.shipmentMethodName,
                    description: props.shipmentMethodDesc,
                    currencies: data.currencies.filter(c =>
                        c.enabled ||
                        c.cost !== undefined && c.cost !== null ||
                        c.costOrderFree !== undefined && c.costOrderFree !== null ||
                        c.costCodFee !== undefined && c.costCodFee !== null
                    )
                };

                // Předáme data včetně ID
                await settingMutation.mutateAsync({
                    id: props.shipmentMethodId,
                    data: filteredData
                } as any);
            } else {
                // Pro odstranění předáváme ID (shipmentMethodId)
                await settingRemovingMutation.mutateAsync(props.shipmentMethodId!);
            }
        } catch (errors) {
            if (errors instanceof ValidationErrorException) {
                const errorData = errors.data;
                Object.keys(errorData.errors).forEach(x => {
                    // @ts-ignore
                    setError(`data.${x}`, { type: "validation", message: errorData.errors[x][0] });
                });
            }
        } finally {
            setSave(false);
        }
    };

    return (
        <form onSubmit={handleSubmit(onSubmit)}>
            <FormProvider {...form}>
                <Grid container alignItems={"center"}>
                    <Grid item xs={4} display={"flex"} alignContent={"center"}>
                        <FormLabel>Titulek</FormLabel>
                    </Grid>
                    <Grid item xs={8} display={"flex"}>
                        <TextField
                            value={props.shipmentMethodName || ''}
                            fullWidth
                            InputProps={{
                                readOnly: true,
                            }}
                        />
                    </Grid>
                    <Grid item xs={4} display={"flex"} alignContent={"center"}>
                        <FormLabel>Popis</FormLabel>
                    </Grid>
                    <Grid item xs={8} display={"flex"}>
                        <TextField
                            value={props.shipmentMethodDesc || ''}
                            fullWidth
                            InputProps={{
                                readOnly: true,
                            }}
                        />
                    </Grid>
                    <Grid item xs={4} display={"flex"} alignContent={"center"}>
                        <FormLabel>Parcelboxy</FormLabel>
                    </Grid>
                    <Grid item xs={8} display={"flex"}>
                        <Switch
                            readOnly={true}
                            checked={parcelBoxes}
                            disabled={true}
                            name={"parcelBoxes"}
                            color="success"
                        />
                    </Grid>
                    {parcelBoxes ? (
                        <>
                            <Grid item xs={4} display={"flex"} alignContent={"center"}>
                                <FormLabel>Nepoužívat ParcelBoxy</FormLabel>
                            </Grid>
                            <Grid item xs={8} display={"flex"} flexDirection={"column"}>
                                <Controller
                                    control={control}
                                    name="disabledParcelBox"
                                    render={({ field: { onChange, value }, fieldState: { error }, formState }) => {
                                        return (
                                            <>
                                                <Switch
                                                    readOnly={true}
                                                    checked={!!value}
                                                    value={value}
                                                    name={"disabledParcelBox"}
                                                    disabled={isSBOX}
                                                    onChange={e => {
                                                        if (!isSBOX) {
                                                            onChange(!value);
                                                        }
                                                    }}
                                                />
                                                {isSBOX && <FormHelperText>SBOX vyžaduje ParcelBox</FormHelperText>}
                                                {error?.message ? <FormHelperText error={true}>{error?.message}</FormHelperText> : null}
                                            </>
                                        );
                                    }}
                                />
                            </Grid>
                            <Grid item xs={4} display={"flex"} alignContent={"center"}>
                                <FormLabel>Nepoužívat AlzaBoxy</FormLabel>
                            </Grid>
                            <Grid item xs={8} display={"flex"} flexDirection={"column"}>
                                <Controller
                                    control={control}
                                    name="disabledAlzaBox"
                                    render={({ field: { onChange, value }, fieldState: { error }, formState }) => {
                                        return (
                                            <>
                                                <Switch
                                                    readOnly={true}
                                                    checked={!!value}
                                                    value={value}
                                                    name={"disabledAlzaBox"}
                                                    disabled={isSBOX}
                                                    onChange={e => {
                                                        if (!isSBOX) {
                                                            onChange(!value);
                                                        }
                                                    }}
                                                />
                                                {isSBOX && <FormHelperText>SBOX nepodporuje AlzaBox</FormHelperText>}
                                                {error?.message ? <FormHelperText error={true}>{error?.message}</FormHelperText> : null}
                                            </>
                                        );
                                    }}
                                />
                            </Grid>
                            <Grid item xs={4} display={"flex"} alignContent={"center"}>
                                <FormLabel>Nepoužívat ParcelShopy</FormLabel>
                            </Grid>
                            <Grid item xs={8} display={"flex"} flexDirection={"column"}>
                                <Controller
                                    control={control}
                                    name="disabledParcelShop"
                                    render={({ field: { onChange, value }, fieldState: { error }, formState }) => {
                                        return (
                                            <>
                                                <Switch
                                                    readOnly={true}
                                                    checked={!!value}
                                                    value={value}
                                                    name={"disabledParcelShop"}
                                                    disabled={isSBOX}
                                                    onChange={e => {
                                                        if (!isSBOX) {
                                                            onChange(!value);
                                                        }
                                                    }}
                                                />
                                                {isSBOX && <FormHelperText>SBOX nepodporuje ParcelShop</FormHelperText>}
                                                {error?.message ? <FormHelperText error={true}>{error?.message}</FormHelperText> : null}
                                            </>
                                        );
                                    }}
                                />
                            </Grid>
                        </>
                    ) : null}
                    <Grid item xs={4} display={"flex"} alignContent={"center"}>
                        <FormLabel>Povolené země</FormLabel>
                    </Grid>
                    <Grid item xs={8} display={"flex"} flexDirection={"column"}>
                        <Controller
                            control={control}
                            name="allowedParcelCountries"
                            render={({ field: { onChange, value }, fieldState: { error }, formState }) => {
                                return (
                                    <>
                                        <SelectInput
                                            multiple
                                            onMultipleChange={ids => {
                                                if (!isSBOX) {
                                                    onChange(ids);
                                                }
                                            }}
                                            optionals={props.countries
                                                .filter(y => {
                                                    if (isSBOX) return y.code === 'CZ';
                                                    if (parcelBoxes) return y.parcelAllowed;
                                                    return true;
                                                })
                                                .map(x => {
                                                    return {
                                                        id: x.code,
                                                        label: x.title,
                                                    };
                                                })}
                                            multipleValue={(value as string[]) || []}
                                        />
                                        {isSBOX && <FormHelperText>SBOX dostupný pouze v České republice</FormHelperText>}
                                    </>
                                );
                            }}
                        />
                    </Grid>
                    <Grid item xs={4} display={"flex"} alignContent={"center"}>
                        <FormLabel>Zakázané platby</FormLabel>
                    </Grid>
                    <Grid item xs={8} display={"flex"}>
                        <Controller
                            control={control}
                            name="disablePayments"
                            render={({ field: { onChange, value }, fieldState: { error }, formState }) => {
                                return (
                                    <SelectInput
                                        multiple
                                        onMultipleChange={ids => {
                                            onChange(ids);
                                        }}
                                        optionals={Object.entries(props.payments)
                                            .filter(([id, name]) => id !== codPayment)
                                            .map(([id, name]) => {
                                                return {
                                                    id: id,
                                                    label: name,
                                                };
                                            })}
                                        multipleValue={value || []}
                                    />
                                );
                            }}
                        />
                    </Grid>
                    <Grid item xs={4} display={"flex"} alignContent={"center"}>
                        <FormLabel>Platba dobírkou</FormLabel>
                    </Grid>
                    <Grid item xs={8} display={"flex"}>
                        <Controller
                            control={control}
                            name="codPayment"
                            render={({ field: { onChange, value }, fieldState: { error }, formState }) => {
                                return (
                                    <SelectInput
                                        onChange={ids => {
                                            onChange(ids);
                                        }}
                                        optionals={Object.entries(props.payments)
                                            .filter(([id, name]) => !(disablePayments || []).includes(id))
                                            .map(([id, name]) => {
                                                return {
                                                    id: id,
                                                    label: name,
                                                };
                                            })}
                                        value={value || undefined}
                                    />
                                );
                            }}
                        />
                    </Grid>
                    <Grid item xs={4} display={"flex"} alignContent={"center"}>
                        <FormLabel>Cena dopravy vč. DPH</FormLabel>
                    </Grid>
                    <Grid item xs={8} display={"flex"}>
                        <Controller
                            control={control}
                            name="isPriceWithDph"
                            render={({ field: { onChange, value }, fieldState: { error }, formState }) => {
                                return (
                                    <>
                                        <Switch
                                            readOnly={true}
                                            checked={!!value}
                                            value={value}
                                            name={"isPriceWithDph"}
                                            onChange={e => {
                                                onChange(!value);
                                            }}
                                            color="success"
                                        />
                                        {error?.message ? <FormHelperText error={true}>{error?.message}</FormHelperText> : null}
                                    </>
                                );
                            }}
                        />
                    </Grid>
                    <Grid item xs={4} display={"flex"} alignContent={"center"}>
                        <FormLabel>Platba podle váhy</FormLabel>
                    </Grid>
                    <Grid item xs={8} display={"flex"}>
                        <Controller
                            control={control}
                            name="costByWeight"
                            render={({ field: { onChange, value }, fieldState: { error }, formState }) => {
                                return (
                                    <>
                                        <Switch
                                            readOnly={true}
                                            checked={!!value}
                                            value={value}
                                            name={"costByWeight"}
                                            onChange={e => {
                                                onChange(!value);
                                            }}
                                            color="success"
                                        />
                                        {error?.message ? <FormHelperText error={true}>{error?.message}</FormHelperText> : null}
                                    </>
                                );
                            }}
                        />
                    </Grid>
                    <WeightsForm data={props.data} />
                    <Grid item xs={12}>
                        <Button
                            onClick={e => {
                                submitButton = "save";
                            }}
                            type="submit"
                            value="save"
                            disabled={deleted || save}
                        >
                            Uložit
                        </Button>
                        {/* DOČASNĚ ZABLOKOVÁNO - implementace bude rozhodnuta později */}
                        {/* {!props.asNew ? (
                            <Button
                                onClick={e => {
                                    submitButton = "delete";
                                }}
                                type="submit"
                                value="delete"
                                color="error"
                                disabled={deleted || save}
                            >
                                Smazat
                            </Button>
                        ) : null} */}
                    </Grid>
                </Grid>
            </FormProvider>
        </form>
    );
};