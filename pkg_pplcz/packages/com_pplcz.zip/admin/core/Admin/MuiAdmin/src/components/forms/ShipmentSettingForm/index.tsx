import {useShipmentSettings} from "../../../queries/settings";
import {useMemo, useState} from "react";
import Skeleton from "@mui/material/Skeleton";
import Grid from "@mui/material/Grid";
import {Box, Card, Tab, Tabs, Typography} from "@mui/material";
import {BaseForm} from "./BaseForm";
import {useQueryCountries, useQueryCurrencies, useQueryPayments} from "../../../queries/codelists";
import {components} from "../../../schema";

type ShipmentMethodSettingModel = components["schemas"]["ShipmentMethodSettingModel"];
type CurrencyModel = components["schemas"]["CurrencyModel"];

const TabPanel = (props: { children?: React.ReactNode; index: number; value: number }) => {
    const {children, value, index, ...other} = props;

    return (
        <div role="tabpanel" hidden={value !== index} {...other}>
            {value === index && <Box>{children}</Box>}
        </div>
    );
};

const ShipmentSettingData = () => {
    const [tabId, setTabId] = useState(0);

    const payments = useQueryPayments();

    const currencies = useQueryCurrencies();

    const countries = useQueryCountries();

    const changeTab = (event: React.SyntheticEvent, newValue: number) => {
        setTabId(newValue);
    };

    const {data: rawData} = useShipmentSettings(0);

    const upgradedData = useMemo(() => {

        if (rawData && currencies) {
            const dataArray = Array.isArray(rawData) ? rawData : (rawData as any).data || [];

            if (!Array.isArray(dataArray)) {
                return null;
            }

            const newData = dataArray.map((wrapper: any) => {
                const item: ShipmentMethodSettingModel = JSON.parse(JSON.stringify(wrapper.data));

                // Ensure arrays exist
                if (!item.currencies) {
                    item.currencies = [];
                }
                if (!item.allowedParcelCountries) {
                    item.allowedParcelCountries = [];
                }
                if (!item.disablePayments) {
                    item.disablePayments = [];
                }
                if (!item.weights) {
                    item.weights = [];
                }

                const currentCurrencies = item.currencies;
                currencies.forEach((y: CurrencyModel) => {
                    if (!currentCurrencies.some((x) => x.currency === y.code))
                        currentCurrencies.push({
                            currency: y.code,
                        });
                });

                // Return with ID, name, desc and code attached
                return {
                    id: wrapper.id,
                    name: wrapper.name,
                    desc: wrapper.desc,
                    code: wrapper.code,
                    data: item
                };
            });

            // ZABLOKOVÁNO: Přidání nové dopravy možné pouze ve VirtueMart administraci
            // newData.push({...})

            return newData;
        }

        return null;
    }, [rawData, currencies]);

    if (!upgradedData || !currencies || !payments || !countries) {
        return <Skeleton/>;
    }

    return (
        <Card id="shipmentSetting">
            <Box paddingTop={2} paddingBottom={2} paddingLeft={2} paddingRight={2}>
                <Typography variant="h3" marginBottom={4}>
                    Nastavení dopravy
                </Typography>
                <Grid item xs={12}>
                    <Tabs value={tabId} onChange={changeTab} aria-label="basic tabs example">
                        {upgradedData.map((wrapper: any, index: number) => {
                            return <Tab key={wrapper.id || index} label={wrapper.name} tabIndex={index}/>;
                        })}
                    </Tabs>
                    {upgradedData.map((wrapper: any, index: number) => {
                        return (
                            <TabPanel key={wrapper.id || index} index={index} value={tabId}>
                                <BaseForm
                                    payments={payments}
                                    countries={countries}
                                    data={wrapper.data}
                                    shipmentMethodId={wrapper.id}
                                    shipmentMethodName={wrapper.name}
                                    shipmentMethodDesc={wrapper.desc}
                                    shipmentMethodCode={wrapper.code}
                                    asNew={false}
                                />
                            </TabPanel>
                        );
                    })}
                </Grid>
            </Box>
        </Card>
    );
};

export default ShipmentSettingData;