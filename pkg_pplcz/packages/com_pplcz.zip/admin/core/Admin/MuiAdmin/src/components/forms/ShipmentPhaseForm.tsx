import { Fragment, useMemo } from "react";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import Checkbox from "@mui/material/Checkbox";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormLabel from "@mui/material/FormLabel";
import Grid from "@mui/material/Grid";
import TextField from "@mui/material/TextField";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import RefreshIcon from "@mui/icons-material/Refresh";
import copy from "copy-to-clipboard";

import { Controller, useForm, useFormContext } from "react-hook-form";
import { components } from "../../schema";
import { useQueryShipmentStates } from "../../queries/settings";
import { Skeleton } from "@mui/material";
import { useEffect, useState } from "react";
import { useUpdateShipmentPhasesMutation } from "../../queries/useShipmentQueries";
import { useOrderStatuses } from "../../queries/codelists";
import SelectInput from "./Inputs/SelectInput";

type UpdateSyncPhasesModel = components["schemas"]["UpdateSyncPhasesModel"];

const Check = (props: { name: string; label: string; checked: boolean; orderState: string | null }) => {
  const [checked, setChecked] = useState(() => props.checked);
  const [orderState, setOrderState] = useState(() => props.orderState);

  const { mutateAsync } = useUpdateShipmentPhasesMutation();
  const { data: statusesData } = useOrderStatuses();

  const statuses = useMemo(() => {
    if (!statusesData) return null;

    return statusesData.map(x => ({
      id: x.code,
      label: x.title,
    }));
  }, [statusesData]);

  return (
    <Box display="flex" alignItems="center" gap={2} marginBottom={1}>
      <Box minWidth="300px">
        <FormControlLabel
          control={
            <Checkbox
              name={props.name}
              checked={checked}
              onChange={e => {
                setChecked(!checked);
                mutateAsync({
                  phases: [
                    {
                      code: props.name,
                      watch: !checked,
                      orderState: orderState,
                    },
                  ],
                });
              }}
            />
          }
          label={props.label}
        />
      </Box>
      <Box flex={1}>
        {statuses && (
          <SelectInput
            optionals={statuses}
            value={orderState || undefined}
            onChange={newOrderState => {
              setOrderState(newOrderState || null);
              mutateAsync({
                phases: [
                  {
                    code: props.name,
                    watch: checked,
                    orderState: newOrderState,
                  },
                ],
              });
            }}
          />
        )}
      </Box>
    </Box>
  );
};

const ShipmentPhaseForm = () => {
  const { control, resetField, getValues } = useForm<UpdateSyncPhasesModel>();
  const { data, isLoading } = useQueryShipmentStates();
  const { mutateAsync } = useUpdateShipmentPhasesMutation();

  const [cronSecret, setCronSecret] = useState<string>("");
  const [regenerating, setRegenerating] = useState(false);

  useEffect(() => {
    const fetchCronUrl = async () => {
      try {
        const response = await fetch(
          "/administrator/index.php?option=com_pplcz&task=setting.get_cron_url&format=json"
        );
        if (response.ok) {
          const result = await response.json();
          // Extrahuj secret z URL
          const url = new URL(result.url || "", window.location.origin);
          const secret = url.searchParams.get('secret');
          setCronSecret(secret || "");
        }
      } catch (error) {
        console.error("Failed to fetch cron URL:", error);
      }
    };
    fetchCronUrl();
  }, []);

  useEffect(() => {
    if (data)
      setTimeout(() => {
        resetField("maxSync", { defaultValue: data.maxSync });
      });
  }, [data]);

  const handleRegenerateCronKey = async () => {
    setRegenerating(true);
    try {
      const response = await fetch(
        "/administrator/index.php?option=com_pplcz&task=setting.regenerate_cron_secret&format=json",
        {
          method: "POST",
        }
      );

      if (response.ok) {
        const result = await response.json();
        // Extrahuj secret z URL
        const url = new URL(result.url || "", window.location.origin);
        const secret = url.searchParams.get('secret');
        setCronSecret(secret || "");
      }
    } catch (error) {
      console.error("Failed to regenerate cron key:", error);
    } finally {
      setRegenerating(false);
    }
  };

  // Generovat URL pro jednotlivé endpointy
  const getCronUrl = (task: string) => {
    const baseUrl = window.location.origin;
    return `${baseUrl}/index.php?option=com_pplcz&task=cron.${task}&format=raw&secret=${cronSecret}`;
  };

  return (
    <Card id="sync">
      <Box paddingTop={2} paddingBottom={2} paddingLeft={2} paddingRight={2}>
        <Typography variant="h3" marginBottom={4}>
          Synchronizace objednávek
        </Typography>
        <Typography marginBottom={4}>
          <strong>Limity</strong>
        </Typography>
        <Grid container alignItems={"center"}>
          <Grid item xs={4} display={"flex"} alignContent={"center"}>
            <FormLabel>Synchronizovat max</FormLabel>
          </Grid>
          <Grid item xs={8}>
            <Controller
              name="maxSync"
              control={control}
              render={({ field: { onChange, value }, formState }) => (
                <TextField
                  value={value}
                  size="medium"
                  name={'maxSync'}
                  onChange={onChange}
                  onBlur={e => {
                    const maxSync = getValues("maxSync");
                    if (maxSync) {
                      mutateAsync({ maxSync });
                    }
                  }}
                  InputProps={{
                    type: "number",
                  }}
                  helperText={"Maximální počet synchronizovaných objednávek během jednoho požadavku"}
                />
              )}
            />
          </Grid>
        </Grid>
        <Typography marginTop={4} marginBottom={2}>
          <strong>Synchronizovat dle stavu</strong>
        </Typography>
        <Typography marginBottom={4}>
          Pokud má objednávka zásilku s jedním z vybraných stavů, bude sledovaná.
        </Typography>
        {isLoading || !data ? (
          <Skeleton height={150} sx={{ transform: "scale(1,1)" }} />
        ) : (
          <>
            {(data.phases || []).map(x => {
              return (
                <Fragment key={x.code}>
                  <Check checked={x.watch} label={x.title} name={x.code} orderState={x.orderState || null} />
                </Fragment>
              );
            })}
          </>
        )}
      </Box>

      <Box
        paddingTop={2}
        paddingBottom={2}
        paddingLeft={2}
        paddingRight={2}
        sx={{ borderTop: 1, borderColor: 'divider' }}
      >
        <Typography variant="h3" marginBottom={2}>
          <strong>Automatická synchronizace (Cron)</strong>
        </Typography>

        <Typography variant="body2" color="text.secondary" paragraph>
          Pro automatickou synchronizaci nastavte následující URL jako cron joby na serveru.
        </Typography>

        {/* Shipment Phase Sync */}
        <Box mb={3}>
          <Typography variant="subtitle2" fontWeight="bold" gutterBottom>
            1. Synchronizace zásilek (doporučeno: každých 5 minut)
          </Typography>
          <Box
            sx={{
              bgcolor: 'grey.100',
              p: 2,
              borderRadius: 1,
              fontFamily: 'monospace',
              fontSize: '0.875rem',
              wordBreak: 'break-all'
            }}
          >
            <Box display="flex" alignItems="center" gap={1}>
              <Typography
                component="span"
                sx={{ flex: 1, fontFamily: 'monospace', fontSize: '0.875rem' }}
              >
                {cronSecret ? getCronUrl('shipment_phase') : "Načítání..."}
              </Typography>
              <IconButton
                size="small"
                onClick={() => copy(getCronUrl('shipment_phase'))}
                disabled={!cronSecret}
                title="Kopírovat URL"
              >
                <ContentCopyIcon fontSize="small" />
              </IconButton>
            </Box>
          </Box>
        </Box>

        {/* Delete Logs */}
        <Box mb={3}>
          <Typography variant="subtitle2" fontWeight="bold" gutterBottom>
            2. Mazání starých error logů (doporučeno: 1 denně)
          </Typography>
          <Box
            sx={{
              bgcolor: 'grey.100',
              p: 2,
              borderRadius: 1,
              fontFamily: 'monospace',
              fontSize: '0.875rem',
              wordBreak: 'break-all'
            }}
          >
            <Box display="flex" alignItems="center" gap={1}>
              <Typography
                component="span"
                sx={{ flex: 1, fontFamily: 'monospace', fontSize: '0.875rem' }}
              >
                {cronSecret ? getCronUrl('delete_logs') : "Načítání..."}
              </Typography>
              <IconButton
                size="small"
                onClick={() => copy(getCronUrl('delete_logs'))}
                disabled={!cronSecret}
                title="Kopírovat URL"
              >
                <ContentCopyIcon fontSize="small" />
              </IconButton>
            </Box>
          </Box>
        </Box>

        {/* Refresh About */}
        <Box mb={3}>
          <Typography variant="subtitle2" fontWeight="bold" gutterBottom>
            3. Aktualizace konfigurace (doporučeno: 1 denně)
          </Typography>
          <Box
            sx={{
              bgcolor: 'grey.100',
              p: 2,
              borderRadius: 1,
              fontFamily: 'monospace',
              fontSize: '0.875rem',
              wordBreak: 'break-all'
            }}
          >
            <Box display="flex" alignItems="center" gap={1}>
              <Typography
                component="span"
                sx={{ flex: 1, fontFamily: 'monospace', fontSize: '0.875rem' }}
              >
                {cronSecret ? getCronUrl('refresh_about') : "Načítání..."}
              </Typography>
              <IconButton
                size="small"
                onClick={() => copy(getCronUrl('refresh_about'))}
                disabled={!cronSecret}
                title="Kopírovat URL"
              >
                <ContentCopyIcon fontSize="small" />
              </IconButton>
            </Box>
          </Box>
        </Box>

        <Box display="flex" gap={2} alignItems="center">
          <Button
            variant="outlined"
            size="small"
            startIcon={<RefreshIcon />}
            onClick={handleRegenerateCronKey}
            disabled={regenerating}
          >
            {regenerating ? "Generování..." : "Změnit bezpečnostní klíč"}
          </Button>

          <Typography variant="caption" color="text.secondary">
            Po změně klíče aktualizujte crontab na serveru!
          </Typography>
        </Box>
      </Box>
    </Card>
  );
};

export default ShipmentPhaseForm;
