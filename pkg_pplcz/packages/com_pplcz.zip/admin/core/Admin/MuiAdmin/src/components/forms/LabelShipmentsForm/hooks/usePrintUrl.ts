import { useMemo } from "react";
import { makePrintUrl } from "../../../../connection";
import { components } from "../../../../schema";

type ShipmentWithAdditionalModel = components["schemas"]["ShipmentWithAdditionalModel"];

export const usePrintUrl = (models: ShipmentWithAdditionalModel[], printState: string, generatedUrl: URL | null) => {
  return useMemo(() => {
    if (
      models?.[0]?.shipment?.lock &&
      models[0].shipment.packages?.[0]?.shipmentNumber &&
      models?.[0]?.shipment.batchRemoteId
    ) {
      const url = new URL(makePrintUrl(models?.[0]?.shipment.batchRemoteId, null, null, printState));
      return url;
    }

    if (generatedUrl) {
      // Aktualizovat generatedUrl s novým printState
      const updatedUrl = new URL(generatedUrl.toString());
      updatedUrl.searchParams.set("pplcz_print", printState);
      return updatedUrl;
    }

    return null;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [`${generatedUrl}`, models, printState]);
};
