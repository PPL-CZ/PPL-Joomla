import {useMutation, useQueryClient} from "@tanstack/react-query";
import {baseConnectionUrl, makeApiUrl} from "../connection";
import {components} from "../schema";
import {UnknownErrorException, ValidationErrorException} from "./types";

type UpdateShipmentModel = components["schemas"]["UpdateShipmentModel"];
type UpdateShipmentSenderModel = components["schemas"]["UpdateShipmentSenderModel"];
type RecipientAddressModel = components["schemas"]["RecipientAddressModel"];
type UpdateShipmentParcelModel = components["schemas"]["UpdateShipmentParcelModel"];
type UpdateSyncPhasesModel = components["schemas"]["UpdateSyncPhasesModel"];

/**
 * Mutation pro vytvoření/úpravu zásilky
 */
export const useUpdateShipmentMutation = (onSuccessCallback?: (shipmentId: number) => void) => {
    return useMutation({
        mutationKey: ["shipment-update"],
        mutationFn: async (variables: { shipmentId?: number; data: UpdateShipmentModel }) => {

            const id = variables.shipmentId ? variables.shipmentId : 0;

            const url = makeApiUrl("shipment.update_shipment", { shipment_id: id });

            const response = await fetch(url, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(variables.data),
            });

            if (response.status === 400) {
                const data = await response.json();
                throw new ValidationErrorException(response.status, data.data);
            } else if (response.status > 400) {
                throw new UnknownErrorException(response.status);
            }

            if (response.status === 201) {
                const newId = response.headers.get("location")?.split("/").reverse()?.[0];
                return {shipmentId: parseInt(newId!), isNew: true};
            }

            return {shipmentId: variables.shipmentId!, isNew: false};
        },
        onSuccess: (data) => {
            onSuccessCallback?.(data.shipmentId);
        },
    });
};

/**
 * Mutation pro změnu odesílatele zásilky
 */
export const useUpdateShipmentSenderMutation = (onSuccessCallback?: (shipmentId: number) => void) => {
    return useMutation({
        mutationKey: ["shipment-sender-update"],
        mutationFn: async (variables: { shipmentId: number; senderId: number }) => {

            const url = makeApiUrl("shipment.update_shipment_sender", {
                shipment_id: variables.shipmentId
            });

            const response = await fetch(url, {
                method: "POST",
                headers: {
                    "content-type": "application/json",
                },
                body: JSON.stringify({
                    senderId: variables.senderId,
                } as UpdateShipmentSenderModel),
            });

            if (response.status === 204) {
                return variables.shipmentId;
            }

            throw new Error("Failed to update sender");
        },
        onSuccess: (shipmentId) => {
            onSuccessCallback?.(shipmentId);
        },
    });
};

/**
 * Mutation pro aktualizaci adresy příjemce
 */
export const useUpdateRecipientMutation = (onSuccessCallback?: (shipmentId: number) => void) => {
    return useMutation({
        mutationKey: ["recipient-update"],
        mutationFn: async (variables: { shipmentId: number; address: RecipientAddressModel }) => {

            const url = makeApiUrl("shipment.update_recipient_address", {
                shipment_id: variables.shipmentId
            });

            const response = await fetch(url, {
                method: "POST",
                headers: {
                    "content-type": "application/json",
                },
                body: JSON.stringify(variables.address),
            });

            if (response.status === 400) {
                const data = await response.json();
                throw new ValidationErrorException(response.status, data.data);
            } else if (response.status > 400) {
                throw new UnknownErrorException(response.status);
            }

            return variables.shipmentId;
        },
        onSuccess: (shipmentId) => {
            onSuccessCallback?.(shipmentId);
        },
    });
};

/**
 * Mutation pro aktualizaci parcelshop/parcelbox zásilky
 */
export const useUpdateShipmentParcelMutation = (onSuccessCallback?: (shipmentId: number) => void) => {
    return useMutation({
        mutationKey: ["shipment-parcel-update"],
        mutationFn: async (variables: { shipmentId: number; parcelCode: string; parcelCountry: string }) => {
            const url = makeApiUrl("shipment.update_shipment_parcel", {
                shipment_id: variables.shipmentId,
                parcel_code: variables.parcelCode,
                parcel_country: variables.parcelCountry
            });

            const response = await fetch(url, {
                method: "POST",
                headers: {
                    "content-type": "application/json",
                },
                body: JSON.stringify({
                    parcelCode: variables.parcelCode,
                    parcelCountry: variables.parcelCountry,
                } as UpdateShipmentParcelModel),
            });

            if (response.status === 404) {
                throw new Error("Parcel not found");
            }

            return variables.shipmentId;
        },
        onSuccess: (shipmentId) => {
            onSuccessCallback?.(shipmentId);
        },
    });
};

/**
 * Mutation pro aktualizaci synchronizačních fází zásilek
 */
export const useUpdateShipmentPhasesMutation = () => {
    return useMutation({
        mutationKey: ["shipment-phases-update"],
        mutationFn: async (data: UpdateSyncPhasesModel) => {
            const url = makeApiUrl('setting.set_phase');

            await fetch(url, {
                method: "POST",
                // headers: {
                //   "Content-Type": "application/json",
                // },
                body: JSON.stringify(data),
            });
        },
    });
};
