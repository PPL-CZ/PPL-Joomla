import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Grid from "@mui/material/Grid";
import HeaderMain from "../components/header/main";
import HeaderPage from "../components/header/page";
import useHeaderStyle from "./useHeaderStyle";
import { useShipmentSettings } from "../queries/settings";
import { useMemo, useState } from "react";
import Skeleton from "@mui/material/Skeleton";
import { Alert, Card, Tab, Tabs } from "@mui/material";
import { BaseForm } from "../components/forms/ShipmentSettingForm/BaseForm";
import { useQueryCountries, useQueryCurrencies, useQueryPayments } from "../queries/codelists";
import { components } from "../schema";

type ShipmentMethodSettingModel = components["schemas"]["ShipmentMethodSettingModel"];
type CurrencyModel = components["schemas"]["CurrencyModel"];

const TabPanel = (props: { children?: React.ReactNode; index: number; value: number }) => {
    const { children, value, index, ...other } = props;

    return (
        <div role="tabpanel" hidden={value !== index} {...other}>
            {value === index && <Box>{children}</Box>}
        </div>
    );
};

const ShipmentMethodsPage = () => {
    const { classes } = useHeaderStyle();
    const [tabId, setTabId] = useState(0);

    const payments = useQueryPayments();
    const currencies = useQueryCurrencies();
    const countries = useQueryCountries();
    const { data: rawData } = useShipmentSettings(0);

    const changeTab = (event: React.SyntheticEvent, newValue: number) => {
        setTabId(newValue);
    };

    const upgradedData = useMemo(() => {
        if (rawData && currencies) {
            const dataArray = Array.isArray(rawData) ? rawData : (rawData as any).data || [];

            if (!Array.isArray(dataArray)) {
                return null;
            }

            const newData = dataArray.map((wrapper: any) => {
                const item: ShipmentMethodSettingModel = JSON.parse(JSON.stringify(wrapper.data));

                // Ensure arrays exist
                if (!item.currencies) {
                    item.currencies = [];
                }
                if (!item.allowedParcelCountries) {
                    item.allowedParcelCountries = [];
                }
                if (!item.disablePayments) {
                    item.disablePayments = [];
                }
                if (!item.weights) {
                    item.weights = [];
                }

                const currentCurrencies = item.currencies;
                currencies.forEach((y: CurrencyModel) => {
                    if (!currentCurrencies.some((x) => x.currency === y.code))
                        currentCurrencies.push({
                            currency: y.code,
                        });
                });

                // Return with ID, name, desc and code attached
                return {
                    id: wrapper.id,
                    name: wrapper.name,
                    desc: wrapper.desc,
                    code: wrapper.code,
                    data: item
                };
            });

            return newData;
        }

        return null;
    }, [rawData, currencies]);

    if (!upgradedData || !currencies || !payments || !countries) {
        return (
            <>
                <HeaderMain />
                <HeaderPage
                    left={
                        <Typography component={"h1"} className={classes.h1}>
                            Dopravní metody
                        </Typography>
                    }
                />
                <Box pl={2} pr={2} justifyContent="center" display={"flex"}>
                    <Grid maxWidth={"xl"} pt={4} pb={4} alignContent={"center"} height={"100%"} spacing={0} container>
                        <Grid item xs={12}>
                            <Skeleton />
                        </Grid>
                    </Grid>
                </Box>
            </>
        );
    }

    // Pokud nejsou žádné PPL shipping metody
    if (upgradedData.length === 0) {
        return (
            <>
                <HeaderMain />
                <HeaderPage
                    left={
                        <Typography component={"h1"} className={classes.h1}>
                            Dopravní metody
                        </Typography>
                    }
                />
                <Box pl={2} pr={2} justifyContent="center" display={"flex"}>
                    <Grid maxWidth={"xl"} pt={4} pb={4} alignContent={"center"} height={"100%"} spacing={0} container>
                        <Grid item xs={12}>
                            <Card id="shipmentMethods">
                                <Box paddingTop={2} paddingBottom={2} paddingLeft={2} paddingRight={2}>
                                    <Typography variant="h3" marginBottom={4}>
                                        Nastavení dopravy
                                    </Typography>
                                    <Alert severity="warning">
                                        Nejsou k dispozici žádné dopravní metody.
                                        Vytvořte alespoň jednu dopravní metodu v administraci VirtueMart.
                                    </Alert>
                                </Box>
                            </Card>
                        </Grid>
                    </Grid>
                </Box>
            </>
        );
    }

    return (
        <>
            <HeaderMain />
            <HeaderPage
                left={
                    <Typography component={"h1"} className={classes.h1}>
                        Dopravní metody
                    </Typography>
                }
            />
            <Box pl={2} pr={2} justifyContent="center" display={"flex"}>
                <Grid maxWidth={"xl"} pt={4} pb={4} alignContent={"center"} height={"100%"} spacing={0} container>
                    <Grid item xs={12}>
                        <Card id="shipmentMethods">
                            <Box paddingTop={2} paddingBottom={2} paddingLeft={2} paddingRight={2}>
                                <Typography variant="h3" marginBottom={4}>
                                    Nastavení dopravy
                                </Typography>
                                <Grid item xs={12}>
                                    <Tabs value={tabId} onChange={changeTab} aria-label="basic tabs example">
                                        {upgradedData.map((wrapper: any, index: number) => {
                                            return <Tab key={wrapper.id || index} label={wrapper.name} tabIndex={index} />;
                                        })}
                                    </Tabs>
                                    {upgradedData.map((wrapper: any, index: number) => {
                                        return (
                                            <TabPanel key={wrapper.id || index} index={index} value={tabId}>
                                                <BaseForm
                                                    payments={payments}
                                                    countries={countries}
                                                    data={wrapper.data}
                                                    shipmentMethodId={wrapper.id}
                                                    shipmentMethodName={wrapper.name}
                                                    shipmentMethodDesc={wrapper.desc}
                                                    shipmentMethodCode={wrapper.code}
                                                    asNew={false}
                                                />
                                            </TabPanel>
                                        );
                                    })}
                                </Grid>
                            </Box>
                        </Card>
                    </Grid>
                </Grid>
            </Box>
        </>
    );
};

export default ShipmentMethodsPage;
