import React, { useMemo, useEffect } from "react";
import { useForm, Controller, useFieldArray, useFormContext, FormProvider } from "react-hook-form";
import { CSSProperties } from "react";
import { components } from "../schema";

type Data = components["schemas"]["ProductModel"];
type ShipmentMethodModel = components["schemas"]["ShipmentMethodModel"];
type PackageModel = components["schemas"]["PackageSizeModel"];

interface ProductProps {
    data: Data;
    methods: ShipmentMethodModel[];
    nonce: string;
    element: HTMLElement;
}
const Package = (props: {
    position: number,
    remove: (index: number) => void
}) => {
    const { register } = useFormContext<Data>()

    const inputSize: CSSProperties = {
        display: "inline",
        width: '5em'
    }

    return <tr>
        <td>
            <input id={`pplXSize_${props.position}`} size={7} style={inputSize}
                   type={"number"} {...register(`pplSizes.${props.position}.xSize`)} />
        </td>
        <td>
            <input id={`pplYSize_${props.position}`} size={7} style={inputSize}
                   type={"number"} {...register(`pplSizes.${props.position}.ySize`)} />
        </td>
        <td>
            <input id={`pplZSize_${props.position}`} size={7} style={inputSize}
                   type={"number"} {...register(`pplSizes.${props.position}.zSize`)} />
        </td>
        <td>
            <a href={'#'} onClick={(ev) => {
                ev.preventDefault();
                props.remove(props.position);
            }}>[x]</a>
        </td>
    </tr>
}


const Product = (props: ProductProps) => {
    const formCtx = useForm<Data>({
        defaultValues: { ...(props.data || {}) },
    });

    const { register, control, watch } = formCtx;

    const { fields, append, remove } = useFieldArray({
        control,
        name: "pplSizes"
    });

    const float: CSSProperties = {
        float: "none",
        width: "auto"
    };

    const thStyle: CSSProperties = {
        textAlign: "left",
        padding: "5px"
    };

    const methods = useMemo(() => {
        const sortedMethods = props.methods.map(x => x);
        sortedMethods.sort((x, y) => {
            return x.title.localeCompare(y.title);
        });
        return sortedMethods;
    }, [props.methods]);

    // Sledovat všechny hodnoty formuláře
    const formValues = watch();

    // Synchronizovat s hidden inputy v hlavním VirtueMart formuláři
    useEffect(() => {
        // Najít rodičovský VirtueMart formulář (MIMO shadow DOM)
        const vmForm = document.querySelector('form[name="adminForm"]') as HTMLFormElement;

        if (!vmForm) {
            return;
        }

        // Vytvořit/aktualizovat hidden inputy
        const fieldNames = [
            'pplConfirmAge15',
            'pplConfirmAge18',
            'pplDisabledParcelBox',
            'pplDisabledAlzaBox',
            'pplDisabledParcelShop',
            'pplDisabledTransport'
        ] as const;

        fieldNames.forEach(fieldName => {
            const value = formValues[fieldName as keyof Data];

            if (fieldName === 'pplDisabledTransport') {
                // Smazat staré pplDisabledTransport[] inputy
                vmForm.querySelectorAll('input[name="pplDisabledTransport[]"]').forEach(el => el.remove());

                // Vytvořit nové pro každou hodnotu v poli
                if (Array.isArray(value) && value.length > 0) {
                    value.forEach(code => {
                        if (typeof code === 'string') {
                            const input = document.createElement('input');
                            input.type = 'hidden';
                            input.name = 'pplDisabledTransport[]';
                            input.value = code;
                            input.setAttribute('data-pplcz', 'true');
                            vmForm.appendChild(input);
                        }
                    });
                }
            } else {
                // Ostatní pole - checkbox hodnoty
                let input = vmForm.querySelector(`input[name="${fieldName}"][data-pplcz="true"]`) as HTMLInputElement;
                if (!input) {
                    input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = fieldName;
                    input.setAttribute('data-pplcz', 'true');
                    vmForm.appendChild(input);
                }
                input.value = value ? '1' : '0';
            }
        });

        // Synchronizovat pplSizes (balíčky)
        // Smazat staré pplSizes inputy
        vmForm.querySelectorAll('input[name^="pplSizes["][data-pplcz="true"]').forEach(el => el.remove());

        // Vytvořit nové pro každý balíček
        if (formValues.pplSizes && Array.isArray(formValues.pplSizes) && formValues.pplSizes.length > 0) {
            formValues.pplSizes.forEach((size, index) => {
                if (size && typeof size === 'object') {
                    // Vytvořit input pro xSize
                    if (size.xSize !== null && size.xSize !== undefined) {
                        const inputX = document.createElement('input');
                        inputX.type = 'hidden';
                        inputX.name = `pplSizes[${index}][xSize]`;
                        inputX.value = String(size.xSize);
                        inputX.setAttribute('data-pplcz', 'true');
                        vmForm.appendChild(inputX);
                    }

                    // Vytvořit input pro ySize
                    if (size.ySize !== null && size.ySize !== undefined) {
                        const inputY = document.createElement('input');
                        inputY.type = 'hidden';
                        inputY.name = `pplSizes[${index}][ySize]`;
                        inputY.value = String(size.ySize);
                        inputY.setAttribute('data-pplcz', 'true');
                        vmForm.appendChild(inputY);
                    }

                    // Vytvořit input pro zSize
                    if (size.zSize !== null && size.zSize !== undefined) {
                        const inputZ = document.createElement('input');
                        inputZ.type = 'hidden';
                        inputZ.name = `pplSizes[${index}][zSize]`;
                        inputZ.value = String(size.zSize);
                        inputZ.setAttribute('data-pplcz', 'true');
                        vmForm.appendChild(inputZ);
                    }
                }
            });
        }

        // Cleanup při unmount
        return () => {
            vmForm.querySelectorAll('input[data-pplcz="true"]').forEach(el => el.remove());
        };
    }, [formValues]);

    return (
        <div className="pplcz-product-tab">
            <div>
                <label style={float}><strong>Věkové omezení (pouze v případě ČR se tato služba poskytuje)</strong></label>
            </div>
            <label style={float} htmlFor={"pplConfirmAge15"}>
                <input
                    style={float}
                    id={"pplConfirmAge15"}
                    type="checkbox"
                    {...register("pplConfirmAge15")}
                />
                &nbsp;Ověření věku 15+
            </label>
            <br/>
            <label style={float} htmlFor={"pplConfirmAge18"}>
                <input
                    style={float}
                    id={"pplConfirmAge18"}
                    type="checkbox"
                    {...register("pplConfirmAge18")}
                />
                &nbsp;Ověření věku 18+
            </label>
            <br/>
            <label style={float}><strong>Seznam zakázaných míst (pro výdejní místa)</strong></label>
            <div>
                <label style={float}>
                    <input
                        id="pplDisabledParcelBox"
                        value="1"
                        type="checkbox"
                        {...register('pplDisabledParcelBox')}
                    />
                    &nbsp;ParcelBoxy
                </label>
            </div>
            <div>
                <label style={float}>
                    <input
                        id="pplDisabledAlzaBox"
                        value="1"
                        type="checkbox"
                        {...register('pplDisabledAlzaBox')}
                    />
                    &nbsp;AlzaBoxy
                </label>
            </div>
            <div>
                <label style={float}>
                    <input
                        id="pplDisabledParcelShop"
                        value="1"
                        type="checkbox"
                        {...register('pplDisabledParcelShop')}
                    />
                    &nbsp;Obchody
                </label>
            </div>

            <FormProvider {...formCtx}>
                <div>
                    <label style={float}><strong>Produkt lze případně rozdělit na menší balíčky</strong></label>
                    <div>
                        {fields.length > 0 && (
                            <table style={{marginTop: '10px', marginBottom: '10px'}}>
                                <thead>
                                <tr>
                                    <th style={thStyle}>Šířka (cm)</th>
                                    <th style={thStyle}>Výška (cm)</th>
                                    <th style={thStyle}>Hloubka (cm)</th>
                                    <th/>
                                </tr>
                                </thead>
                                <tbody>
                                {fields.map((item, index) => {
                                    return <Package key={item.id} position={index} remove={remove}/>
                                })}
                                </tbody>
                            </table>
                        )}
                        <div style={{marginTop: '5px'}}>
                            <a href={'#'} onClick={ev => {
                                ev.preventDefault();
                                append({xSize: null, ySize: null, zSize: null});
                            }}>Přidat řádek</a>
                        </div>
                    </div>
                </div>
            </FormProvider>

            <label style={float}><strong>Seznam zakázaných metod</strong></label>
            <br/>
            {methods.map(shipment => (
                <Controller
                    key={shipment.code}
                    control={control}
                    name="pplDisabledTransport"
                    render={(fieldProps) => {
                        const value = (fieldProps.field.value || []) as string[];
                        const checked = value.indexOf(shipment.code) > -1;

                        return (
                            <div>
                                <label style={float} htmlFor={`pplDisabledTransport_${shipment.code}`}>
                                    <input
                                        value={shipment.code}
                                        style={float}
                                        id={`pplDisabledTransport_${shipment.code}`}
                                        type="checkbox"
                                        checked={checked}
                                        onChange={() => {
                                            if (value.indexOf(shipment.code) > -1) {
                                                fieldProps.field.onChange(value.filter(x => x !== shipment.code));
                                            } else {
                                                fieldProps.field.onChange(value.concat([shipment.code]));
                                            }
                                        }}
                                    />
                                    &nbsp;{shipment.title}
                                </label>
                            </div>
                        );
                    }}
                />
            ))}
        </div>
    );
};

export default Product;