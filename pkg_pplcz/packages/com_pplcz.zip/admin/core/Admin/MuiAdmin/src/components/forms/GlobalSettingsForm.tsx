import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Card from "@mui/material/Card";
import Grid from "@mui/material/Grid";
import Typography from "@mui/material/Typography";
import Skeleton from "@mui/material/Skeleton";

import { components } from "../../schema";
import { Controller, useForm } from "react-hook-form";
import {useEffect, useState} from "react";
import SavingProgress from "../SavingProgress";
import {
    useGlobalSettingQuery,
    useGlobalSettingMutation
} from "../../queries/settings";
import TextField from "@mui/material/TextField";
import FormLabel from "@mui/material/FormLabel";

type GlobalSettingModel = components["schemas"]["GlobalSettingModel"];

const GlobalSettingForm = () => {

  const { reset, handleSubmit, control, setError } = useForm<GlobalSettingModel>();
  const [update, setUpdate] = useState(false);
  const [success, setSuccess] = useState(false);
  const { data, isLoading } = useGlobalSettingQuery();

  console.log(data);

    useEffect(() => {
        if (data) {
            reset(data)
        }
    }, [data]);


  const { mutateAsync } = useGlobalSettingMutation();

  return (

      <Card>
        {update ? <SavingProgress /> : false}
        <Box id="globalsetting" paddingTop={2} paddingBottom={2} paddingLeft={2} paddingRight={2}>
          <Typography variant="h3" marginBottom={4}>
            Nastavení mapového widgetu
          </Typography>
          {isLoading ? (
            <Skeleton height={150} sx={{ transform: "scale(1,1)" }} />
          ) : (
            <Box marginTop={4}>
              <form
                onSubmit={handleSubmit(async fields => {
                  setUpdate(true);
                  setSuccess(false);
                  try {
                    await mutateAsync(fields);
                    setSuccess(true);
                  } catch (error) {
                    // Error handling pokud bude potřeba
                  } finally {
                    setUpdate(false);
                  }
                })}
              >
                <Grid container alignItems={"center"}>
                    <Grid item xs={4} display={"flex"} alignContent={"center"}>
                        <FormLabel>API klíč pro widget</FormLabel>
                    </Grid>
                    <Grid item xs={8} display={"flex"} alignContent={"center"}>
                        <Grid container>
                            <Grid item xs={12}>
                                <Controller
                                    name="map.apikey"
                                    control={control}
                                    render={({ field: { onChange, value }, fieldState: { error } }) => (
                                        <TextField
                                            id="apikey"
                                            name={"apikey"}
                                            value={value ?? ""}
                                            size="medium"
                                            onChange={onChange}
                                            error={!!error}
                                            helperText={error?.message}
                                        />
                                    )}
                                />
                            </Grid>
                            <Grid item xs={12}>
                                <span style={{ fontSize: "1.1rem" }}>
                                    Pro používání nové mapy si prosím vygenerujte API klíč v administraci{" "}
                                    <a target={"_blank"} href={"https://klient.ppl.cz/widgetadmin"}>ZDE</a>.
                                </span>
                            </Grid>
                        </Grid>
                    </Grid>
                </Grid>
                <Box marginTop={4} marginBottom={4}>
                  <Button type="submit">Uložit</Button>
                </Box>
              </form>
            </Box>
          )}
        </Box>
      </Card>
  );
};

export default GlobalSettingForm;
