<?php
namespace PPLCZ\Admin;
defined("_JEXEC") or die();

class Errors
{
    private $errors = [];

    public function add($code, $message, $data = '')
    {
        $code = ltrim($code, ".");
        if (!isset($this->errors[$code])) {
            $this->errors[$code] = [];
        }
        $this->errors[$code][] = $message;
    }

    public function hasErrors()
    {
        return !empty($this->errors);
    }

    public function getErrors()
    {
        return $this->errors;
    }

    public function getErrorMessage()
    {
        if (empty($this->errors)) {
            return '';
        }
        $firstError = reset($this->errors);
        return is_array($firstError) ? $firstError[0] : $firstError;
    }

}