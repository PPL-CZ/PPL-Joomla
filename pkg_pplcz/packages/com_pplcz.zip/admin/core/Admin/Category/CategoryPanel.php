<?php

namespace PPLCZ\Admin\Category;

defined("_JEXEC") or die();

use PPLCZ\Admin\Assets\JsTemplate;
use PPLCZ\Model\Model\CategoryModel;
use PPLCZ\Model\Model\PackageSizeModel;
use PPLCZ\ModelNormalizer\ShipmentSettingDenormalizer;
use PPLCZ\Serializer;
use PPLCZ\Setting\MethodSetting;

require_once __DIR__ . '/../../autoloader.php';

class CategoryPanel {

    /**
     * Get available shipping methods
     * @return array
     */

    public static function get_shipping()
    {
        $output = [];
        foreach (MethodSetting::getMethods() as $v) {
            $output[] = pplcz_normalize($v);
        }
        return $output;
    }

    /**
     * Render category form
     * @param int|null $virtuemart_category_id
     */
    public static function Render($virtuemart_category_id = null) {
        // Joomla/VirtueMart verze
        if ($virtuemart_category_id === null) {
            $app = \Joomla\CMS\Factory::getApplication();
            $virtuemart_category_id = $app->input->getInt('virtuemart_category_id', 0);
        }

        if (!$virtuemart_category_id) {
            // Nová kategorie - prázdný model
            $model = new CategoryModel();
        } else {
            // Načtení existující kategorie z databáze
            $db = \Joomla\CMS\Factory::getDbo();
            $query = $db->getQuery(true);
            $query->select('params')
                ->from($db->quoteName('#__pplcz_category'))
                ->where($db->quoteName('virtuemart_category_id') . ' = ' . (int)$virtuemart_category_id);
            $db->setQuery($query);
            $params = $db->loadResult();

            if ($params) {
                $data = json_decode($params, true);
                $model = Serializer::getInstance()->denormalize($data, CategoryModel::class);
            } else {
                $model = new CategoryModel();
            }
        }

        $model = Serializer::getInstance()->normalize($model, "array");
        $shipments = self::get_shipping();
        $nonce = md5(uniqid());

        ?><div
                id="pplcz_category_overlay"
                class="panel"
                data-data='<?php echo htmlspecialchars(json_encode(pplcz_normalize($model))); ?>'
                data-methods='<?php echo htmlspecialchars(json_encode($shipments)); ?>'
                data-pplNonce='<?php echo htmlspecialchars(json_encode($nonce)); ?>'
        >
        </div>
        <?php
        JsTemplate::addInlineScript("Category", "pplcz_category_overlay");
    }

    /**
     * Save category data
     * @param int $virtuemart_category_id
     */
    public static function Save($virtuemart_category_id) {
        // Joomla/VirtueMart verze
        $app = \Joomla\CMS\Factory::getApplication();
        $input = $app->input;

        $model = new CategoryModel();
        $pplDisabledParcelBox = false;
        $pplDisabledParcelShop = false;
        $pplDisabledAlzaBox = false;

        $pplConfirmAge15 = false;
        $pplConfirmAge18 = false;
        $pplDisabledTransport = [];

        // Načtení dat z POST
        if ($input->post->get('pplConfirmAge15'))
            $pplConfirmAge15 = $input->post->get('pplConfirmAge15', '', 'INT');
        if ($input->post->get('pplConfirmAge18'))
            $pplConfirmAge18 = $input->post->get('pplConfirmAge18', '', 'INT');
        if ($input->post->get('pplDisabledTransport'))
            $pplDisabledTransport = $input->post->get('pplDisabledTransport', array(), 'ARRAY');

        if ($input->post->get('pplDisabledParcelBox'))
            $pplDisabledParcelBox = $input->post->get('pplDisabledParcelBox', '', 'INT');

        if ($input->post->get('pplDisabledParcelShop'))
            $pplDisabledParcelShop = $input->post->get('pplDisabledParcelShop', '', 'INT');

        if ($input->post->get('pplDisabledAlzaBox'))
            $pplDisabledAlzaBox = $input->post->get('pplDisabledAlzaBox', '', 'INT');

        // Package size (single object, not array like product)
        $xSize = null;
        $ySize = null;
        $zSize = null;

        if ($input->post->exists('pplSize_xSize')) {
            $xSize = $input->post->get('pplSize_xSize', null, 'INT');
            if ($xSize <= 0)
                $xSize = null;
        }

        if ($input->post->exists('pplSize_ySize')) {
            $ySize = $input->post->get('pplSize_ySize', null, 'FLOAT');
            if ($ySize <= 0)
                $ySize = null;
        }

        if ($input->post->exists('pplSize_zSize')) {
            $zSize = $input->post->get('pplSize_zSize', null, 'FLOAT');
            if ($zSize <= 0)
                $zSize = null;
        }

        // Set package size if any dimension is provided
        if ($xSize || $ySize || $zSize) {
            $size = new PackageSizeModel();
            $size->setXSize($xSize);
            $size->setYSize($ySize);
            $size->setZSize($zSize);
            $model->setPplSize($size);
        }

        // Nastavení do modelu
        $model->setPplConfirmAge15(!!$pplConfirmAge15);
        $model->setPplConfirmAge18(!!$pplConfirmAge18);

        if (is_array($pplDisabledTransport)) {
            $model->setPplDisabledTransport($pplDisabledTransport);
        }
        $model->setPplDisabledParcelBox(!!$pplDisabledParcelBox);
        $model->setPplDisabledParcelShop(!!$pplDisabledParcelShop);
        $model->setPplDisabledAlzaBox(!!$pplDisabledAlzaBox);

        // Uložení do databáze
        $db = \Joomla\CMS\Factory::getDbo();
        $query = $db->getQuery(true);

        // Serializace modelu
        $params = json_encode(Serializer::getInstance()->normalize($model, 'array'));

        // Kontrola, zda už záznam existuje
        $query->select('COUNT(*)')
            ->from($db->quoteName('#__pplcz_category'))
            ->where($db->quoteName('virtuemart_category_id') . ' = ' . (int)$virtuemart_category_id);
        $db->setQuery($query);
        $exists = $db->loadResult();

        if ($exists) {
            // UPDATE
            $query = $db->getQuery(true);
            $query->update($db->quoteName('#__pplcz_category'))
                ->set($db->quoteName('params') . ' = ' . $db->quote($params))
                ->where($db->quoteName('virtuemart_category_id') . ' = ' . (int)$virtuemart_category_id);
        } else {
            // INSERT
            $query = $db->getQuery(true);
            $query->insert($db->quoteName('#__pplcz_category'))
                ->columns(array($db->quoteName('virtuemart_category_id'), $db->quoteName('params')))
                ->values((int)$virtuemart_category_id . ', ' . $db->quote($params));
        }

        $db->setQuery($query);
        $db->execute();
    }
}
