<?php

namespace PPLCZ\Admin\Product;

defined("_JEXEC") or die();

use Joomla\CMS\Factory;
use PPLCZ\Admin\Assets\JsTemplate;
use PPLCZ\Model\Model\ProductModel;
use PPLCZ\Entity\ProductEntity;
use PPLCZ\ModelNormalizer\ShipmentSettingDenormalizer;
use PPLCZ\Serializer;
use PPLCZ\Model\Model\ShipmentMethodModel;
use PPLCZ\Setting\MethodSetting;
use PPLCZ\ShipmentMethod;

require_once __DIR__ . '/../../autoloader.php';

class Tab {

    /**
     * @param array $tabs
     * @return array
     */
    public static function Tabs($tabs)
    {
        $tabs["pplcz_shipping_tab"] = [
            "label" => "PPL",
            "target" => "pplcz_tab_overlay",
            "class" => [ 'hide_if_virtual', 'hide_if_downloadable'  ]
        ];

        return $tabs;
    }

    public static function get_shipping()
    {
        $output = [];
        foreach (MethodSetting::getMethods() as $v) {
            $shipmentMethodModel = pplcz_normalize($v);
            $output[] = $shipmentMethodModel;
        }
        return $output;
    }

    public static function Render($virtuemart_product_id = null) {
        // Joomla/VirtueMart verze
        if ($virtuemart_product_id === null) {
            $app = \Joomla\CMS\Factory::getApplication();
            $virtuemart_product_id = $app->input->getInt('virtuemart_product_id', 0);
        }

        if (!$virtuemart_product_id) {
            // Nový produkt - prázdný model
            $model = new ProductModel();
        } else {
            // Načtení existujícího produktu
            \JTable::addIncludePath(JPATH_ADMINISTRATOR . '/components/com_virtuemart/tables');
            $productTable = \JTable::getInstance('products', 'Table');
            $productTable->load($virtuemart_product_id);

            $model = Serializer::getInstance()->denormalize($productTable, ProductModel::class);
        }

        $model = Serializer::getInstance()->normalize($model, "array");
        $shipments = self::get_shipping();
        $nonce = md5(uniqid());

        ?><div
                id="pplcz_tab_overlay"
                class="panel"
                data-data='<?php echo htmlspecialchars(json_encode(pplcz_normalize($model))); ?>'
                data-methods='<?php echo htmlspecialchars(json_encode($shipments)); ?>'
                data-pplNonce='<?php echo htmlspecialchars(json_encode($nonce)); ?>'
        >
        </div>
        <?php
        JsTemplate::addInlineScript("Product", "pplcz_tab_overlay");
    }

    public static function Save($virtuemart_product_id) {
        // Joomla/VirtueMart verze
        $app = \Joomla\CMS\Factory::getApplication();
        $input = $app->input;

        $model = new ProductModel();
        $pplDisabledParcelBox = false;
        $pplDisabledParcelShop = false;
        $pplDisabledAlzaBox = false;

        $pplConfirmAge15 = false;
        $pplConfirmAge18 = false;
        $pplDisabledTransport = [];

        // Načtení dat z POST
        if ($input->post->get('pplConfirmAge15'))
            $pplConfirmAge15 = $input->post->get('pplConfirmAge15', '', 'INT');
        if ($input->post->get('pplConfirmAge18'))
            $pplConfirmAge18 = $input->post->get('pplConfirmAge18', '', 'INT');
        if ($input->post->get('pplDisabledTransport'))
            $pplDisabledTransport = $input->post->get('pplDisabledTransport', array(), 'ARRAY');

        if ($input->post->get('pplDisabledParcelBox'))
            $pplDisabledParcelBox = $input->post->get('pplDisabledParcelBox', '', 'INT');

        if ($input->post->get('pplDisabledParcelShop'))
            $pplDisabledParcelShop = $input->post->get('pplDisabledParcelShop', '', 'INT');

        if ($input->post->get('pplDisabledAlzaBox'))
            $pplDisabledAlzaBox = $input->post->get('pplDisabledAlzaBox', '', 'INT');

        $pplSizes = [];
        if ($input->post->get('pplSizes'))
            $pplSizes = $input->post->get('pplSizes', array(), 'ARRAY');

        // Nastavení do modelu
        $model->setPplConfirmAge15(!!$pplConfirmAge15);
        $model->setPplConfirmAge18(!!$pplConfirmAge18);

        if (is_array($pplDisabledTransport)) {
            $model->setPplDisabledTransport($pplDisabledTransport);
        }
        $model->setPplDisabledParcelBox(!!$pplDisabledParcelBox);
        $model->setPplDisabledParcelShop(!!$pplDisabledParcelShop);
        $model->setPplDisabledAlzaBox(!!$pplDisabledAlzaBox);

        if (is_array($pplSizes)) {
            $model->setPplSizes($pplSizes);
        }

        // Uložení do databáze
        $db = Factory::getContainer()->get('DatabaseDriver');
        $query = $db->getQuery(true);

        // Serializace modelu
        $params = json_encode(Serializer::getInstance()->normalize($model, 'array'));

        // Kontrola, zda už záznam existuje
        $query->select('COUNT(*)')
            ->from($db->quoteName('#__pplcz_product'))
            ->where($db->quoteName('virtuemart_product_id') . ' = ' . (int)$virtuemart_product_id);
        $db->setQuery($query);
        $exists = $db->loadResult();

        if ($exists) {
            // UPDATE
            $query = $db->getQuery(true);
            $query->update($db->quoteName('#__pplcz_product'))
                ->set($db->quoteName('params') . ' = ' . $db->quote($params))
                ->where($db->quoteName('virtuemart_product_id') . ' = ' . (int)$virtuemart_product_id);
        } else {
            // INSERT
            $query = $db->getQuery(true);
            $query->insert($db->quoteName('#__pplcz_product'))
                ->columns(array($db->quoteName('virtuemart_product_id'), $db->quoteName('params')))
                ->values((int)$virtuemart_product_id . ', ' . $db->quote($params));
        }

        $db->setQuery($query);
        $db->execute();
    }

}

