import "./product/tab";
import InitCategoryTab from "./category/init";
import InitProductTab from "./product/init";



window.PPLczPlugin = window.PPLczPlugin ||  [];

const PPLczPlugin = window.PPLczPlugin;

// Registrace funkcí
PPLczPlugin.pplczInitCategoryTab = InitCategoryTab;
PPLczPlugin.pplczInitProductTab = InitProductTab;


// Zpracování fronty - zavolá funkce, které byly přidány přes push()
const processQueue = () => {
    const queue = [...PPLczPlugin]; // kopie pole
    PPLczPlugin.length = 0; // vyčisti frontu

    queue.forEach(item => {
        if (Array.isArray(item)) {
            const [functionName, ...args] = item;
            const fn = PPLczPlugin[functionName];

            if (typeof fn === 'function') {
                // Najdi element podle ID
                if (args.length > 0 && typeof args[0] === 'string') {
                    const element = document.getElementById(args[0]);
                    if (element) {
                        fn(element, ...args.slice(1));
                    } else {
                        console.error(`PPLczPlugin: Element "${args[0]}" not found for function "${functionName}"`);
                    }
                } else {
                    fn(...args);
                }
            } else {
                console.error(`PPLczPlugin: Function "${functionName}" not found`);
            }
        }
    });
};

// Zpracuj frontu při načtení DOM
document.addEventListener('DOMContentLoaded', processQueue);

// Zpracuj frontu i hned (pro případ, že už je DOM ready)
if (document.readyState === 'loading') {
    // DOM ještě není ready, čekáme na DOMContentLoaded
} else {
    // DOM je ready, zpracuj frontu hned
    processQueue();
}



