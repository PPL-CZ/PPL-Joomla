<?php

namespace PPLCZ\Admin\Assets;

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Session\Session;

//require_once "administrator/components/com_pplcz/core/autoloader.php";

class JsTemplate
{
    public const COLLECTIONURL = "https://www1.ppl.cz";

    protected static $isAdded = false;

    /**
     * Registrace a spuštění skriptů
     */
    public static function scripts(): void
    {
        if (!self::$isAdded) {
            self::adminScripts();
            self::$isAdded = true;
        }
    }

    /**
     * Přidá inline push do PPLczPlugin fronty
     */
    public static function addInlineScript(string $functionName, ?string $element = null): void
    {
        $doc = Factory::getApplication()->getDocument();
        if (!self::$isAdded) {
            $doc->addScriptDeclaration('window.PPLczPlugin = window.PPLczPlugin || [];');
        }
        self::$isAdded = true;

        if ($element) {
            $doc->addScriptDeclaration(
                sprintf('window.PPLczPlugin.push(["%s", "%s"]);', addslashes($functionName), addslashes($element))
            );
        } else {
            $doc->addScriptDeclaration(
                sprintf('window.PPLczPlugin.push(["%s"]);', addslashes($functionName))
            );
        }
    }

    /**
     * Načte React build a předá data do JS
     */
    protected static function adminScripts(): void
    {
        $doc = Factory::getApplication()->getDocument();
        $wa = $doc->getWebAssetManager();

        // Load jQuery (required by admin-order.js)
        $wa->useScript('jquery');

        // hlavní React JS (uprav hash podle buildu)
        $wa->registerAndUseScript('pplcz-assets', Uri::root() . 'administrator/components/com_pplcz/core/Admin/Assets/build/bundle.js', [], ['defer' => true]);
        $wa->registerAndUseScript('pplcz-muiadmin', Uri::root() . 'administrator/components/com_pplcz/core/Admin/MuiAdmin/build/static/js/bundle.js', [], ['defer' => true]);
        $wa->registerAndUseScript('pplcz_map_js', Uri::root() . 'administrator/components/com_pplcz/core/Front/Components/Map/ppl-map.js', [], ['defer' => true]);
        $wa->registerAndUseStyle('pplcz_map_css', Uri::root() . 'administrator/components/com_pplcz/core/Front/Components/Map/ppl-map.css', [], ['defer' => true]);
        $wa->registerAndUseScript('pplcz-admin-order', Uri::root() . 'administrator/components/com_pplcz/core/Admin/Assets/assets/js/admin-order.js', ['jquery', 'pplcz-muiadmin'], ['defer' => true]);
        // Inicializace fronty
        $doc->addScriptDeclaration('window.PPLczPlugin = window.PPLczPlugin || [];');

        // Konfigurace mapy pro výběr ParcelShop/ParcelBox
        $mapUrl = Uri::root() . 'index.php?option=com_pplcz&view=map&tmpl=component';
        $mapConfig = ['mapurl' => $mapUrl, 'siteurl' => Uri::root()];
        $doc->addScriptDeclaration('window.PPLCZ_MAP_CONFIG = ' . json_encode($mapConfig) . ';');

        // Předání PHP → JS dat
        $pluginData = [
            "token" => Session::getFormToken(),
            "url" => Uri::base() . 'index.php?option=com_pplcz&format=json',
            "api_get_url" => Uri::base() . 'index.php?option=com_pplcz&task=setting.get_api&format=json',
            "pluginPath" => Uri::root() . 'administrator/components/com_pplcz/core/Admin/MuiAdmin/build/static',
            "newCollectionUrl" => self::COLLECTIONURL,
            "ajax_url" => Uri::base() . 'index.php?option=com_ajax&plugin=pplcz&format=json',
            "file_download_url" => Uri::base() . 'index.php?option=com_pplcz&task=file.download'
        ];

        $doc->addScriptOptions('pplcz_data', $pluginData);

    }
}
