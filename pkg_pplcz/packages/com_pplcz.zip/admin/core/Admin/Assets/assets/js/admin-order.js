function pplczAdminOrder() {

    const panel = jQuery(".pplcz-panel")

    const get_data = (element) => {
        const item = jQuery(element || panel)

        const orderId = item.data("orderid");
        const shipmentId = item.data("shipmentid");
        const packageId = item.data("packageid");
        const shipment = item.data("shipment");
        const optionals = item.data("optionals");
        const value = item.data("value");
        return {
            orderId,
            shipmentId,
            packageId,
            shipment,
            optionals,
            value
        }
    }

    // Získat orderId a id panelu na začátku
    const orderId = panel.data("orderid");
    const panelId = panel.attr('id');

    const disable = () => {
        panel.find('button').prop('disabled', true);
    }
    const enable = () => {
        panel.find('button').prop('disabled', false);
    }

    const makeUrl = (name, pathToReplace, values) => {
        return window.PPLczPlugin.makeUrl(name, pathToReplace, values);
    }

    /**
     * Vytvoří Joomla admin URL s dynamickou doménou
     * @param {string} task - task parameter (např. "shipment.rerender")
     * @param {Object} params - další URL parametry
     * @returns {URL} Kompletní URL objekt
     */
    const makeJoomlaUrl = (task, params = {}) => {
        const url = new URL(window.location.origin + '/administrator/index.php');
        url.searchParams.set('option', 'com_pplcz');
        url.searchParams.set('task', task);

        Object.entries(params).forEach(([key, value]) => {
            if (value !== undefined && value !== null) {
                url.searchParams.set(key, String(value));
            }
        });

        return url;
    }

    const refresh = () => {
        const url = makeJoomlaUrl("shipment.rerender", { order_id: orderId });

        return fetch(url).then(x => {
            return x.text().then(text => {
                try {
                    return JSON.parse(text);
                } catch (e) {
                    throw new SyntaxError('Server returned non-JSON response: ' + text.substring(0, 200));
                }
            });
        }).then((response) => {
            // Zpracovat HTML - může být v response.html nebo response.data.html
            let html = response.html || (response.data && response.data.html) || response;
            jQuery(`#${panelId}`).replaceWith(html);
            pplczAdminOrder();
        }).catch(err => {
            throw err;
        });
    }

    const run = (url, method) => {
        method = method || 'GET';
        return fetch(url, {
            method: method,
        }).then(x => {
            if (x.status >= 300)
                throw new Error(x.statusText);
            return x;
        }).then(() => {
            return refresh();
        }).catch((err) => {
            enable();
        });
    }


    panel.find(".cancel-package").on("click", function (e) {
        e.preventDefault();
        disable();
        const data = get_data(this);
        const url = makeJoomlaUrl("shipment.cancel_package", {
            package_id: data.packageId,
            shipment_id: data.shipmentId,
            order_id: data.orderId
        });
        run(url, "POST");
    })

    panel.find(".pplcz_available_print_setting").on("click", function (e) {
        e.preventDefault();
        disable();
        const data = get_data(this);
        const PPLczPlugin = window.PPLczPlugin = window.PPLczPlugin || [];

        const optionals = data.optionals;
        let currentValue = data.value;
        const shipmentId = data.shipmentId;
        const item = jQuery("<div>").prependTo("body")[0];
        let myrender = null;
        let unmount = null;
        let cachedResponse = null;

        const onFinish = () => {
            unmount();

            if (cachedResponse) {
                jQuery(`#${panelId}`).replaceWith(cachedResponse);
                pplczAdminOrder();
            } else {
                const url = makeJoomlaUrl("shipment.change_print", {
                    print: currentValue,
                    order_id: orderId,
                    shipment_id: shipmentId
                });

                fetch(url, { method: "POST" })
                    .then(x => {
                        if (!x.ok) {
                            throw new Error(`HTTP ${x.status}: ${x.statusText}`);
                        }
                        return x.json();
                    })
                    .then(response => {
                        const html = response.html || (response.data && response.data.html) || response;
                        jQuery(`#${panelId}`).replaceWith(html);
                        pplczAdminOrder();
                    })
                    .catch(error => {
                        console.error('Error in onFinish:', error);
                        enable();
                    });
            }
        };

        const onChange = (newValue) => {
            currentValue = newValue;
            cachedResponse = null;

            if (myrender) {
                myrender({
                    optionals,
                    value: newValue,
                    onFinish,
                    onChange
                });
            }

            const url = makeJoomlaUrl("shipment.change_print", {
                print: newValue,
                order_id: orderId,
                shipment_id: shipmentId
            });

            fetch(url, { method: "POST" })
                .then(x => {
                    if (!x.ok) {
                        console.error(`HTTP ${x.status}: ${x.statusText}`);
                        return null;
                    }
                    return x.json();
                })
                .then(response => {
                    if (response) {
                        const html = response.html || (response.data && response.data.html) || null;
                        if (html) {
                            cachedResponse = html;
                        }
                    }
                })
                .catch(error => {
                    console.error('Error in onChange fetch:', error);
                });
        };

        PPLczPlugin.push(["selectLabelPrint", item, {
            optionals,
            value: currentValue,
            onFinish,
            onChange,
            returnFunc: (returnData) => {
                unmount = returnData.unmount;
                myrender = returnData.render;
            }
        }]);
    })


    panel.find(".add-package").on("click", function (e) {

        e.preventDefault();
        disable();
        const data = get_data(this);
        (async () => {
            const url = makeJoomlaUrl("shipment.add_package", {
                order_id: data.orderId,
                shipment_id: data.shipmentId
            });

            run(url, "POST"
            );
        })();
    });

    panel.find(".remove-package").on("click", async function (e) {
        e.preventDefault();
        disable();

        const data = get_data(this);
        const url = makeJoomlaUrl("shipment.remove_package", {
            order_id: data.orderId,
            shipment_id: data.shipmentId
        });

        run(url, "DELETE");

    });

    const renderShipment = (shipment) => {
        // @ts-ignore
        const PPLczPlugin = window.PPLczPlugin = window.PPLczPlugin || [];
        //pplPlugin.push(["wpUpdateStyle", `ppl-order-panel-shipment-div-${orderId}-overlay`]);
        let unmount = null;
        const item = jQuery("<div>").prependTo("body")[0];
        PPLczPlugin.push(["newShipment", item, {
            "shipment": shipment,
            "returnFunc": function (data) {
                unmount = data.unmount;
            },
            "onChange": function () {
                refresh().catch(err => {
                });
            },
            "onFinish": function () {
                refresh().then(() => {
                    unmount();
                });
            }
        }]);
    }

    panel.find(".create-labels").on("click", function (e) {
        disable();
        const data = get_data(this);
        const PPLczPlugin = window.PPLczPlugin = window.PPLczPlugin || [];
        let unmount = null;
        const item = jQuery("<div>").prependTo("body")[0];


        PPLczPlugin.push(["newLabel", item, {
            "hideOrderAnchor": false,
            "shipment": data.shipment,
            "returnFunc": function (data) {
                unmount = data.unmount;
            },
            "onFinish": function () {
                refresh().then(() => {
                    unmount();
                })
            }
        }]);
    });

    panel.find(".create-labels-add").on("click", function (e) {
        e.preventDefault();
        disable();
        const data = get_data(this);
        const PPLczPlugin = window.PPLczPlugin = window.PPLczPlugin || [];
        let unmount = null;
        const item = jQuery("<div>").prependTo("body")[0];

        PPLczPlugin.push(["selectBatch", item, {
            "items": {
                "items": [{
                    "orderId": data.orderId,
                    "shipmentId": data.shipmentId
                }]
            },
            "onClose": function () {
                refresh().then(() => {
                    unmount();
                }).catch(err => {
                    enable();
                });
            },
            "returnFunc": function (returnData) {
                unmount = returnData.unmount;
            }
        }]);
    });

    jQuery(this).find(".refresh-shipments-labels").on("click", function (e) {
        disable();
        const data = get_data(this);
        run(makeUrl("shipment", `/${data.shipmentId}/refreshLabels`), "PUT");
    });

    jQuery(this).find(".refresh-shipments-states").on("click", function (e) {
        disable();
        const data = get_data(this);
        run(makeUrl("shipment", `/${data.shipmentId}/refreshStates`), "PUT");
    });

    // Handler pro refresh-shipments (Aktualizovat stav zásilky)
    // Volá komplexní refresh všech balíků v zásilce
    panel.find(".refresh-shipments").on("click", function (e) {
        e.preventDefault();
        disable();
        const data = get_data(this);
        const url = makeJoomlaUrl("shipment.test_labels", {
            shipment_id: data.shipmentId
        });
        run(url, "POST");
    });


    setTimeout(function () {
        var refresh = panel.find(`.refresh-shipments-labels`);
        if (refresh.length) {
            refresh.prop("disabled", false).click();
        }
    }, 5000);


    panel.find(".remove-shipment").on("click", async function (e) {
        disable();

        const data = get_data(this);
        const url = makeJoomlaUrl("shipment.remove_shipment", {
            order_id: data.orderId,
            shipment_id: data.shipmentId
        });
        run(url, "DELETE");
    });

    panel.find(".detail-shipment").on("click", function (e) {
        e.preventDefault();
        disable();

        const data = get_data(this);
        // Nemělo by být data.shipment? Podmínka je nastavena na data.shipmentId
        if (data.shipmentId) {
            renderShipment(data.shipment);
        } else {
            const url = makeJoomlaUrl("shipment.create_shipment", { order_id: data.orderId });

            fetch(url, {method: "POST"}).then(x => {
                if (x.status === 201) {
                    const shipment_id = x.headers.get("x-entity-id");

                    const url = makeJoomlaUrl("shipment.get_shipment", { shipment_id: shipment_id });

                    fetch(url).then(x => x.json()).then(y => {
                        enable();
                        renderShipment(y);
                    });
                } else {
                    enable();
                }
            })

        }
    })

}

pplczAdminOrder();