<?php
namespace PPLCZ\Admin\RestResponse;

use PPLCZ\Admin\Errors;
defined("_JEXEC") or die();


class RestResponse400  {

    private $errors;
    private $status = 400;
    private $error_data;

    public function __construct(Errors $errors, $status = 400, $headers = array())
    {
        $this->errors = $errors;
        $this->status = $status;
    }

    public function send()
    {
        http_response_code($this->status);

        $response = [
            'data' => [
                "code" => "element.error.dataerror.validation",
                'errors' => $this->errors->getErrors(),
                "errors_data" => $this->error_data,
            ]
        ];

        header('Content-Type: application/json');
        echo json_encode($response);
    }

    public function __toString()
    {
        ob_start();
        $this->send();
        return ob_get_clean();
    }
}