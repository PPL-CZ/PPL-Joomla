<?php

namespace PPLCZ\Setting;

use Joomla\CMS\Factory;
use PPLCZ\Model\Model\GlobalSettingMapModel;
use PPLCZ\Model\Model\GlobalSettingModel;
use PPLCZ\Model\Model\ParcelPlacesModel;
use PPLCZ\Model\Model\ShipmentMethodModel;

class MethodSetting
{
    public static function getGlobalSetting()
    {
        $globalSetting = new GlobalSettingModel();

        $apikeyKey = pplcz_create_name("map_api_key");
        $usenewmapKey = pplcz_create_name("use_new_map");

        $globalSettingMapModel = new GlobalSettingMapModel();
        $globalSettingMapModel->setApikey(pplcz_get_option($apikeyKey) ?: null);
        $globalSettingMapModel->setEnabled(pplcz_get_option($usenewmapKey) === 'yes');
        $globalSetting->setMap($globalSettingMapModel);

        return $globalSetting;
    }

    public static function setGlobalSetting(GlobalSettingModel $globalSettingModel)
    {
        $apikeyKey = pplcz_create_name("map_api_key");
        $usenewmapKey = pplcz_create_name("use_new_map");

        $map = $globalSettingModel->getMap();
        if ($map) {
            $apikey = $map->getApikey();
            $enabled = $apikey ? 'yes' : 'no';

            pplcz_set_option($usenewmapKey, $enabled);
            pplcz_set_option($apikeyKey, $apikey ?: '');
        }
    }

    public static function getGlobalParcelboxesSetting()
    {
        $parcelPlaces = new ParcelPlacesModel();

        $disabledParcelBox = !!(pplcz_get_option(pplcz_create_name("disabled_parcelbox")));
        $disabledParcelShop = !!(pplcz_get_option(pplcz_create_name("disabled_parcelshop")));
        $disabledAlzaBox = !!(pplcz_get_option(pplcz_create_name("disabled_alzabox")));

        $disabledCountriesFromBaseSetting = pplcz_get_option(pplcz_create_name("disabled_parcel_countries"));

        if (!is_array($disabledCountriesFromBaseSetting))
            $disabledCountriesFromBaseSetting = [];

        $languageMap = pplcz_get_option(pplcz_create_name("map_language"));

        $parcelPlaces->setDisabledCountries($disabledCountriesFromBaseSetting);
        $parcelPlaces->setMapLanguage($languageMap);
        $parcelPlaces->setDisabledParcelBox($disabledParcelBox);
        $parcelPlaces->setDisabledParcelShop($disabledParcelShop);
        $parcelPlaces->setDisabledAlzaBox($disabledAlzaBox);

        return $parcelPlaces;
    }

    public static function setGlobalParcelboxesSetting(ParcelPlacesModel $setting)
    {
        $parcelbox = pplcz_create_name("disabled_parcelbox");
        $parcelshop = pplcz_create_name("disabled_parcelshop");
        $alzabox = pplcz_create_name("disabled_alzabox");
        $disabledCountries = pplcz_create_name("disabled_parcel_countries");
        $languageMap = pplcz_create_name("map_language");

        pplcz_set_option($parcelbox, $setting->getDisabledParcelBox());
        pplcz_set_option($parcelshop, $setting->getDisabledParcelShop());
        pplcz_set_option($alzabox, $setting->getDisabledAlzaBox());
        pplcz_set_option($disabledCountries, $setting->getDisabledCountries());
        pplcz_set_option($languageMap, $setting->getMapLanguage());

    }

    public static function getCodMethods($code)
    {
        $methods = [
            "PRIV" => "PRID",
            "CONN" => "COND",
            "SMAR" => "SMAD",
            "SMEU" => "SMED",
            "SBOX" => "SBOD"
        ];
        if (isset($methods[$code]))
            return $methods[$code];
        return null;
    }

    public static function getMethod($code)
    {
        foreach (static::getMethods() as $method)
        {
            if ($method->getCode() === $code)
                return $method;
        }
        return null;
    }

    private static $_methods = null;

    /**
     * @return ShipmentMethodModel[]
     */
    public static function getMethods()
    {
        if (self::$_methods !== null) return self::$_methods;

        $output = [];

        $description = [
            "PRID" => "Doprava v rámci České republiky na adresu",
            "SMAD" => "Doprava v rámci České republiky na výdejní místo",
            "SBOD" => "Doprava v rámci České republiky pouze do ParcelBoxu (váha omezena do 10 kg a rozměry max 50×40×38cm)",
            "SMED" => "Doprava v rámci Polska, Německa, Slovenska na výdejní místo",
            "COND" => "Doprava v rámci EU na adresu",
            "COPD" => "Doprava mimo EU v rámci Evropy",
        ];



        $methods = [
            "PRIV"=> "PPL Parcel CZ Private", // cz
            "SMAR" => "PPL Parcel CZ Smart", // cz, VM

            "SMEU" => "PPL Parcel Smart Europe", // necz
            "CONN" => "PPL Parcel Connect", // necz,

            "COPL" => "PPL Parcel Connect Plus",

            "SBOX" => "PPL Parcel CZ Smart To Box"
        ];

        foreach ($methods as $key => $value) {
            $method = new ShipmentMethodModel();

            $method->setCode($key);
            $method->setTitle($value);
            $method->setDescription($description[substr($key, 0, 3) . 'D']);
            $method->setCodAvailable(false);
            $method->setParcelRequired(in_array($key, ["SMAR", "SMEU", "SBOX"], true));
            $method->setAgeValidation(null);

            if (in_array($key, ["SMAR", "PRIV"], true)) {
                $method->setAgeValidation(true);
            } else if ($key === "SBOX") {
                $method->setAgeValidation(false);
                $method->setMaxWeight(10);
                $method->setMaxDimension([50, 40, 38 ]);
            } else if (in_array($key, ["SMEU", "CONN"], true)) {
                $method->setMaxPackages(1);
            }

            if($method->getParcelRequired())
            {
                $method->setDisabledParcelTypes([]);
                $method->setAvailableParcelTypes(["ParcelBox", "ParcelShop", "AlzaBox"]);

                if ($method->getCode() === "SBOX") {
                    $method->setDisabledParcelTypes([ "AlzaBox", "ParcelShop"]);
                    $method->setAvailableParcelTypes(["ParcelBox"]);
                    $method->setMaxPackages(1);
                }
            }
            $output[] = $method;
        }

        $codMethods = [
            "PRID"=> "PPL Parcel CZ Private - dobírka", // cz
            "SMAD" => "PPL Parcel CZ Smart - dobírka", // cz, VM
            "SMED" => "PPL Parcel Smart Europe - dobírka", // necz
            "COND" => "PPL Parcel Connect - dobírka", // necz,
            "SBOD" => "PPL Parcel CZ Smart To Box - dobírka"
        ];

        foreach ($codMethods as $key => $value) {
            $method = new ShipmentMethodModel();
            $method->setCode($key);
            $method->setTitle($value);
            $method->setCodAvailable(true);
            $method->setDescription($description[$key]);
            $method->setParcelRequired(in_array($key, ["SMAD", "SMED", "SBOD"], true));
            $method->setAgeValidation(null);

            if (in_array($key, ["SMAD", "PRID"], true)) {
                $method->setAgeValidation(true);
            } else if ($key === "SBOD") {
                $method->setAgeValidation(false);
                $method->setMaxWeight(10);
                $method->setMaxDimension([50, 40, 38 ]);
                $method->setMaxPackages(1);
            }else if (in_array($key, ["SMED", "COND"], true)) {
                $method->setMaxPackages(1);
            }

            if($method->getParcelRequired())
            {
                $method->setAvailableParcelTypes(["ParcelBox", "ParcelShop", "AlzaBox"]);
                $method->setDisabledParcelTypes([]);
                if ($method->getCode() === "SBOD") {
                    $method->setAvailableParcelTypes(["ParcelBox"]);
                    $method->setDisabledParcelTypes([ "AlzaBox", "ParcelShop"]);
                }
            }

            $output[] = $method;
        }

        foreach ($output as $value)
        {
            $code = $value->getCode();
            $countries = [];
            if (in_array($code, ['SMAR',"SMAD", 'PRIV', 'PRID', "SBOX", "SBOD" ]))
                $countries = ["CZ"];
            else if (in_array($code,['SMEU',"SMED", 'CONN', 'COND']))
                $countries = self::getEuCountries();
            else {
                $countries = require __DIR__ . '/../config/countries.php';
                $countries = array_diff(array_keys($countries), self::getEuCountries());
            }
            $value->setCountries($countries);
        }

        return self::$_methods = $output;
    }

    public static function getEuCountries()
    {
        return [
            'AT', // Rakousko
            'BE', // Belgie
            'BG', // Bulharsko
            'HR', // Chorvatsko
            'CY', // Kypr
            'DK', // Dánsko
            'EE', // Estonsko
            'FI', // Finsko
            'FR', // Francie
            'DE', // Německo
            'GR', // Řecko
            'HU', // Maďarsko
            'IE', // Irsko
            'IT', // Itálie
            'LV', // Lotyšsko
            'LT', // Litva
            'LU', // Lucembursko
            'MT', // Malta
            'NL', // Nizozemsko
            'PL', // Polsko
            'PT', // Portugalsko
            'RO', // Rumunsko
            'SK', // Slovensko
            'SI', // Slovinsko
            'ES', // Španělsko
            'SE', // Švédsko
        ];
    }

    public static function getMethodForCountry($country, $method)
    {

        $countries = require __DIR__ . '/../config/countries.php';
        if (!isset($countries[$country]))
            return $method;

        if ($country === 'CZ') {
            $codes = [
                'PRIV' => 'PRIV', 'PRID' => "PRID", 'SMAR' => 'SMAR', 'SMAD' => 'SMAD',
                'SMEU' => "SMAR", "SMED" => "SMAD", "CONN" => "PRIV", 'COND' => "PRID",
                "COPL" => "PRIV", "SBOX" => "SBOX", "SBOD" => "SBOD"
            ];
            if (isset($codes[$method]))
                return $codes[$method];
            else return $method;

        } else {
            if (in_array($country, self::getEuCountries(), true)) {
                $codes = [
                    "COPL" => "CONN",
                    'PRIV' => 'CONN', 'PRID' => "COND", 'SMAR' => 'SMEU', 'SMAD' => 'SMED',
                    'SMEU' => "SMEU", "SMED" => "SMED", "CONN" => "CONN", 'COND' => "COND",
                ];

                if (isset($codes[$method]))
                    return $codes[$method];
                else return $method;

            } else {
                if (in_array($method, ['COPL', "PRIV", "CONN"], true))
                    return "COPL";
                return null;
            }
        }
    }

    public
    static function isCOD($shipmentCode, $paymentCode)
    {
        $db = Factory::getDbo();
        $query = $db->getQuery(true)
            ->select('params')
            ->from($db->quoteName('#__pplcz_shipment_method'))
            ->where($db->quoteName('virtuemart_shipmentmethod_id') . ' = ' . $shipmentCode);

        $db->setQuery($query);
        $cod = $db->loadResult();
        $cod = json_decode($cod);


        return (int)$cod->codPayment === $paymentCode;
    }

    public
    static function parcelMethods()
    {
        return [
            "SMAR", "SMEU", "SMAD", "SMED", "SBOX", "SBOD"
        ];
    }




}