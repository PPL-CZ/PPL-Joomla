<?php
namespace PPLCZ\Setting;

use PPLCZ\Model\Model\SyncPhasesModel;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Table\Table;

class PhaseSetting
{
    public static function setPhase($key, $watch, $orderState)
    {
        $params = ComponentHelper::getParams('com_pplcz');

        if ($watch || $orderState) {
            $params->set(pplcz_create_name("watch_phases_{$key}"), !!$watch);
            $params->set(pplcz_create_name("watch_phases_{$key}_orderState"), $orderState);
        }
        else {
            $params->remove(pplcz_create_name("watch_phases_{$key}"));
            $params->remove(pplcz_create_name("watch_phases_{$key}_orderState"));
        }

        $table = Table::getInstance('extension');
        $table->load(['element' => 'com_pplcz']);
        $table->params = $params->toString();
        $table->store();
    }

    public static function setMaxSync($value)
    {
        $params = ComponentHelper::getParams('com_pplcz');
        $params->set(pplcz_create_name("watch_phases_max_sync"), intval($value) ?: 200);

        $table = Table::getInstance('extension');
        $table->load(['element' => 'com_pplcz']);
        $table->params = $params->toString();
        $table->store();
    }


    public static function getPhases()
    {
        $phases = include __DIR__ . '/../config/shipment_phases.php';
        unset($phases['Deleted']);

        $phases = array_map(function ($item, $key) {
            $params = ComponentHelper::getParams('com_pplcz');
            $output = new \PPLCZ\Model\Model\ShipmentPhaseModel();
            $output->setCode($key);
            $output->setTitle($item);
            $output->setWatch(!!$params->get(pplcz_create_name("watch_phases_{$key}")));
            $output->setOrderState($params->get(pplcz_create_name("watch_phases_{$key}_orderState")) ?: null);
            return $output;
        }, $phases, array_keys($phases));

        $params = ComponentHelper::getParams('com_pplcz');
        $maxSync = $params->get(pplcz_create_name("watch_phases_max_sync"));
        $maxSync = intval($maxSync) ?: 200;

        $sync = new SyncPhasesModel();

        $sync->setPhases($phases);
        $sync->setMaxSync($maxSync);

        return $sync;
    }
}