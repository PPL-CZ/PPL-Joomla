<?php
namespace PPLCZ\Setting;

use PPLCZ\Model\Model\SyncPhasesModel;

class PhaseSetting
{
    public static function setPhase($key, $watch, $orderState)
    {
        if ($watch || $orderState) {
            pplcz_set_option(pplcz_create_name("watch_phases_{$key}"), !!$watch);
            pplcz_set_option(pplcz_create_name("watch_phases_{$key}_orderState"), $orderState);
        }
        else {
            pplcz_delete_option(pplcz_create_name("watch_phases_{$key}"));
            pplcz_delete_option(pplcz_create_name("watch_phases_{$key}_orderState"));
        }
    }

    public static function setMaxSync($value)
    {
        pplcz_set_option(pplcz_create_name("watch_phases_max_sync"), intval($value) ?: 200);
    }


    public static function getPhases()
    {
        $phases = include __DIR__ . '/../config/shipment_phases.php';
        unset($phases['Deleted']);

        $phases = array_map(function ($item, $key) {
            $output = new \PPLCZ\Model\Model\ShipmentPhaseModel();
            $output->setCode($key);
            $output->setTitle($item);
            $output->setWatch(!!pplcz_get_option(pplcz_create_name("watch_phases_{$key}")));
            $output->setOrderState(pplcz_get_option(pplcz_create_name("watch_phases_{$key}_orderState")) ?: null);
            return $output;
        }, $phases, array_keys($phases));

        $maxSync = pplcz_get_option(pplcz_create_name("watch_phases_max_sync"));
        $maxSync = intval($maxSync) ?: 200;

        $sync = new SyncPhasesModel();

        $sync->setPhases($phases);
        $sync->setMaxSync($maxSync);

        return $sync;
    }
}
