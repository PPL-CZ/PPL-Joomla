<?php
namespace PPLCZ\Setting;

use PPLCZ\Model\Model\CountryModel;

class CountrySetting {

    /**
     * @return CountryModel[]
     */
    public static function getCountries()
    {
        $allowedCountries = pplcz_get_allowed_countries();
        $currencies = pplcz_get_cod_currencies();
        $parcelAllowed = pplcz_get_parcel_countries();

        return array_map(function ($country) use ($currencies, $parcelAllowed) {
            $countryModel = new CountryModel();
            $countryCode = $country->country_2_code;
            $countryModel->setCode($countryCode);
            $countryModel->setTitle($country->country_name);
            $countryModel->setParcelAllowed(in_array($countryCode, $parcelAllowed));

            $countryModel->setCodAllowed(array_unique(array_map(function ($item) {
                return $item['currency'];
            }, array_filter($currencies, function ($item) use ($countryCode) {
                return $item['country'] === $countryCode;
            }))));

            return $countryModel;

        }, $allowedCountries);

    }
}