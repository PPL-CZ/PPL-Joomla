<?php
namespace PPLCZ\Setting;

use PPLCZ\Model\Model\MyApi2;

class ApiSetting
{
    public static function getApi()
    {
        $apiKey = pplcz_get_option(pplcz_create_name("client_id"));
        // setApi() zapisuje vždy do "secret" — ten tedy musí mít přednost.
        // "client_secret" zůstává jen jako fallback pro ručně upravené instalace;
        // při opačném pořadí by přebíjel právě uloženou hodnotu.
        $apiSecret = pplcz_get_option(pplcz_create_name("secret")) ?: pplcz_get_option(pplcz_create_name("client_secret"));

        $myapi2 = new MyApi2();
        $myapi2->setClientId($apiKey ?: "");
        $myapi2->setClientSecret($apiSecret ?: "");

        return $myapi2;
    }

    public static function setApi(MyApi2  $myapi2)
    {
        pplcz_set_option(pplcz_create_name("client_id"), $myapi2->getClientId());
        pplcz_set_option(pplcz_create_name("secret"), $myapi2->getClientSecret());
    }
}
