<?php
namespace PPLCZ\Setting;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Table\Table;
use PPLCZ\Model\Model\MyApi2;

class ApiSetting
{
    public static function getApi()
    {
        $table = Table::getInstance('extension');
        $table->load(['element' => 'com_pplcz', 'type' => 'component']);
        $params = new \Joomla\Registry\Registry($table->params);

        $apiKey = $params->get(pplcz_create_name("client_id"));
        // Handle both "client_secret" (new) and "secret" (old) parameter names for backward compatibility
        $apiSecret = $params->get(pplcz_create_name("client_secret")) ?: $params->get(pplcz_create_name("secret"));

        $myapi2 = new MyApi2();
        $myapi2->setClientId($apiKey ?: "");
        $myapi2->setClientSecret($apiSecret ?: "");

        return $myapi2;
    }

    public static function setApi(MyApi2  $myapi2)
    {
        // Load params directly from database to avoid saving cache values
        $table = Table::getInstance('extension');
        $table->load(['element' => 'com_pplcz', 'type' => 'component']);

        $params = new \Joomla\Registry\Registry($table->params);
        $params->set(pplcz_create_name("client_id"), $myapi2->getClientId());
        $params->set(pplcz_create_name("secret"), $myapi2->getClientSecret());

        $table->params = $params->toString();
        $table->store();
    }
}