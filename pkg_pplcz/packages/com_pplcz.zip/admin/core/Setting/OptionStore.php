<?php

namespace PPLCZ\Setting;

defined("_JEXEC") or die();

use Joomla\CMS\Factory;

/**
 * Úložiště nastavení komponenty — obdoba get_option()/update_option()
 * z WooCommerce verze.
 *
 * Data leží ve vlastní tabulce `#__pplcz_setting`, ne v `#__extensions`.`params`:
 * ten řádek Joomla při odinstalaci komponenty maže, takže nastavení uložené
 * v params nepřežije přeinstalaci — a s ním mizí i vazba na adresu odesílatele
 * a přihlašovací údaje. Uživatelská data se přitom mazat nesmí.
 *
 * Hodnoty se ukládají jako JSON, aby se zachoval typ (pole, bool, int).
 */
class OptionStore
{
    /**
     * Cache v rámci requestu. Klíč => dekódovaná hodnota.
     *
     * @var array
     */
    private static $cache = [];

    public static function get($name, $default = null)
    {
        if (array_key_exists($name, self::$cache)) {
            $value = self::$cache[$name];

            return $value === null ? $default : $value;
        }

        try {
            $db = Factory::getContainer()->get('DatabaseDriver');
            $query = $db->getQuery(true)
                ->select($db->quoteName('value'))
                ->from($db->quoteName('#__pplcz_setting'))
                ->where($db->quoteName('name') . ' = :name')
                ->bind(':name', $name);

            $raw = $db->setQuery($query)->loadResult();
        } catch (\Exception $e) {
            // Tabulka ještě neexistuje (probíhá instalace nebo upgrade)
            // — chovej se, jako by nastavení nebylo vyplněné.
            return $default;
        }

        $value = $raw === null ? null : json_decode($raw, true);
        self::$cache[$name] = $value;

        return $value === null ? $default : $value;
    }

    public static function set($name, $value)
    {
        try {
            $db = Factory::getContainer()->get('DatabaseDriver');

            // Upsert po jednotlivých klíčích: na rozdíl od params, kde se
            // přepisoval celý blob, se souběžné zápisy různých nastavení
            // navzájem neruší.
            $sql = 'INSERT INTO ' . $db->quoteName('#__pplcz_setting')
                . ' (' . $db->quoteName('name') . ', ' . $db->quoteName('value') . ')'
                . ' VALUES (' . $db->quote($name) . ', ' . $db->quote(json_encode($value)) . ')'
                . ' ON DUPLICATE KEY UPDATE ' . $db->quoteName('value')
                . ' = VALUES(' . $db->quoteName('value') . ')';

            $db->setQuery($sql)->execute();
        } catch (\Exception $e) {
            error_log("PPL-CZ: nepodařilo se uložit nastavení '$name': " . $e->getMessage());

            return false;
        }

        self::$cache[$name] = $value;

        return true;
    }

    public static function delete($name)
    {
        try {
            $db = Factory::getContainer()->get('DatabaseDriver');
            $query = $db->getQuery(true)
                ->delete($db->quoteName('#__pplcz_setting'))
                ->where($db->quoteName('name') . ' = :name')
                ->bind(':name', $name);

            $db->setQuery($query)->execute();
        } catch (\Exception $e) {
            return false;
        }

        unset(self::$cache[$name]);

        return true;
    }

    public static function exists($name)
    {
        return self::get($name, null) !== null;
    }
}
