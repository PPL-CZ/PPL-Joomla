<?php

use Joomla\CMS\Plugin\PluginHelper;
use PPLCZ\Model\Model\CartModel;
use PPLCZ\Serializer;
use PPLCZ\Model\Model\ParcelDataModel;
use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Date\Date;

defined("_JEXEC") or die();

function pplcz_create_name($name)
{
    return "pplcz_" . $name;
}

function sanitize_key($key)
{
    $key = strtolower($key);
    return preg_replace('/[^a-z0-9_\-]/', '', $key);
}

function pplcz_map_args()
{
    return PPLCZ\Component\Ppladmin\Administrator\Front\Components\Map\Map::args();
}

function pplcz_asset_icon($name)
{
    return Uri::root() . ("administrator/components/com_pplcz/core/Admin/Assets/Images/$name");
}

/**
 * Nastavení komponenty — tenké obálky nad PPLCZ\Setting\OptionStore.
 *
 * Volající kód drží stejný tvar jako WooCommerce verze (get_option/update_option);
 * úložištěm je tabulka `#__pplcz_setting`, ne `#__extensions`.`params`, aby
 * nastavení přežilo odinstalaci a přeinstalaci komponenty.
 */
function pplcz_get_option($name, $default = null)
{
    return \PPLCZ\Setting\OptionStore::get($name, $default);
}

function pplcz_set_option($name, $value)
{
    return \PPLCZ\Setting\OptionStore::set($name, $value);
}

function pplcz_delete_option($name)
{
    return \PPLCZ\Setting\OptionStore::delete($name);
}

function pplcz_set_shipment_print($shipmentId, $print)
{
    pplcz_set_option(pplcz_create_name("print_shipment_{$shipmentId}"), $print);
}

function pplcz_get_shipment_print($shipmentId)
{
    return pplcz_get_option(pplcz_create_name("print_shipment_{$shipmentId}"));
}

function pplcz_set_batch_print($batchId, $print)
{
    pplcz_set_option(pplcz_create_name("print_batch_{$batchId}"), $print);
}

function pplcz_get_batch_print($batchId)
{
    return pplcz_get_option(pplcz_create_name("print_batch_{$batchId}"));
}

function pplcz_get_download_pdf($download, $reference = null, $print = null)
{
    // Generate URL for FileController::download() in Joomla
    $url = \Joomla\CMS\Uri\Uri::base() . 'index.php';
    $params = [
        'option' => 'com_pplcz',
        'task' => 'file.download',
        'format' => 'raw',
        'pplcz_download' => $download
    ];

    if ($reference !== null) {
        $params['pplcz_reference'] = $reference;
    }

    if ($print !== null) {
        $params['pplcz_print'] = $print;
    }

    return $url . '?' . http_build_query($params);
}

function pplcz_normalize($value)
{
    return Serializer::getInstance()->normalize($value);
}

function pplcz_denormalize($value, $type, $context = [])
{
    return Serializer::getInstance()->denormalize($value, $type, null, $context);
}

function pplcz_validate($model, $errors = null, $path = "")
{
    if (!$errors)
        $errors = new \PPLCZ\Admin\Errors();
    \PPLCZ\Validator\Validator::getInstance()->validate($model, $errors, $path);
    return $errors;
}

function pplcz_get_parcel_countries()
{
    $countryModel = VmModel::getModel('country');
    $get_countries = $countryModel->getCountries(true);

    foreach ($get_countries as $key => $country) {
        if (!in_array($country->country_2_code, ['CZ', 'SK', 'PL', 'DE', 'NL', 'RO', 'BG', 'HU', 'AT']))
            unset($get_countries[$key]);
    }
    $get_countries = array_map(function ($country) {
        return $country->country_2_code;
    }, $get_countries);
    return $get_countries;
}

function pplcz_get_allowed_countries()
{
    $countryModel = VmModel::getModel('country');
    $get_countries = $countryModel->getCountries(true);

    $countries = include __DIR__ . '/config/countries.php';
    foreach ($get_countries as $key => $v) {
        if (!isset($countries[$v->country_2_code]))
            unset($get_countries[$key]);
    }

    return $get_countries;
}

function pplcz_get_cod_currencies()
{
    $currencies = include __DIR__ . '/config/cod_currencies.php';
    return $currencies;
}

/**
 * @return ParcelDataModel|null
 */
function pplcz_get_cart_parceldata()
{
    $rate = pplcz_get_cart_shipping_method();
    if (!$rate)
        return null;

    /**
     * @var CartModel $metadata
     */

    $metadata = Serializer::getInstance()->denormalize($rate, CartModel::class);
    if ($metadata->getParcelRequired()) {

        $app = Factory::getApplication();
        $session = $app->getSession();

        $parcelshop_data = $session->get(pplcz_create_name('parcelshop_data'));

        if ($parcelshop_data) {
            return Serializer::getInstance()->denormalize($parcelshop_data, ParcelDataModel::class);
        }
    }
    return null;
}

/**
 * Get all available order statuses from VirtueMart
 * Returns associative array with status code as key and status name as value
 * Compatible with WooCommerce wc_get_order_statuses() format
 *
 * @return array Array of order statuses ['code' => 'name']
 */
function pplcz_get_order_statuses() {
    $db = Factory::getContainer()->get('DatabaseDriver');
    $query = $db->getQuery(true)
        ->select([
            $db->quoteName('order_status_code'),
            $db->quoteName('order_status_name')
        ])
        ->from($db->quoteName('#__virtuemart_orderstates'))
        ->order($db->quoteName('ordering') . ' ASC');

    $db->setQuery($query);
    $states = $db->loadObjectList();

    // Convert to associative array compatible with WooCommerce format
    $result = [];
    if ($states) {
        foreach ($states as $state) {
            // Use order_status_code as key (similar to WooCommerce 'wc-processing')
            $result[$state->order_status_code] = $state->order_status_name;
        }
    }

    return $result;
}

/**
 * Get order status for specific order by ID
 *
 * @param int $id Order ID
 * @return string|null Order status code
 */
function pplcz_get_order_status($id) {
    $db = Factory::getContainer()->get('DatabaseDriver');
    $query = $db->getQuery(true)
        ->select($db->quoteName('order_status'))
        ->from($db->quoteName('#__virtuemart_orders'))
        ->where($db->quoteName('virtuemart_order_id') . ' = ' . (int)$id);

    $db->setQuery($query);
    $result = $db->loadResult();

    return $result;
}

/**
 * Update VirtueMart order status
 *
 * @param int $orderId VirtueMart order ID (virtuemart_order_id)
 * @param string $status Order status code
 * @return bool Success
 */
function pplcz_update_order_status($orderId, $status) {
    if (empty($orderId) || empty($status)) {
        return false;
    }

    try {
        $orderModel = \VmModel::getModel('orders');
        return $orderModel->updateStatusForOneOrder($orderId, ['order_status' => $status]);
    } catch (\Exception $e) {
        error_log("PPL-CZ: Failed to update order status for order #{$orderId}: " . $e->getMessage());
        return false;
    }
}

/**
 * Mark VirtueMart order as paid (set paid amount = order total)
 *
 * @param int $orderId VirtueMart order ID (virtuemart_order_id)
 * @return bool Success
 */
function pplcz_mark_order_paid($orderId) {
    if (empty($orderId)) {
        return false;
    }

    try {
        $db = Factory::getContainer()->get('DatabaseDriver');

        // Get order total
        $query = $db->getQuery(true)
            ->select($db->quoteName(['order_total', 'paid']))
            ->from($db->quoteName('#__virtuemart_orders'))
            ->where($db->quoteName('virtuemart_order_id') . ' = ' . (int)$orderId);

        $db->setQuery($query);
        $order = $db->loadObject();

        if (!$order) {
            return false;
        }

        // Only set paid if not already paid
        if (empty($order->paid) || $order->paid == 0) {
            $date = Factory::getDate();
            $today = $date->toSQL();

            // Update paid amount and paid_on date
            $query = $db->getQuery(true)
                ->update($db->quoteName('#__virtuemart_orders'))
                ->set($db->quoteName('paid') . ' = ' . (float)$order->order_total)
                ->set($db->quoteName('paid_on') . ' = ' . $db->quote($today))
                ->where($db->quoteName('virtuemart_order_id') . ' = ' . (int)$orderId);

            $db->setQuery($query);
            return $db->execute();
        }

        return true; // Already paid

    } catch (\Exception $e) {
        error_log("PPL-CZ: Failed to mark order as paid for order #{$orderId}: " . $e->getMessage());
        return false;
    }
}

/**
 * Get order meta data (stored in component params)
 * Used for tracking which phase triggered the last status change
 *
 * @param int $orderId Order ID
 * @param string $key Meta key
 * @return mixed Meta value or null if not found
 */
function pplcz_get_order_meta($orderId, $key) {
    return pplcz_get_option(pplcz_create_name("order_{$orderId}_{$key}"));
}

/**
 * Set order meta data (store in component params)
 * Used for tracking which phase triggered the last status change
 *
 * @param int $orderId Order ID
 * @param string $key Meta key
 * @param mixed $value Meta value
 * @return bool Success
 */
function pplcz_set_order_meta($orderId, $key, $value) {
    try {
        pplcz_set_option(pplcz_create_name("order_{$orderId}_{$key}"), $value);
    } catch (\Exception $e) {
        error_log("PPL-CZ: Failed to set order meta for order #{$orderId}: " . $e->getMessage());
        return false;
    }
}

function pplcz_set_cart_parceldata()
{
    require_once JPATH_ADMINISTRATOR . '/components/com_virtuemart/helpers/config.php';
    VmConfig::loadConfig(false, false, true);

    require_once JPATH_SITE . '/components/com_virtuemart/helpers/cart.php';
    PluginHelper::importPlugin('vmshipment');

    $app = Factory::getApplication();
    $input = $app->getInput();
    $json = $input->getString('parcelshop', '{}');
    $decoded = json_decode($json, true);

    $session = Factory::getApplication()->getSession();

    if ($decoded) {
        $session->set(pplcz_create_name("parcelshop_data"), Serializer::getInstance()->normalize($decoded));
    } else {
        $session->set(pplcz_create_name("parcelshop_data"), null);
    }

    echo new \Joomla\CMS\Response\JsonResponse([
        'success' => true,
        'saved' => $decoded,
    ]);

}

/**
 * @return \WC_Shipping_Rate|null
 */
function pplcz_get_cart_shipping_method()
{
    $cart = VirtueMartCart::getCart();

    return VmModel::getModel('shipmentmethod')->getShipment($cart->virtuemart_shipmentmethod_id);
}

function pplcz_get_update_setting()
{
    return pplcz_get_option(pplcz_create_name("update_setting")) ?: '';
}

function pplcz_set_update_setting()
{
    pplcz_set_option(pplcz_create_name("update_setting"), "" . time());
}

function pplcz_simple_guid()
{
    $site_url = Uri::base();
    $timestamp = time();

    $raw_string = $site_url . '-' . $timestamp;

    $hash = hash('sha256', $raw_string);
    $time = (new \Joomla\CMS\Date\Date())->format("YmdHis");
    $guid = sprintf('%s-%08s-%04s-%04s-%04s-%12s',
        substr($time, 2),
        substr($hash, 0, 8),
        substr($hash, 8, 4),
        substr($hash, 12, 4),
        substr($hash, 16, 4),
        substr($hash, 20, 12)
    );

    return $guid;
}


