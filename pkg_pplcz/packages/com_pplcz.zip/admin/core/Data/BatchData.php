<?php

namespace PPLCZ\Data;
defined('_JEXEC') or die();


use Joomla\CMS\Factory;
use Joomla\CMS\Table\Table;
use Joomla\Database\DatabaseDriver;
use Joomla\Event\DispatcherInterface;

class BatchData extends Table
{
    public $ppl_batch_id;
    public $name = null;
    public $remote_batch_id = null;
    public $lock = 0;
    public $created_at = null;

    protected $ignore_lock = false;

    public function ignore_lock()
    {
        $this->ignore_lock = true;
    }

    protected $hard_lock = false;

    public function hard_lock()
    {
        $this->hard_lock = true;
    }

    public function get_ignore_lock()
    {
        return $this->ignore_lock;
    }

    public function __construct(DatabaseDriver $db = null, ?DispatcherInterface $dispatcher = null)
    {
        $db = Factory::getContainer()->get('DatabaseDriver');
        parent::__construct('#__pplcz_batch', 'ppl_batch_id', $db, $dispatcher);
    }

    public function get_lock()
    {
        return $this->lock;
    }

    public function set_lock($value)
    {
        $this->lock = (int)(bool)$value;
    }

    public function get_id()
    {
        return $this->ppl_batch_id;
    }

    public function get_name()
    {
        return $this->name;
    }

    public function set_name($value)
    {
        $this->name = $value;
    }

    public function get_remote_batch_id()
    {
        return $this->remote_batch_id;
    }

    public function set_remote_batch_id($value)
    {
        $this->remote_batch_id = $value;
    }

    public function get_created_at()
    {
        return $this->created_at;
    }

    public function set_created_at($value)
    {
        $this->created_at = $value;
    }


    public static function get_batchs($free)
    {
// Opravit free
        $db = Factory::getContainer()->get('DatabaseDriver');

        if ($free) {
            $query = "select * from #__pplcz_batch where `lock` = 0 and ppl_batch_id  in (select batch_local_id from #__pplcz_shipment)  order by ppl_batch_id desc";
            $db->setQuery($query);
            $rows = $db->loadAssocList();
        } else {
            $query = "select * from #__pplcz_batch where ppl_batch_id  in (select batch_local_id from #__pplcz_shipment) and created_at > now() - INTERVAL 5 DAY  order by ppl_batch_id desc";
            $db->setQuery($query);
            $rows = $db->loadAssocList();

            if (count($rows) < 20) {
                $ids = array_map(function ($item) {
                    return $item['ppl_batch_id'];
                }, $rows);

                $query = "select * from #__pplcz_batch where ppl_batch_id  in (select batch_local_id from #__pplcz_shipment)  order by ppl_batch_id desc limit 20";
                $db->setQuery($query);
                $rows2 = $db->loadAssocList();

                foreach($rows2 as $row){
                    if (count($rows) < 20) {
                        if(!in_array($row['ppl_batch_id'], $ids, true)){
                            $rows[] = $row;
                        }
                    }
                }

            }
        }


        $output = [];

        foreach ($rows as $row) {
            $data = new BatchData();
            $data->load($row["ppl_batch_id"]);
            $output[] = $data;
        }
        return $output;
    }

    public static function get_last_batch()
    {
        $db = Factory::getContainer()->get('DatabaseDriver');

        $query = "select * from #__pplcz_batch where `lock` = 0 order by ppl_batch_id desc limit 1";
        $db->setQuery($query);
        $rows = $db->loadAssocList();

        $output = [];

        foreach ($rows as $row) {
            $data = new BatchData();
            $data->load($row["ppl_batch_id"]);
            $output[] = $data;
        }
        return $output;
    }

}