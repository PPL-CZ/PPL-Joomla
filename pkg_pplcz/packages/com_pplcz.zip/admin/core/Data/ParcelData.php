<?php

namespace PPLCZ\Data;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Table\Table;
use Joomla\Database\DatabaseDriver;

class ParcelData extends Table
{
    public $ppl_parcel_id = null;
    public $name = null;
    public $name2 = null;
    public $street = null;
    public $city = null;
    public $zip = null;
    public $country = null;
    public $code = null;
    public $lat = null;
    public $lng = null;
    public $type = null;
    public $hidden = 0;
    public $valid = 0;
    public $lock = 0;
    public $draft = null;

    public function __construct(DatabaseDriver $db =  null)
    {
        $db = $db ?? Factory::getContainer()->get('DatabaseDriver');
        parent::__construct('#__pplcz_parcel', 'ppl_parcel_id', $db);
    }

    public function get_id(){
        return $this->ppl_parcel_id;
    }


    public function set_lat($value)
    {
        $this->lat = $value;
    }

    public function get_lat()
    {
        return $this->lat;
    }

    public function set_lng($value)
    {
        $this->lng = $value;
    }

    public function get_lng()
    {
        return $this->lng;
    }

    public function set_type($value){
        $this->type = $value;
    }

    public function get_type()
    {
        return $this->type;
    }

    public function set_code($value)
    {
        $this->code = $value;
    }

    public function get_code($context = 'view')
    {
        return $this->code;
    }

    // Getter and Setter for 'name'
    public function get_name($context = 'view')
    {
        return $this->name;
    }

    public function set_name($value)
    {
        $this->name = $value;
    }

    public function get_name2($context = 'view')
    {
        return $this->name2;
    }

    public function set_name2($value)
    {
        $this->name2 = $value;
    }


    // Getter and Setter for 'street'
    public function get_street($context = 'view')
    {
        return $this->street;
    }

    public function set_street($value)
    {
        $this->street = $value;
    }

    // Getter and Setter for 'city'
    public function get_city($context = 'view')
    {
        return $this->city;
    }

    public function set_city($value)
    {
        $this->city = $value;
    }

    // Getter and Setter for 'zip'
    public function get_zip($context = 'view')
    {
        return $this->zip;
    }

    public function set_zip($value)
    {
        $this->zip = $value;
    }

    public function get_country($context = 'view')
    {
        return $this->country;
    }

    public function set_country($value)
    {
        $this->country = $value;
    }

    public function set_valid($value)
    {
        $this->valid = (int)$value;
    }

    public function get_valid()
    {
        return (bool)$this->valid;
    }

    public static function getAccessPointByCode($code, $country)
    {
        $db = Factory::getContainer()->get('DatabaseDriver');
        $query = $db->getQuery(true)
            ->select('*')
            ->from($db->quoteName('#__pplcz_parcel'))
            ->where($db->quoteName('code') . ' = ' . $db->quote($code))
            ->where($db->quoteName('country') . ' = ' . $db->quote($country))
            ->where($db->quoteName('hidden') . ' = 0');

        $db->setQuery($query);
        $rows = $db->loadAssocList();
        $output = [];

        foreach ($rows as $row) {
            $parcel = new ParcelData();
            $parcel->load($row['ppl_parcel_id']);
            $output[] = $parcel;
        }
        return reset($output);
    }
}