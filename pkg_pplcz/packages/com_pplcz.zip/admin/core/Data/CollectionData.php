<?php

namespace PPLCZ\Data;

defined("_JEXEC") or die();


use Joomla\CMS\Table\Table;
use Joomla\CMS\Factory;
use Joomla\Database\DatabaseDriver;
use Joomla\Event\DispatcherInterface;
use Symfony\Component\ErrorHandler\Error\FatalError;

class CollectionData extends Table
{
    public $ppl_collection_id = 0;
    public $remote_collection_id = null;
    public $created_date = null;
    public $send_date = null;
    public $send_to_api_date = null;
    public $reference_id = null;
    public $state = 'BeforeSend';
    public $shipment_count = 0;
    public $estimated_shipment_count = 0;
    public $contact = '';
    public $telephone = '';
    public $email = '';
    public $note = '';

    public function __construct($db = null,?DispatcherInterface $dispatcher = null)
    {
        $db = $db ?? Factory::getContainer()->get('DatabaseDriver');
        parent::__construct('#__pplcz_collections', 'ppl_collection_id', $db, $dispatcher);

    }

    public function get_id()
    {
        return $this->ppl_collection_id;
    }

    public function get_remote_collection_id()
    {
        return $this->remote_collection_id;
    }

    public function set_remote_collection_id($value)
    {
        $this->remote_collection_id = $value;
    }

    public function get_estimated_shipment_count()
    {
        return $this->estimated_shipment_count;
    }

    public function set_estimated_shipment_count($value)
    {
        $this->estimated_shipment_count = $value;
    }

    public function get_created_date()
    {
        return $this->created_date;
    }

    public function set_created_date($value)
    {
        $this->created_date = $value;
    }

    public function get_send_to_api_date()
    {
        return $this->send_to_api_date;
    }

    public function set_send_to_api_date($value)
    {
        $this->send_to_api_date = $value;
    }

    public function get_send_date()
    {
        return $this->send_date;
    }

    public function set_send_date($value)
    {
        $this->send_date = $value;
    }

    public function get_reference_id()
    {
        return $this->reference_id;
    }

    public function set_reference_id($value)
    {
        $this->reference_id = $value;
    }

    public function get_state()
    {
        return $this->state;
    }

    public function set_state($value)
    {
        $this->state = $value;
    }

    public function get_shipment_count()
    {
        return $this->shipment_count;
    }

    public function set_shipment_count($value)
    {
        $this->shipment_count = $value;
    }

    public function get_contact()
    {
        return $this->contact;
    }

    public function set_contact($value)
    {
        $this->contact = $value;
    }

    public function get_telephone()
    {
        return $this->telephone;
    }

    public function set_telephone($value)
    {
        $this->telephone = $value;
    }

    public function get_email()
    {
        return $this->email;
    }

    public function set_email($value)
    {
        $this->email = $value;
    }

    public function get_note()
    {
        return $this->note;
    }

    public function set_note($value)
    {
        $this->note = $value;
    }

    public function store($updateNulls = false)
    {
        if(empty($this->ppl_collection_id)){
            $this->created_date = (new \Joomla\CMS\Date\Date())->toSql();
            $this->reference_id = pplcz_simple_guid();
        }
        return parent::store($updateNulls);
    }

    public static function read_collections($args)
    {
        $db = \Joomla\CMS\Factory::getContainer()->get('DatabaseDriver');
        $query = $db->getQuery(true)
            ->select('*')
            ->from($db->quoteName('#__pplcz_collections'));

        // Filtrování podle stavu
        if (!empty($args['state'])) {
            $states = array_map([$db, 'quote'], $args['state']); // escapuje každý stav
            $query->where($db->quoteName('state') . ' IN (' . implode(',', $states) . ')');
        }

        // Filtrování podle data (posledních 10 dní)
        $d = (new \DateTime())->sub(new \DateInterval('P10D'));
        $query->where($db->quoteName('send_date') . ' > ' . $db->quote($d->format('Y-m-d')));

        // Řazení podle send_date sestupně
        $query->order($db->quoteName('send_date') . ' DESC');

        // Spuštění dotazu
        $db->setQuery($query);
        $rows = $db->loadAssocList();

        $collection = [];
        foreach ($rows as $result) {
            $c = new CollectionData();
            $c->load($result['ppl_collection_id']);
            $collection[] = $c;
        }

        return $collection;
    }

    public static function available_collections()
    {
        $db = Factory::getContainer()->get('DatabaseDriver');
        $collection = [];
        $state = '';
        $db->setQuery('select * from #__pplcz_collections where state is null or state = ' . $db->quote($state) . ' order by created_date');
        $rows = $db->loadAssocList();
        foreach ($rows as $row)
        {
            $data = new CollectionData();
            $data->load($row['ppl_collection_id']);
            $collection[] = $data;
        }

        return $collection;
    }

    public static function last_collection()
    {
        $db = Factory::getContainer()->get('DatabaseDriver');
        $collection = [];
        $db->setQuery('select * from #__pplcz_collections order by created_date desc limit 1');
        $rows = $db->loadAssocList();
        foreach ($rows as $row)
        {
            $data = new CollectionData();
            $data->load($row['ppl_collection_id']);
            $collection[] = $data;
        }

        return $collection;
    }
}