<?php

namespace PPLCZ\Data;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Table\Table;
use Joomla\Database\DatabaseDriver;
use Joomla\Event\DispatcherInterface;

class PackageData extends Table
{
    public $ppl_package_id = null;
    public $ppl_shipment_id = null;
    public $wc_order_id = null;
    public $reference_id = null;
    public $shipment_number = null;
    public $weight = null;
    public $insurance = null;
    public $insurance_currency = null;
    public $phase = null;
    public $status = null;
    public $status_label = null;
    public $phase_label = null;
    public $last_update_phase = null;
    public $last_test_phase = null;
    public $ignore_phase = null;
    public $import_error = null;
    public $import_error_code = null;
    public $lock = 0;
    public $draft = null;
    public $label_id = null;
    protected $ignore_lock = false;
    protected $hard_lock = false;

    public function __construct(DatabaseDriver $db = null, ?DispatcherInterface $dispatcher = null)
    {
        $db = $db ?? Factory::getContainer()->get('DatabaseDriver');
        parent::__construct('#__pplcz_package', 'ppl_package_id', $db, $dispatcher);
    }

    public function get_id()
    {
        return $this->ppl_package_id;
    }

    public function get_ppl_shipment_id()
    {
        return $this->ppl_shipment_id;
    }

    public function set_ppl_shipment_id($value)
    {
        $this->ppl_shipment_id = $value;
    }

    public function get_wc_order_id()
    {
        return $this->wc_order_id;
    }

    public function set_wc_order_id($value)
    {
        $this->wc_order_id = $value;
    }

    public function get_reference_id()
    {
        return $this->reference_id;
    }

    public function set_reference_id($value)
    {
        $this->reference_id = $value;
    }

    public function get_shipment_number()
    {
        return $this->shipment_number;
    }

    public function set_shipment_number($value)
    {
        $this->shipment_number = $value;
    }

    public function get_weight()
    {
        return $this->weight;
    }

    public function set_weight($value)
    {
        $this->weight = $value;
    }

    public function get_insurance()
    {
        return $this->insurance;
    }

    public function set_insurance($value)
    {
        $this->insurance = $value;
    }

    public function get_insurance_currency()
    {
        return $this->insurance_currency;
    }

    public function set_insurance_currency($value)
    {
        $this->insurance_currency = $value;
    }

    public function get_phase()
    {
        return $this->phase;
    }

    public function set_phase($value)
    {
        $this->phase = $value;
    }

    public function get_status()
    {
        return $this->status;
    }

    public function set_status($value)
    {
        $this->status = $value;
    }

    public function get_status_label()
    {
        return $this->status_label;
    }

    public function set_status_label($value)
    {
        $this->status_label = $value;
    }

    public function get_phase_label()
    {
        return $this->phase_label;
    }

    public function set_phase_label($value)
    {
        $this->phase_label = $value;
    }

    public function get_last_update_phase()
    {
        return $this->last_update_phase;
    }

    public function set_last_update_phase($value)
    {
        $this->last_update_phase = $value;
    }

    public function get_last_test_phase()
    {
        return $this->last_test_phase;
    }

    public function set_last_test_phase($value)
    {
        $this->last_test_phase = $value;
    }

    public function get_ignore_phase()
    {
        return $this->ignore_phase;
    }

    public function set_ignore_phase($value)
    {
        $this->ignore_phase = $value;
    }

    public function get_import_error()
    {
        return $this->import_error;
    }

    public function set_import_error($value)
    {
        $this->import_error = $value;
    }

    public function get_import_error_code()
    {
        return $this->import_error_code;
    }

    public function set_import_error_code($value)
    {
        $this->import_error_code = $value;
    }

    public function get_label_id()
    {
        return $this->label_id;
    }

    public function set_label_id($value)
    {
        $this->label_id = $value;
    }

    public function isImported(): bool
    {
        return ($this->get_shipment_number() && !!$this->get_import_error());
    }

    public function get_lock()
    {
        return $this->lock;
    }

    public function set_lock($value)
    {
        $this->lock = $value;
    }
    public function ignore_lock()
    {
        $this->ignore_lock = true;
    }
    public function get_ignore_lock()
    {
        return $this->ignore_lock;
    }

    public function hard_lock()
    {
        $this->hard_lock = true;
    }


    public static function find_packages_by_shipment($ppl_shipment_id)
    {
        $db = Factory::getContainer()->get('DatabaseDriver');
        $db->setQuery('SELECT * FROM #__pplcz_package WHERE ppl_shipment_id = ' . $db->quote($ppl_shipment_id));
        $rows = $db->loadAssocList();
        $output = [];

        foreach ($rows as $row) {
            $package = new PackageData();
            $package->bind($row);
            $output[] = $package;
        }

        return $output;
    }

    public static function find_package_by_shipment_number($shipmentNumbers)
    {
        $db = Factory::getContainer()->get('DatabaseDriver');
        $db->setQuery('SELECT * FROM #__pplcz_package WHERE shipment_number = ' . (int)$shipmentNumbers);
        $rows = $db->loadAssocList();
        $output = [];

        foreach ($rows as $row) {
            $package = new PackageData();
            $package->bind($row);
            $output[] = $package;
        }

        return $output;
    }

    public static function find_packages_by_phases_and_time($phases, $from_last_test_phase, $last_change_update, $limit)
    {
        if (!$phases || !is_array($phases)) {
            return [];
        }

        $db = Factory::getContainer()->get('DatabaseDriver');
        $query = $db->getQuery(true);

        $phasesSafe = array_map([$db, 'quote'], $phases);

        $query->select('*')
            ->from($db->quoteName('#__pplcz_package'))
            ->where($db->quoteName('phase') . ' IN (' . implode(',', $phasesSafe) . ')')
            ->where('(' . $db->quoteName('last_update_phase') . ' >= ' . $db->quote($last_change_update) .
                ' OR ' . $db->quoteName('last_update_phase') . ' IS NULL)')
            ->where($db->quoteName('shipment_number') . ' IS NOT NULL')
            ->where($db->quoteName('shipment_number') . " <> ''")
            ->where('(' . $db->quoteName('last_test_phase') . ' < ' . $db->quote($from_last_test_phase) .
                ' OR ' . $db->quoteName('last_test_phase') . ' IS NULL)')
            ->order($db->quoteName('last_test_phase') . ' ASC');


        $db->setQuery($query, 0, (int)$limit);
        $rows = $db->loadAssocList();

        $output = [];

        foreach ($rows as $row) {
            $package = new PackageData($db);
            $package->bind($row);
            $output[] = $package;
        }

        return $output;
    }


}