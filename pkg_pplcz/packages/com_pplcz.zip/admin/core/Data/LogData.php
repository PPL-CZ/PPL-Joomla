<?php

namespace PPLCZ\Data;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Table\Table;
use Joomla\Database\DatabaseDriver;
use Joomla\Event\DispatcherInterface;

class LogData extends Table
{

    public $ppl_log_id = 0;
    public $timestamp = '';
    public $message = '';
    public $errorhash = '';
    public $lock = 0;
    public $draft = 0;

    /**
     * Konstruktor
     */
    public function __construct(DatabaseDriver $db = null, ?DispatcherInterface $dispatcher = null)
    {
        $db = $db ?? Factory::getDbo();
        parent::__construct('#__pplcz_log', 'ppl_log_id', $db, $dispatcher);
    }

    public function get_id(): string
    {
        return $this->ppl_log_id;
    }

    public function get_message(): string
    {
        return $this->message;
    }

    public function set_message(string $value): void
    {
        $this->message = $value;
    }

    public function get_timestamp(): string
    {
        return $this->timestamp;
    }

    public function set_timestamp(string $value): void
    {
        $this->timestamp = $value;
    }

    public function get_errorhash(): string
    {
        return $this->errorhash;
    }

    public function set_errorhash(string $value): void
    {
        $this->errorhash = $value;
    }
}
