<?php
namespace PPLCZ\Data;

defined("_JEXEC") or die();


use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Table\Table;
use Joomla\Registry\Registry;
use Joomla\Database\DatabaseDriver;
use Joomla\Event\DispatcherInterface;

class AddressData extends Table
{
    public $ppl_address_id = null;
    public $address_name = '';
    public $name = '';
    public $contact = '';
    public $mail = '';
    public $phone = '';
    public $street = '';
    public $city = '';
    public $zip = '';
    public $country = '';
    public $note = '';
    public $type = '';
    public $hidden = 1;
    public $lock = 0;
    public $draft = null;
    protected $ignore_lock = false;
    protected $hard_lock = false;

    public function ignore_lock()
    {
        $this->ignore_lock = true;
    }

    public function hard_lock()
    {
        $this->hard_lock = true;
    }

    public function set_id($value)
    {
        $this->ppl_address_id = $value;
    }
    public function get_id()
    {
        return $this->ppl_address_id;
    }

    public function set_address_name($value)
    {
        $this->address_name = $value;
    }

    public function get_address_name()
    {
        return $this->address_name;
    }

    // Getter a Setter pro note
    public function get_note()
    {
        return $this->note;
    }

    public function set_note($value)
    {
        $this->note = $value;
    }

    // Getter a Setter pro hidden
    public function get_hidden($context = 'view')
    {
        return $this->hidden;
    }

    public function set_hidden($value)
    {
        $this->hidden = $value;
    }

    // Getter a Setter pro contact
    public function get_contact($context = 'view')
    {
        return $this->contact;
    }

    public function set_contact($value)
    {
        $this->contact = $value;
    }

    // Getter a Setter pro name
    public function get_name($context = 'view')
    {
        return $this->name;
    }

    public function set_name($value)
    {
        $this->name = $value;
    }

    // Getter a Setter pro mail
    public function get_mail($context = 'view')
    {
        return $this->mail;
    }

    public function set_mail($value)
    {
        $this->mail = $value;
    }

    // Getter a Setter pro phone
    public function get_phone($context = 'view')
    {
        return $this->phone;
    }

    public function set_phone($value)
    {
        $this->phone = $value;
    }

    // Getter a Setter pro street
    public function get_street($context = 'view')
    {
        return $this->street;
    }

    public function set_street($value)
    {
        $this->street = $value;
    }

    // Getter a Setter pro city
    public function get_city($context = 'view')
    {
        return $this->city;
    }

    public function set_city($value)
    {
        $this->city = $value;
    }

    // Getter a Setter pro zip
    public function get_zip($context = 'view')
    {
        return $this->zip;
    }

    public function set_zip($value)
    {
        $this->zip = $value;
    }

    // Getter a Setter pro type
    public function get_type($context = 'view')
    {
        return $this->type;
    }

    public function set_type($value)
    {
        $this->type = $value;
    }

    // Getter a Setter pro country
    public function get_country($context = 'view')
    {
        return $this->country;
    }

    public function set_country($value)
    {
        $this->country = $value;
    }

    public function get_lock()
    {
        return $this->lock;
    }

    public function set_lock($value)
    {
        $this->lock = (int)(bool)$value;
    }


    public function __construct(DatabaseDriver $db = null, ?DispatcherInterface $dispatcher = null)
    {
        $db = $db ?? Factory::getContainer()->get('DatabaseDriver');
        parent::__construct('#__pplcz_address', 'ppl_address_id', $db, $dispatcher);
    }

    public function load($keys = 'ppl_address_id', $reset = true)
    {
        parent::load($keys, $reset);
    }

    /**
     * @param AddressData[] $addreses
     * @return void
     */
    public static function set_default_sender_addresses(array $addreses)
    {
        $ids = [];
        foreach ($addreses as $address)
        {
            $ids[] = $address->ppl_address_id;
        }
        $ids = implode(",", $ids);

        // Načíst params přímo z databáze, NE z ComponentHelper cache
        $table = Table::getInstance('extension');
        $table->load(['element' => 'com_pplcz']);

        // Použít aktuální params z databáze
        $params = new Registry($table->params);
        $params->set(pplcz_create_name("default_sender_address"), $ids);

        $table->params = $params->toString();
        $table->store();
    }

    /**
     * @return AddressData[]
     */
    public static function get_default_sender_addresses()
    {
        $table = Table::getInstance('extension');
        $table->load(['element' => 'com_pplcz']);
        $params = new Registry($table->params);
        $content = $params->get(pplcz_create_name("default_sender_address"));
        // PHP 8.1+ kompatibilita - explode() nesmí dostat null
        if (empty($content)) {
            return [];
        }

        $data = array_unique(array_filter(array_map("trim", explode(",", $content)), "ctype_digit"));
        foreach ($data as $key => $val)
        {
            $id = $val;
            $val = new AddressData();
            $val->load($id);
            if ($val->ppl_address_id)
                $data[$key] = $val;
            else
                unset($data[$key]);
        }
        return $data;
    }
}