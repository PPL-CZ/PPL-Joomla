<?php
// phpcs:ignoreFile WordPress.DB.DirectDatabaseQuery.DirectQuery

namespace PPLCZ\Data;

defined('_JEXEC') or die();

use Joomla\CMS\Table\Table;
use Joomla\CMS\Factory;

class ShipmentData extends Table
{
    public $ppl_shipment_id = null;
    public $wc_order_id = null;
    public $reference_id = null;
    public $import_state = null;
    public $service_code = null;
    public $package_ids = null; // CSV
    public $service_name = null;
    public $recipient_address_id = null;
    public $sender_address_id = null;
    public $cod_bank_account_id = null;
    public $cod_value = null;
    public $cod_value_currency = null;
    public $cod_variable_number = null;
    public $parcel_id = null;
    public $has_parcel = 0;
    public $batch_id = null;
    public $batch_local_id = null;
    public $batch_label_group = null;
    public $age = null;
    public $note = null;
    public $lock = 0;
    public $draft = null;
    public $import_errors = null;
    protected $ignore_lock = false;
    protected $hard_lock = false;

    public function ignore_lock()
    {
        $this->ignore_lock = true;
    }

    public function hard_lock()
    {
        $this->hard_lock = true;
    }

    public function __construct($db = null)
    {
        if (!$db) {
            $db = Factory::getContainer()->get('DatabaseDriver');
        }
        parent::__construct('#__pplcz_shipment', 'ppl_shipment_id', $db);
    }

    public function get_id()
    {
        return $this->ppl_shipment_id;
    }


    public function get_package_ids()
    {
        return $this->package_ids ? array_filter(array_map('trim', explode(',', $this->package_ids)), 'ctype_digit') : [];
    }

    public function set_package_ids(array $ids)
    {
        $this->package_ids = implode(',', array_filter(array_map('trim', $ids), 'ctype_digit'));
    }

    public function get_sender_address_id($default = false)
    {
        if ($default) {
            $addresses = AddressData::get_default_sender_addresses();
            $address = reset($addresses);
            return $address ? $address->ppl_address_id : null;
        }
        return $this->sender_address_id;
    }

    public function set_sender_address_id($value)
    {
        $this->sender_address_id = $value;
    }

    public function get_cod_bank_account_id($default = false)
    {
        if ($default) {
            $banks = CodBankAccountData::get_default_bank_accounts();
            $currency = $this->cod_value_currency;
            $filtered = array_filter($banks, fn($b) => $b->currency === $currency);
            return $filtered ? reset($filtered)->id : ($banks ? reset($banks)->id : null);
        }
        return $this->cod_bank_account_id;
    }

    public function set_cod_bank_account_id($value)
    {
        $this->cod_bank_account_id = $value;
    }

    public function get_batch_label_group()
    {
        return $this->batch_label_group;
    }

    public function set_batch_label_group($value)
    {
        $this->batch_label_group = $value;
    }

    public function get_service_name()
    {
        return $this->service_name;
    }

    public function set_service_name($value)
    {
        $this->service_name = $value;
    }

    public function get_import_errors()
    {
        return $this->import_errors;
    }

    public function set_import_errors($value)
    {
        $this->import_errors = $value;
    }

    public function get_cod_variable_number()
    {
        return $this->cod_variable_number;
    }

    public function set_cod_variable_number($value)
    {
        $this->cod_variable_number = $value;
    }

    public function set_wc_order_id($value)
    {
        $this->wc_order_id = $value;
    }

    public function get_wc_order_id()
    {
        return $this->wc_order_id;
    }

    public function get_reference_id()
    {
        return $this->reference_id;
    }

    public function set_reference_id($value)
    {
        $this->reference_id = $value;
    }

    public function get_import_state()
    {
        return $this->import_state;
    }

    public function set_import_state($value)
    {
        $this->import_state = $value;
    }

    public function get_service_code()
    {
        return $this->service_code;
    }

    public function set_service_code($value)
    {
        $this->service_code = $value;
    }

    public function get_recipient_address_id()
    {
        return $this->recipient_address_id;
    }

    public function set_recipient_address_id($value)
    {
        $this->recipient_address_id =  $value;
    }

    public function get_cod_value()
    {
        return $this->cod_value;
    }

    public function set_cod_value($value)
    {
        $this->cod_value = $value;
    }

    public function get_cod_value_currency()
    {
        return $this->cod_value_currency;
    }

    public function set_cod_value_currency($value)
    {
        $this->cod_value_currency = $value;
    }

    public function get_parcel_id()
    {
        return $this->parcel_id;
    }

    public function set_parcel_id($value)
    {
        $this->parcel_id = $value;
    }

    public function get_has_parcel()
    {
        return $this->has_parcel;
    }

    public function set_has_parcel($value)
    {
        $this->has_parcel = (int)(bool)$value;
    }

    public function get_batch_id()
    {
        return $this->batch_id;
    }

    public function set_batch_id($value)
    {
        $this->batch_id = $value;
    }

    public function get_batch_local_id()
    {
        return $this->batch_local_id;
    }

    public function set_batch_local_id($value)
    {
        $this->batch_local_id = $value;
    }

    public function get_age()
    {
        return $this->age;
    }

    public function set_age($value)
    {
        $this->age = $value;
    }

    public function get_note()
    {
        return $this->note;
    }

    public function set_note($value)
    {
        $this->note = $value;
    }

    public function get_lock()
    {
        return $this->lock;
    }

    public function set_lock($value)
    {
        $this->lock = (int)(bool)$value;
    }

    public function lock()
    {
        $this->lock = 1;
        $this->store();

        $recipient = new AddressData();
        $recipient->load($this->get_recipient_address_id());
        if (!$recipient->lock) {
            $recipient->lock = 1;
            $recipient->store();
        }

        $sender = new AddressData();
        $sender->load($this->get_sender_address_id());
        if (!$sender->lock) {
            $sender->lock = 1;
            $sender->store();
        }

        $ids = $this->get_package_ids();

        foreach ($ids as $key => $value) {
            $package = new PackageData();
            $package->load($value);
            if (!$package->lock) {
                $package->lock = 1;
                $package->set_ppl_shipment_id($this->ppl_shipment_id);
                $package->set_wc_order_id($this->get_wc_order_id());
                $package->store();
            }
        }

        if ($this->get_cod_bank_account_id()) {

            $codBank = new CodBankAccountData();
            $codBank->load($this->get_cod_bank_account_id());
            if (!$codBank->lock) {
                $codBank->lock = 1;
                $codBank->store();
            }
        }
    }

    public function unlock()
    {
        /**
         * nemá smysl odemykat záznam, který už je odeslan a akceptován PPL.
         */
        if (in_array($this->get_import_state() ?: "", ["None", "Error", ""], true)) {
            $this->lock = 0;
            $this->set_import_state("None");
            $this->set_import_errors(null);


            foreach ($this->get_package_ids() as $package_id) {
                $package = new PackageData();
                $package->load($package_id);
                $package->lock = 0;
                $package->set_import_error(null);
                $package->set_import_error_code(null);
                $package->store();
            }

            $address = new AddressData();
            $address->load($this->get_recipient_address_id());
            $address->lock = 0;
            $address->store();
            $this->store();
        } else {
            throw new \Exception("Lock");
        }
    }

    public static function read_shipments($args = [])
    {
        $db = Factory::getContainer()->get('DatabaseDriver');
        $where = [];
        $query = $db->getQuery(true)
            ->select('*')
            ->from($db->quoteName('#__pplcz_shipment'));

        if (isset($args['wc_order_id']) && is_array($args['wc_order_id']) && $args["wc_order_id"])
        {
            $orders = array_map(function ($item) {
                return intval($item);
            }, $args["wc_order_id"]) ;

            $where[] =  $db->quoteName('wc_order_id') . ' IN (' . join(', ', $orders). ')';
        }

        if (isset($args['batch_label_group']) && is_array($args['batch_label_group']) && $args['batch_label_group'])
        {
            $batch_groups = array_map(function ($item) use ($db){
                return $db->quote($item);
            }, $args["batch_label_group"]) ;

            $where[] = $db->quoteName('batch_label_group') . ' IN (' . implode(', ', $batch_groups) . ')';

        }

        if (isset($args['batch_id']) && is_array($args['batch_id']) && $args['batch_id'])
        {
            $batch_groups = array_map(function ($item) use ($db){
                return $db->quote($item);
            }, $args["batch_id"]) ;

            $where[] = $db->quoteName('batch_id') . ' IN (' . join(', ', $batch_groups). ') ';
        }
//        $condition = ' where ' . join(" AND ", $where);
//        $condition = $where ? ' WHERE ' . join(" AND ", $where) : '';
        $output = [];

        $query = $db->getQuery(true)
            ->select('*')
            ->from($db->quoteName('#__pplcz_shipment'));

        if($where){
            $query->where($where);
        }

        $db->setQuery($query);
        $rows = $db->loadAssocList();

        foreach($rows as $row){
            $data = new ShipmentData();
            $data->bind($row);
            $output[] = $data;
        }

        return $output;
    }

    public static function read_order_shipments($order_id)
    {
        $output = [];
        $db = Factory::getContainer()->get('DatabaseDriver');
        $db->setQuery('SELECT * FROM #__pplcz_shipment WHERE wc_order_id = ' . $db->quote($order_id));
        $rows = $db->loadAssocList();

        foreach($rows as $row){
            $data = new ShipmentData();
            $data->bind($row);
            $output[] = $data;
        }

        return $output;
    }

    /**
     * @param $batch_id
     * @return ShipmentData[]
     * @throws \Exception
     */
    public static function read_batch_shipments($batch_id)
    {
        $output = [];
        $db = Factory::getContainer()->get('DatabaseDriver');

        $query = $db->getQuery(true)
            ->select('*')
            ->from($db->quoteName('#__pplcz_shipment'))
            ->where($db->quoteName('batch_local_id') . ' = ' . (int)$batch_id)
            ->order($db->quoteName('reference_id') . ' ASC');

        $db->setQuery($query);
        $rows = $db->loadAssocList();

        foreach($rows as $row){
            $session = Factory::getSession();
            $session->set($row["ppl_shipment_id"], $row);

            $data = new ShipmentData();
            $data->bind($row);
            $output[] = $data;
        }

        return $output;
    }

    /**
     * Načte zásilky podle vzdáleného batch ID z PPL API
     * @param string $batch_remote_id Remote batch ID (GUID) from PPL API
     * @return ShipmentData[]
     * @throws \Exception
     */
    public static function read_remote_batch_shipments($batch_remote_id)
    {
        $output = [];
        $db = Factory::getContainer()->get('DatabaseDriver');

        $query = $db->getQuery(true)
            ->select('*')
            ->from($db->quoteName('#__pplcz_shipment'))
            ->where($db->quoteName('batch_id') . ' = ' . $db->quote($batch_remote_id))
            ->order($db->quoteName('reference_id'));

        $db->setQuery($query);
        $rows = $db->loadAssocList();

        foreach($rows as $row){
            $session = Factory::getSession();
            $session->set($row["ppl_shipment_id"], $row);

            $data = new ShipmentData();
            $data->bind($row);
            $output[] = $data;
        }

        return $output;
    }

    /**
     * @return ShipmentData[]
     * @throws \Exception
     */
    public static function read_progress_shipments()
    {
        $output = [];
        $import_state = 'InProgress';
        $db = Factory::getContainer()->get('DatabaseDriver');
        $db->setQuery('SELECT * FROM #__pplcz_shipment WHERE batch_id IS NOT NULL AND import_state = ' . $db->quote($import_state));
        $rows = $db->loadAssocList();

        foreach($rows as $row){
            $data = new ShipmentData();
            $data->bind($row);
            $output[] = $data;
        }

        return $output;
    }

    public static function find_shipments_by_wc_order($wc_order_id)
    {
        $db = Factory::getContainer()->get('DatabaseDriver');

        $query = $db->getQuery(true)
            ->select('*')
            ->from($db->quoteName('#__pplcz_shipment'))
            ->where($db->quoteName('wc_order_id') . ' = ' . (int)$wc_order_id);

        $db->setQuery($query);
        $rows = $db->loadAssocList();

        $output = [];
        $session = Factory::getSession();

        foreach ($rows as $row) {
            $shipmentId = $row['ppl_shipment_id'];

            // Pokus o načtení z Joomla cache
            $sessionKey = 'shipment_' . $shipmentId;
            $shipment = $session->get($sessionKey);

            if ($shipment === false) {
                $shipment = new ShipmentData();
                $shipment->bind($row);

                $session->set($sessionKey, $shipment);
            }

            $output[] = $shipment;
        }

        return $output;
    }

    public static function reorder_batch_shipments($batch_local_id, $shipments)
    {
        $db = Factory::getContainer()->get('DatabaseDriver');

        // 1. Načtení všech zásilek v batchi
        $query = $db->getQuery(true)
            ->select('ppl_shipment_id')
            ->from($db->quoteName('#__pplcz_shipment'))
            ->where($db->quoteName('batch_local_id') . ' = ' . (int)$batch_local_id);

        $db->setQuery($query);
        $batchShipments = $db->loadColumn();

        // 2. Ověření, že seznam odpovídá (žádná zásilka navíc nebo chybějící)
        if (array_diff($shipments, $batchShipments) || array_diff($batchShipments, $shipments)) {
            throw new \Exception("Invalid count shipments - nesouhlasí počet zásilek v batchi");
        }

        // 3. Kontrola zamčených zásilek
        $shipmentObjects = [];
        foreach ($shipments as $shipmentId) {
            $shipmentData = new ShipmentData();
            $shipmentData->load($shipmentId);

            if ($shipmentData->get_lock()) {
                throw new \Exception('Zásilka ID ' . $shipmentId . ' je zamčená a nelze ji přeuspořádat');
            }

            $shipmentObjects[] = $shipmentData;
        }

        $pad = 5; // Padding na 5 číslic (např. 00001)


        $position = 1;
        foreach ($shipmentObjects as $shipment) {
            // Formát: "00001#order_id", "00002#order_id", atd.
            $ref = str_pad($position, $pad, "0", STR_PAD_LEFT) . '#' . $shipment->get_wc_order_id();
            $shipment->reference_id = $ref;
            $shipment->store(true);
            $position++;
        }
    }
}
