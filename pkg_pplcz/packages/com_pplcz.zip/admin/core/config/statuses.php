<?php
defined("_JEXEC") or die();

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Table\Table;

return call_user_func(function () {

    $params = ComponentHelper::getParams('com_pplcz');
    $raw = $params->get(pplcz_create_name('shipment_statuses'));

    if (is_string($raw)) {
        $statuses = json_decode($raw, true);
    } else if (is_array($raw) || is_object($raw)) {
        $statuses = json_decode(json_encode($raw), true); // Normalize to array
    } else {
        $statuses = null;
    }

    if (!is_array($statuses) || defined("PPLCZ_REFRESH")) {
        try {
            $cpl = new \PPLCZ\Admin\CPLOperation();
            $statuses = $cpl->getStatuses();
            if ($statuses) {
                $params->set(pplcz_create_name('shipment_statuses'), json_encode($statuses));
                $table = Table::getInstance('extension');
                $table->load(['element' => 'com_pplcz']);
                $table->params = $params->toString();
                $table->store();
                return $statuses;
            }
        } catch (Exception $ex) {
        }
    }

    return $statuses;
});