<?php
defined("_JEXEC") or die();


return call_user_func(function () {

    $raw = pplcz_get_option(pplcz_create_name('shipment_statuses'));

    if (is_string($raw)) {
        $statuses = json_decode($raw, true);
    } else if (is_array($raw) || is_object($raw)) {
        $statuses = json_decode(json_encode($raw), true); // Normalize to array
    } else {
        $statuses = null;
    }

    if (!is_array($statuses) || defined("PPLCZ_REFRESH")) {
        try {
            $cpl = new \PPLCZ\Admin\CPLOperation();
            $statuses = $cpl->getStatuses();
            if ($statuses) {
                pplcz_set_option(pplcz_create_name('shipment_statuses'), json_encode($statuses));
                return $statuses;
            }
        } catch (Exception $ex) {
        }
    }

    return $statuses;
});