<?php

use Joomla\CMS\Table\Table;

defined("_JEXEC") or die();


return call_user_func(function () {

    $params = \Joomla\CMS\Component\ComponentHelper::getParams('com_pplcz');
    $raw = $params->get(pplcz_create_name('cod_currencies'));

    if (is_string($raw)) {
        $currencies = json_decode($raw, true);
    } else if (is_array($raw) || is_object($raw)) {
        $currencies = json_decode(json_encode($raw), true); // Normalize to array
    } else {
        $currencies = null;
    }

    if (!is_array($currencies) || defined("PPLCZ_REFRESH")) {
        try {
            $cpl = new \PPLCZ\Admin\CPLOperation();
            $currencies = $cpl->getCodCurrencies();
            if ($currencies) {
                // Store as array, not as JSON string - Registry will handle JSON encoding
                $params->set(pplcz_create_name("cod_currencies"), $currencies);

                $table = Table::getInstance('extension');
                $table->load(['element' => 'com_pplcz']);
                $table->params = $params->toString();
                $table->store();

                return $currencies;
            }
        } catch (\Exception $ex) {
            return [];
        }
    }

    if (is_array($currencies)) {
        return $currencies;
    }

    return [];
});