<?php


defined("_JEXEC") or die();


return call_user_func(function () {

    $raw = pplcz_get_option(pplcz_create_name('cod_currencies'));

    if (is_string($raw)) {
        $currencies = json_decode($raw, true);
    } else if (is_array($raw) || is_object($raw)) {
        $currencies = json_decode(json_encode($raw), true); // Normalize to array
    } else {
        $currencies = null;
    }

    if (!is_array($currencies) || defined("PPLCZ_REFRESH")) {
        try {
            $cpl = new \PPLCZ\Admin\CPLOperation();
            $currencies = $cpl->getCodCurrencies();
            if ($currencies) {
                // Store as array, not as JSON string - Registry will handle JSON encoding
                pplcz_set_option(pplcz_create_name("cod_currencies"), $currencies);

                return $currencies;
            }
        } catch (\Exception $ex) {
            return [];
        }
    }

    if (is_array($currencies)) {
        return $currencies;
    }

    return [];
});