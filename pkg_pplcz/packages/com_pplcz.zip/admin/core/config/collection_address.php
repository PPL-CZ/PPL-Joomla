<?php
defined("_JEXEC") or die();

use Joomla\CMS\Factory;
use PPLCZ\Admin\CPLOperation;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Table\Table;

require_once JPATH_ADMINISTRATOR . '/components/com_pplcz/core/globals.php';
require_once JPATH_ADMINISTRATOR . '/components/com_pplcz/core/autoloader.php';

return call_user_func(function() {

        $params = ComponentHelper::getParams('com_pplcz');
        $raw = $params->get(pplcz_create_name('collection_address'));

        if (is_string($raw)) {
            $address = json_decode($raw, true);
        } else if (is_array($raw) || is_object($raw)) {
            $address = json_decode(json_encode($raw), true); // Normalize to array
        } else {
            $address = null;
        }

    try {
        if (!is_array($address) || defined("PPLCZ_REFRESH")) {

            $cpl = new CPLOperation();
            $collectionAddresses = $cpl->getCollectionAddresses();

            foreach ($collectionAddresses as $key => $value) {
                $collectionAddresses[$key] = \PPLCZ\Serializer::getInstance()->denormalize($value, \PPLCZ\Model\Model\CollectionAddressModel::class);
            }

            if ($collectionAddresses) {
                $collectionAddress = array_filter($collectionAddresses, function (\PPLCZ\Model\Model\CollectionAddressModel $model) {
                    return $model->getCode() === "PICK";
                });
                if ($collectionAddress) {
                    $address = reset($collectionAddress);

                    $normalizedAddress = \PPLCZ\Serializer::getInstance()->normalize($address);
                    $params->set(pplcz_create_name('collection_address'), json_encode($normalizedAddress));
                    $table = Table::getInstance('extension');
                    $table->load(['element' => 'com_pplcz']);
                    $table->params = $params->toString();
                    $table->store();

                    return $normalizedAddress;
                }
            }
        }
    }
    catch (\Exception $exception)
    {
        return null;
    }
    return $address;
});