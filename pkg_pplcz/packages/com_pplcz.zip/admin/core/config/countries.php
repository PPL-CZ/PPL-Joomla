<?php
defined("_JEXEC") or die();

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Table\Table;

return call_user_func(function () {

    $params = ComponentHelper::getParams('com_pplcz');
    $raw = $params->get(pplcz_create_name('countries_limit'));

    if (is_string($raw)) {
        $countries = json_decode($raw, true);
    } else if (is_array($raw) || is_object($raw)) {
        $countries = json_decode(json_encode($raw), true); // Normalize to array
    } else {
        $countries = null;
    }

    if (!is_array($countries) || defined("PPLCZ_REFRESH")) {
        try {
            $cpl = new \PPLCZ\Admin\CPLOperation();
            $countries = $cpl->getCountries();
            if ($countries) {
                // Store as array, not as JSON string - Registry will handle JSON encoding
                $params->set(pplcz_create_name('countries_limit'), $countries);
                $table = Table::getInstance('extension');
                $table->load(['element' => 'com_pplcz']);
                $table->params = $params->toString();
                $table->store();
                return $countries;
            }
        } catch (Exception $ex) {

        }
    }

    if(is_array($countries)){
        return $countries;
    }

    return [
        'CZ' => true,
        'DE' => false,
        'GB' => false,
        'SK' => true,
        'AT' => false,
        'PL' => true,
        'CH' => false,
        'FI' => false,
        'HU' => true,
        'SI' => false,
        'LV' => false,
        'EE' => false,
        'LT' => false,
        'BE' => false,
        'DK' => false,
        'ES' => false,
        'FR' => false,
        'IE' => false,
        'IT' => false,
        'NL' => false,
        'NO' => false,
        'PT' => false,
        'SE' => false,
        'RO' => true,
        'BG' => false,
        'GR' => false,
        'LU' => false,
        'HR' => false,
    ];
});