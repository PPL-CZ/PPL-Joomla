<?php

namespace PPLCZ\Model\Model;

class GlobalSettingModel extends \ArrayObject
{
    /**
     * @var array
     */
    protected $initialized = array();
    public function isInitialized($property) : bool
    {
        return array_key_exists($property, $this->initialized);
    }
    /**
     * 
     *
     * @var GlobalSettingMapModel
     */
    protected $map;
    /**
     * 
     *
     * @return GlobalSettingMapModel
     */
    public function getMap() : ?GlobalSettingMapModel
    {
        return $this->map;
    }
    /**
     * 
     *
     * @param GlobalSettingMapModel $map
     *
     * @return self
     */
    public function setMap(?GlobalSettingMapModel $map) : self
    {
        $this->initialized['map'] = true;
        $this->map = $map;
        return $this;
    }
}