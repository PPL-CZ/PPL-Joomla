<?php

defined('_JEXEC') or die('Restricted Access');
/**
 * @package     Joomla.Administrator
 * @subpackage  com_helloworld
 *
 * @copyright   Copyright (C) 2020 John Smith. All rights reserved.
 * @license     GNU General Public License version 3; see LICENSE
 */

// No direct access to this file

JLoader::registerNamespace('PPLCZ', JPATH_ADMINISTRATOR . '/components/com_pplcz/core', false,false, true);

use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;
use PPLCZ\Admin\Assets\JsTemplate;

?>
<div id="pplcz_options"></div>

<?php

JsTemplate::addInlineScript('optionsPage', 'pplcz_options');





