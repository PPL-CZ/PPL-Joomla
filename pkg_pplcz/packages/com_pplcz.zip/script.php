<?php

use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Factory;
use Joomla\CMS\Log\Log;

class com_pplczInstallerScript
{
    /**
     * Constructor
     *
     * @param   InstallerAdapter  $adapter  The object responsible for running this script
     */
    public function __construct(InstallerAdapter $adapter)
    {
    }

    /**
     * Called before any type of action
     *
     * @param   string  $route  Which action is happening (install|uninstall|discover_install|update)
     * @param   InstallerAdapter  $adapter  The object responsible for running this script
     *
     * @return  boolean  True on success
     */
    public function preflight($route, InstallerAdapter $adapter)
    {
        // Check minimum Joomla version
        if (version_compare(JVERSION, '5.0', '<'))
        {
            Factory::getApplication()->enqueueMessage(
                'PPL CZ component requires Joomla 5.0 or higher',
                'error'
            );
            return false;
        }

        // Check PHP version
        if (version_compare(PHP_VERSION, '8.1', '<'))
        {
            Factory::getApplication()->enqueueMessage(
                'PPL CZ component requires PHP 8.1 or higher',
                'error'
            );
            return false;
        }

        return true;
    }

    /**
     * Called after any type of action
     *
     * @param   string  $route  Which action is happening (install|uninstall|discover_install|update)
     * @param   InstallerAdapter  $adapter  The object responsible for running this script
     *
     * @return  boolean  True on success
     */
    public function postflight($route, InstallerAdapter $adapter)
    {
        if ($route === 'install' || $route === 'update')
        {
            // Check if tables were installed
            $tablesInstalled = $this->checkTablesInstalled();

            if (!$tablesInstalled)
            {
                Factory::getApplication()->enqueueMessage(
                    'Database tables were not installed automatically. Attempting manual installation...',
                    'warning'
                );

                // Try to install tables manually
                if ($this->installTablesManually($adapter))
                {
                    Factory::getApplication()->enqueueMessage(
                        'Database tables installed successfully.',
                        'success'
                    );
                }
                else
                {
                    Factory::getApplication()->enqueueMessage(
                        'Failed to install database tables. Please run the SQL file manually: administrator/components/com_pplcz/sql/install.mysql.utf8.sql',
                        'error'
                    );
                    return false;
                }
            }
            else
            {
                Factory::getApplication()->enqueueMessage(
                    'Database tables are already installed.',
                    'info'
                );
            }

            if ($route === 'install')
            {
                Factory::getApplication()->enqueueMessage(
                    'PPL CZ component has been successfully installed. Please configure your API credentials in Components > PPL CZ > Settings.',
                    'success'
                );
            }
            elseif ($route === 'update')
            {
                Factory::getApplication()->enqueueMessage(
                    'PPL CZ component has been successfully updated.',
                    'success'
                );
            }

            // Instalace VirtueMart template overrides
            $this->installTemplateOverrides();
        }

        return true;
    }

    /**
     * Install VirtueMart template overrides for product and shipmentmethod edit
     *
     * @return  boolean  True on success
     */
    private function installTemplateOverrides()
    {
        $success = true;

        // Product overrides
        $productSourceBase = JPATH_ADMINISTRATOR . '/components/com_pplcz/templates/vmadmin/html/com_virtuemart/product';
        $productTargetBase = JPATH_ADMINISTRATOR . '/templates/vmadmin/html/com_virtuemart/product';

        // Vytvořit cílovou složku pro product pokud neexistuje
        if (!is_dir($productTargetBase))
        {
            if (!mkdir($productTargetBase, 0755, true))
            {
                Factory::getApplication()->enqueueMessage(
                    'Failed to create VirtueMart product template override directory: ' . $productTargetBase,
                    'warning'
                );
                $success = false;
            }
        }

        // Soubory pro product k zkopírování
        $productFiles = [
            'product_edit.php',
            'product_edit_ppl.php'
        ];

        foreach ($productFiles as $file)
        {
            $source = $productSourceBase . '/' . $file;
            $target = $productTargetBase . '/' . $file;

            if (file_exists($source))
            {
                if (!copy($source, $target))
                {
                    Factory::getApplication()->enqueueMessage(
                        'Failed to install VirtueMart product template override: ' . $file,
                        'warning'
                    );
                    $success = false;
                }
            }
        }

        // Category overrides
        $categorySourceBase = JPATH_ADMINISTRATOR . '/components/com_pplcz/templates/vmadmin/html/com_virtuemart/category';
        $categoryTargetBase = JPATH_ADMINISTRATOR . '/templates/vmadmin/html/com_virtuemart/category';

        // Vytvořit cílovou složku pro category pokud neexistuje
        if (!is_dir($categoryTargetBase))
        {
            if (!mkdir($categoryTargetBase, 0755, true))
            {
                Factory::getApplication()->enqueueMessage(
                    'Failed to create VirtueMart category template override directory: ' . $categoryTargetBase,
                    'warning'
                );
                $success = false;
            }
        }

        // Soubory pro category k zkopírování
        $categoryFiles = [
            'edit.php',
            'edit_ppl.php'
        ];

        foreach ($categoryFiles as $file)
        {
            $source = $categorySourceBase . '/' . $file;
            $target = $categoryTargetBase . '/' . $file;

            if (file_exists($source))
            {
                if (!copy($source, $target))
                {
                    Factory::getApplication()->enqueueMessage(
                        'Failed to install VirtueMart category template override: ' . $file,
                        'warning'
                    );
                    $success = false;
                }
            }
        }

        // Shipmentmethod overrides
        $shipmentSourceBase = JPATH_ADMINISTRATOR . '/components/com_pplcz/templates/vmadmin/html/com_virtuemart/shipmentmethod';
        $shipmentTargetBase = JPATH_ADMINISTRATOR . '/templates/vmadmin/html/com_virtuemart/shipmentmethod';

        // Vytvořit cílovou složku pro shipmentmethod pokud neexistuje
        if (!is_dir($shipmentTargetBase))
        {
            if (!mkdir($shipmentTargetBase, 0755, true))
            {
                Factory::getApplication()->enqueueMessage(
                    'Failed to create VirtueMart shipmentmethod template override directory: ' . $shipmentTargetBase,
                    'warning'
                );
                $success = false;
            }
        }

        // Soubory pro shipmentmethod k zkopírování
        $shipmentFiles = [
            'edit.php'
        ];

        foreach ($shipmentFiles as $file)
        {
            $source = $shipmentSourceBase . '/' . $file;
            $target = $shipmentTargetBase . '/' . $file;

            if (file_exists($source))
            {
                if (!copy($source, $target))
                {
                    Factory::getApplication()->enqueueMessage(
                        'Failed to install VirtueMart shipmentmethod template override: ' . $file,
                        'warning'
                    );
                    $success = false;
                }
            }
        }

        if ($success)
        {
            Factory::getApplication()->enqueueMessage(
                'VirtueMart template overrides installed successfully.',
                'success'
            );
        }

        return $success;
    }

    /**
     * Check if database tables are installed
     *
     * @return  boolean  True if tables exist
     */
    private function checkTablesInstalled()
    {
        $db = Factory::getContainer()->get('DatabaseDriver');
        $prefix = $db->getPrefix();

        // Check for main tables (must match install.mysql.utf8.sql)
        $tables = [
            $prefix . 'pplcz_address',
            $prefix . 'pplcz_batch',
            $prefix . 'pplcz_cod_bank_account',
            $prefix . 'pplcz_collections',
            $prefix . 'pplcz_log',
            $prefix . 'pplcz_order_meta',
            $prefix . 'pplcz_package',
            $prefix . 'pplcz_parcel',
            $prefix . 'pplcz_product',
            $prefix . 'pplcz_shipment',
            $prefix . 'pplcz_shipment_method',
        ];

        foreach ($tables as $table)
        {
            $db->setQuery("SHOW TABLES LIKE " . $db->quote($table));
            $result = $db->loadResult();

            if (!$result)
            {
                Log::add(
                    'Table not found during check: ' . $table,
                    Log::WARNING,
                    'com_pplcz'
                );
                return false;
            }
        }

        return true;
    }

    /**
     * Install database tables manually
     *
     * @param   InstallerAdapter  $adapter  The installer adapter
     *
     * @return  boolean  True on success
     */
    private function installTablesManually(InstallerAdapter $adapter)
    {
        try
        {
            $db = Factory::getContainer()->get('DatabaseDriver');
            $sqlFile = JPATH_ADMINISTRATOR . '/components/com_pplcz/sql/install.mysql.utf8.sql';

            if (!file_exists($sqlFile))
            {
                $msg = 'SQL installation file not found: ' . $sqlFile;
                Factory::getApplication()->enqueueMessage($msg, 'error');
                Log::add($msg, Log::ERROR, 'com_pplcz');
                return false;
            }

            // Read SQL file
            $sql = file_get_contents($sqlFile);

            if (empty($sql))
            {
                $msg = 'SQL installation file is empty';
                Factory::getApplication()->enqueueMessage($msg, 'error');
                Log::add($msg, Log::ERROR, 'com_pplcz');
                return false;
            }

            Log::add('Starting manual database installation', Log::INFO, 'com_pplcz');

            // Replace prefix placeholder
            $prefix = $db->getPrefix();
            $sql = str_replace('#__', $prefix, $sql);

            // Split into individual queries
            $queries = $db->splitSql($sql);
            $successCount = 0;
            $errorCount = 0;

            // Execute each query
            foreach ($queries as $query)
            {
                $query = trim($query);

                if (empty($query))
                {
                    continue;
                }

                $db->setQuery($query);

                try
                {
                    $db->execute();
                    $successCount++;

                    // Log successful table creation
                    if (preg_match('/CREATE TABLE.*`(\w+)`/', $query, $matches))
                    {
                        Log::add('Created table: ' . $matches[1], Log::INFO, 'com_pplcz');
                    }
                }
                catch (\Exception $e)
                {
                    $errorCount++;
                    // Log error but continue with other queries
                    Log::add(
                        'Error executing query: ' . $e->getMessage() . ' Query: ' . substr($query, 0, 100),
                        Log::ERROR,
                        'com_pplcz'
                    );

                    Factory::getApplication()->enqueueMessage(
                        'SQL Error: ' . $e->getMessage(),
                        'warning'
                    );
                }
            }

            Log::add(
                sprintf('Database installation completed: %d succeeded, %d failed', $successCount, $errorCount),
                Log::INFO,
                'com_pplcz'
            );

            // Verify installation
            $allInstalled = $this->checkTablesInstalled();

            if (!$allInstalled)
            {
                Factory::getApplication()->enqueueMessage(
                    'Some database tables were not created. Please check logs.',
                    'warning'
                );
            }

            return $allInstalled;
        }
        catch (\Exception $e)
        {
            $msg = 'Error installing database tables: ' . $e->getMessage();
            Factory::getApplication()->enqueueMessage($msg, 'error');
            Log::add($msg, Log::ERROR, 'com_pplcz');
            return false;
        }
    }

    /**
     * Called on installation
     *
     * @param   InstallerAdapter  $adapter  The object responsible for running this script
     *
     * @return  boolean  True on success
     */
    public function install(InstallerAdapter $adapter)
    {
        return true;
    }

    /**
     * Called on update
     *
     * @param   InstallerAdapter  $adapter  The object responsible for running this script
     *
     * @return  boolean  True on success
     */
    public function update(InstallerAdapter $adapter)
    {
        return true;
    }

    /**
     * Called on uninstallation
     *
     * @param   InstallerAdapter  $adapter  The object responsible for running this script
     */
    public function uninstall(InstallerAdapter $adapter)
    {
        // Odstranit VirtueMart template overrides
        $this->uninstallTemplateOverrides();

        // Uživatelská data se defaultně NEMAŽOU — tabulky zůstávají zachovány
        // pro případnou reinstalaci nebo migraci dat.
        // $this->dropDatabaseTables();

        Factory::getApplication()->enqueueMessage(
            'PPL CZ component has been uninstalled. Database tables with user data have been preserved.',
            'warning'
        );

        return true;
    }

    /**
     * Drop all component database tables
     *
     * @return  boolean  True on success
     */
    private function dropDatabaseTables()
    {
        try
        {
            $db = Factory::getContainer()->get('DatabaseDriver');
            $prefix = $db->getPrefix();

            // List of tables to drop (in order to respect foreign keys)
            $tables = [
                'pplcz_shipment',
                'pplcz_package',
                'pplcz_address',
                'pplcz_parcel',
                'pplcz_cod_bank_account',
                'pplcz_batch',
                'pplcz_collections',
                'pplcz_log',
                'pplcz_order_meta',
                'pplcz_product',
                'pplcz_shipment_method',
            ];

            foreach ($tables as $table)
            {
                $tableName = $prefix . $table;

                // Check if table exists
                $db->setQuery("SHOW TABLES LIKE " . $db->quote($tableName));
                $exists = $db->loadResult();

                if ($exists)
                {
                    $db->setQuery("DROP TABLE IF EXISTS " . $db->quoteName($tableName));
                    $db->execute();

                    Log::add(
                        'Dropped table: ' . $tableName,
                        Log::INFO,
                        'com_pplcz'
                    );
                }
            }

            return true;
        }
        catch (\Exception $e)
        {
            Factory::getApplication()->enqueueMessage(
                'Error dropping database tables: ' . $e->getMessage(),
                'error'
            );

            Log::add(
                'Error dropping tables: ' . $e->getMessage(),
                Log::ERROR,
                'com_pplcz'
            );

            return false;
        }
    }

    /**
     * Remove VirtueMart template overrides for product and shipmentmethod edit
     *
     * @return  void
     */
    private function uninstallTemplateOverrides()
    {
        // Remove product overrides
        $productTargetBase = JPATH_ADMINISTRATOR . '/templates/vmadmin/html/com_virtuemart/product';

        $productFiles = [
            'product_edit.php',
            'product_edit_ppl.php'
        ];

        foreach ($productFiles as $file)
        {
            $target = $productTargetBase . '/' . $file;

            if (file_exists($target))
            {
                if (!unlink($target))
                {
                    Factory::getApplication()->enqueueMessage(
                        'Failed to remove VirtueMart product template override: ' . $file,
                        'warning'
                    );
                }
            }
        }

        // Remove category overrides
        $categoryTargetBase = JPATH_ADMINISTRATOR . '/templates/vmadmin/html/com_virtuemart/category';

        $categoryFiles = [
            'edit.php',
            'edit_ppl.php'
        ];

        foreach ($categoryFiles as $file)
        {
            $target = $categoryTargetBase . '/' . $file;

            if (file_exists($target))
            {
                if (!unlink($target))
                {
                    Factory::getApplication()->enqueueMessage(
                        'Failed to remove VirtueMart category template override: ' . $file,
                        'warning'
                    );
                }
            }
        }

        // Remove shipmentmethod overrides
        $shipmentTargetBase = JPATH_ADMINISTRATOR . '/templates/vmadmin/html/com_virtuemart/shipmentmethod';

        $shipmentFiles = [
            'edit.php'
        ];

        foreach ($shipmentFiles as $file)
        {
            $target = $shipmentTargetBase . '/' . $file;

            if (file_exists($target))
            {
                if (!unlink($target))
                {
                    Factory::getApplication()->enqueueMessage(
                        'Failed to remove VirtueMart shipmentmethod template override: ' . $file,
                        'warning'
                    );
                }
            }
        }
    }
}
